Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Course presentation</p>

Course presentation
========================================================

- Statistics is a compulsory course of the mathematics department with 6 credits 

- This **was supposed** to be the English version of the course

Teaching main components
========================================================

- Theory: 12 on-line lectures on Wednesdays for all class M1 
- Problems: 6 lectures on Mondays split into M11 (odd weeks) and M12 (even weeks) 
- Practicals: 3 on-line lectures o Wednesdays for all class M1



Grading
========================================================

- Theory: 3 on-line exams and 1 on-site exam comprising 71% 
of the grade.
- Practicals: 3 on-line exams each comprising 8% of the grade (24% in total).
- General competence: on-site essay after the 4th theory exam and worth 5% of the final grade. 


Single grade exams
========================================================

![plot of chunk unnamed-chunk-1](Presentation-figure/unnamed-chunk-1-1.png)
 
Cumulative grading  
========================================================
![plot of chunk unnamed-chunk-2](Presentation-figure/unnamed-chunk-2-1.png)



Objectives
========================================================

- Pass the course with the highest possible mark.

- Learn statistics.


The smartest way to climb up
========================================================

- Work a little each week on your own (you will consume less energy!)
- Prepare the problems session with the assignments

![plot of chunk unnamed-chunk-3](Presentation-figure/unnamed-chunk-3-1.png)



The training program
========================================================

- We will follow this training [program](https://atenea.upc.edu/mod/resource/view.php?id=2500675) where I have detailed the subject week by week and the **assigments**.

- I will give you specific **assignments** each week. They do not count for the grade but they will help you to go through the material. We will revise them on the problems and practical sessions.

- The lectures will be high-paced (we only have 12 and 3 practicals!)

- There is a lot of supporting material: (videos, problems, slides). Look for them in ATENEA and [my blog](https://alejandro-isglobal.github.io/teaching.html)


Bibliography
========================================================

- Montgomery, D. C.; Runger, G. C. Applied
statistics and probability for engineers. 4th
ed. New York: John Wiley & Sons, cop. 2006.
ISBN 9780471745891.

- Irwin Miller; Marylees Miller John E. Freund's
Mathematical Statistics with Applications.
4th ed. Pearson, 2000. ISBN 9780321807090
