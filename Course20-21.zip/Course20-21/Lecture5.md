Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 5</p>


Objective
========================================================

- Continuous random variables
- Moments of continuous random variables
- Probability density function
- Chebyshev's theorem 


Random variable
====================================================

**Definition:**

A random variable is a function that assigns a real number to each outcome in the sample space of a random experiment.



Measurement
====================================================

**Definition:**

The process of measurement is the assignment of a number to a characteristic of an object or event so that it can be compared with other objects or events.

Properties:

- type: nominal (male/female), ordinal (1st, 2nd, .. 3rd), interval (distance), and ratios (length)
- magnitude: a numerical value produced by an instrument 
- unit: a universal reference to which comparisons (measurements) are made
-  **uncertainty**: errors in the measurement process

Discrete random variables
====================================================

For a discrete random variable X with possible values $x_1 , x_2 , .. , x_m$ , a **probability
mass function** is a function such that

- $f(xi)\geq 0$
- $\sum_{i=1}^m f(x_i)=1$  
- $f(x_i)=P(X=x_i)$

In the frequentist interpretation, we have that 
$f_i=\frac{n_i}{n} \rightarrow f(x_i)=P(X=x_i)$ when $n \rightarrow \infty$ ($f_i$ are observed frequencies $f(x_i)$ are probabilities!).  


Continuous random variable
====================================================

What happens with continuous variables? 


```
        outcome   ni          fi
1  [0.801,20.9] 2274 0.456718217
2   (20.9,40.7]  992 0.199236795
3   (40.7,60.6]  982 0.197228359
4   (60.6,80.5]  178 0.035750151
5    (80.5,100]  169 0.033942559
6     (100,120]  142 0.028519783
7     (120,140]   58 0.011648925
8     (140,160]  104 0.020887728
9     (160,180]   42 0.008435429
10    (180,200]   38 0.007632055
```

Continuous random variable
====================================================

- We redefined the outcomes as little regular intervals (bins) and computed the relative frequency for each of them as we did in the discrete case. 

$f_i=\frac{n_i}{n} \rightarrow f(x_i)=P(X=x_i)$

The probability depends now on the length of the bins $\Delta x$. If we make the bins smaller and smaller then the frequencies get smaller and we should also have 

 $P(X=x_i) \rightarrow 0$ when $\Delta x \rightarrow 0$

Continuous random variable
====================================================

We, therefore, define a quantity at a point $x$ that is the amount of probability that we would find in an infinitesimal bin $dx$ at $x$

$$f(x)= \frac{P(x\leq X \leq x+dx)}{dx}$$

$f(x)$ is a probability **density** function. Therefore, the probability of $x$ between $x$ and $x+dx$
is given by

$$P(x\leq X \leq x+dx)= f(x) dx$$


Probability density function
====================================================

**Definition**

For a continuous random variable X, a probability density function is such that  

- $f(x) \geq 0$
- $\int_{-\infty}^{\infty} f(x) dx = 1$
- $P(a\leq X \leq b)=\int_{a}^{b} f(x) dx$


Probability density function
====================================================

- The probability density functions is a step forward in the abstraction of probabilities: we add the continuous limit ($dx \rightarrow 0$). 

- All the properties of probabilities are translated in terms of densities ($\sum \rightarrow \int$). 

- Assignment of probabilities to a random variable can be done with equiprobability (classical) arguments.

- Densities are mathematical quantities some will map to experiments some will not. *Which density will map best to my experiment?*

Probability density function
====================================================

A line production process requires to drill a hole of $12.5mm$ in a metallic disc. Sometimes the drill moves and opens slightly larger holes 

-  We **believe** that $$f(x)=20 e^{-20(x-12.5)}$$ for $12.5 \leq x$ and  $f(x)=0$ for $x\leq 12.5$ 

Later we will learn what *believe* precisely means.

Probability density function
====================================================

We can use the function to calculate for instance the density $x=12.6$, $f(12.6)=2.70$

![plot of chunk unnamed-chunk-2](Lecture5-figure/unnamed-chunk-2-1.png)

Mean
====================================================

As in the discrete case, the **mean** measures the center of the distribution

**Definition**

Suppose X is a continuous random variable with probability **density** function $f(x)$. The mean or expected value of X, denoted as $\mu$ or $E(X)$, is

$$\mu=E(X)=\int_{-\infty}^\infty x f(x) dx$$

It is the continuous version of the center of mass.

Mean
====================================================

If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
-  and  $f(x)=0$ for $x\leq 12.5$ 
 

what is the expected diameter?



Mean
====================================================

$E(X) = \int_{-\infty}^\infty x f(x)dx$
</br>$= \int_{-\infty}^\infty 20 x e^{-20(x-12.5)}dx$
</br>$= -xe^{-20(x-12.5)} -\frac{1}{20}e^{-20(x-12.5)}\bigm|_{12.5}^\infty$
</br>$= 12.5 + 0.05 = 12.55$

Second line: integration by parts. $\int uv' = uv -\int u'v$

Last line: In the limit, $x\rightarrow\infty$ value of the integral is 0

Variance
====================================================

As in the discrete case, the variance measures the dispersion about the mean

**Definition**

Suppose X is a continuous random variable with probability density function $f(x)$. The variance of X, denoted as $\sigma^2$ or $V(X)$, is

$$\sigma^2=V(X)=\int_{-\infty}^\infty (x-\mu)^2 f(x) dx$$



Mean and variance properties
====================================================

- For any function $h$ of a random variable X, with density function $f(x)$, its expected value is given by

$E[h(X)]= \int_{-\infty}^\infty h(x) f(x) dx$

For $a$ and $b$ scalars, the main is linear but the variance is not ($Y=h(X)=a X +b$)

- $E(a X +b)= \int [a x +b] f(x)dx = a E(X) +b$

- $V(a X +b)=  a^2 V(X)$


Variance is not linear: demonstration
====================================================
for $Y=a X +b$, $E(Y)=\mu_Y$

$V(a X +b) = \int (a x +b-\mu_Y)^2 f(x)dx$
</br>$=  \int ( a x +b -a E(X) -b)^2 f(x)dx$
</br>$=  \int a^2(x  - E(X) )^2 f(x)dx$
</br>$=  a^2  \int (  x  - E(X) )^2 f(x)dx$
</br>$=  a^2 V(X)$ 

Variance
====================================================


If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
- and  $f(x)=0$ for $x\leq 12.5$ 
 
what is the variance of $f(x)$?

We can of course do the integral, but to compute this variance is better to first compute the second moment about the origin.

Moments of a continuous random variable 
====================================================

Similar to the discrete case, the variance of a continuous random variable $X$ satisfies

$V(X)=\int_{-\infty}^\infty (x-\mu)^2 f(x)dx$
</br>$=\int (x^2-2x\mu+\mu^2) f(x)dx$
</br>$=\int x^2 f(x)dx -2\mu\int x f(x) dx + \mu^2$
</br>$=\int x^2 f(x)dx -2\mu^2 + \mu^2$
</br>$=\int x^2 f(x)dx -\mu^2$

where $E(x^2)=\int x^2 f(x)dx$ is the second moment about the origin.

Moments of a continuous random variable 
====================================================


**Property**

The variance can also be written as

$$\sigma^2=V(X)=\int_{-\infty}^\infty (x-\mu)^2 f(x) dx=\int_{-\infty}^\infty x^2 f(x) dx-\mu^2$$

Remember the property for **discrete** random variables

$$\sigma^2=V(X)=\sum_{i=1}^n (x_i-\mu)^2 f(x_i) =\Sigma_{i=1}^n x_i^2 f(x_i) -\mu^2$$

The variance is the moment of inertia about the center of mass



Moments of a continuous random variable 
====================================================

If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
-  and  $f(x)=0$ for $x\leq 12.5$ 
 
what is the variance of $f(x)$?


let's use

$V(X)=E(X^2) -\mu^2$


Moments of a continuous random variable 
====================================================



$V(X)=\sigma^2 = \int_{-\infty}^\infty x^2 f(x)dx - \mu^2$
</br>$= \int_{-\infty}^\infty 20 x^2 e^{-20(x-12.5)}dx - \mu^2$
</br>$= -x^2e^{-20(x-12.5)}\bigm|_{12.5}^\infty + \int_{-\infty}^\infty 2x e^{-20(x-12.5)}dx - \mu^2$
</br>$= 12.5^2 + \frac{2\mu}{20} -\mu^2 = [12.5^2 + \frac{2*12.5}{20}+\frac{1}{20^2}]+\frac{1}{20^2} -\mu^2$
</br>$= (12.5 + \frac{1}{20})^2+\frac{1}{20^2} -(12.5 + \frac{1}{20})^2$
</br>$= \frac{1}{20^2}$

Remember $\mu=12.5+1/20=12.55$ 

then $\mu=12.5+\sigma$



Moments of a continuous random variable 
====================================================

Let's remember that the r-moment **about the origin** is the expected values of the function $X^r$

$E(X^r)=\mu'_r=\int_{-\infty}^\infty x^r f(x) dx$

- the first moment about the origin $r=1$ is the mean
</br>$E(X)=\mu=\mu'_1=\int_{-\infty}^\infty x f(x) dx$

- the second moment about the origin $r=2$ is 
</br>$\mu'_2=\int_{-\infty}^\infty x^2 f(x) dx$


Moments of a continuous random variable 
====================================================

The expected value of $\mu_r=(X-\mu)^r$ is the $r$-moment of X with **about the mean**.

</br>$E[(X-\mu)^r]=\mu_r=\int_{-\infty}^\infty (x-\mu)^r f(x) dx$


- the zeroth moment about the mean is 
</br>$\mu_0=1$

- the first moment about the mean is 
</br>$\mu_1=0$

- the second moment about the mean is the variance </br>$\mu_2=V(X)=\sigma^2$



Moments of a continuous random variable 
====================================================


How $\mu'_r$ and $\mu_r$ relate?
</br>$E[(X)^r]=\mu'_r=\int_{-\infty}^\infty (x-\mu+\mu)^r f(x) dx$
</br>$=\int_{-\infty}^\infty \sum_{i=0..r} \binom r i \mu^{r-i}(x-\mu)^i f(x) dx$
</br>$=\sum_{i=0..r} \binom r i \mu^{r-i} \int_{-\infty}^\infty (x-\mu)^i f(x) dx$
</br>$=\sum_{i=0..r} \binom r i \mu^{i} \mu_{r-i}$

- when $r=2$ we have:  $\mu'_2 = \mu_2 + \mu^2$ (remember that $\mu_0=1$, $\mu_1=0$ and $\mu_2=V(X)$) and then we recover the property of the variance: $V(X)= \mu'_2 - \mu^2=E(X^2)-E(X)^2$ 

- when $r=3$ we have: $\mu'_3= \mu^0\mu_3+3\mu^1\mu_2+3\mu^2\mu_1+\mu^3\mu_0$

$\mu'_3= \mu_3+3\mu\mu_2+\mu^3$

Moments of a continuous random variable 
====================================================

Standardized moments:

- Skewness: $\frac{\mu_3}{\sigma^3}$ tells us how symmetric the probability density about the mean is.
- kurtosis: $\frac{\mu_4}{\sigma^4}$ tells us how much probability we can find far from the mean.

Is there a way to compute the moments in an automatic way?

Moments of a continuous random variable 
====================================================

Skewness and  kurtosis

<img src="./figures/sk.png" style="width:60%"  align="center">


Moment generating function 
====================================================

**Definition**

Another way to encode the information of the probability distribution is through a function $M_x$ defined as:

$M_X(t)=E(e^{tX})=\int_{-\infty}^{\infty}  e^{tx} f(x)dx$

Which gives the moments by a simple differentiation

$\mu'_r =\frac{d^r M_X(t)}{dt^r}\bigm|_{t=0}$


Moment generating function 
====================================================

Remember
</br>$\frac{d^re^{tx}}{dt^r}=x^r e^{tx}$

so that
</br>$\frac{d^re^{tx}}{dt^r}\bigm|_{t=0}=x^r$

therefore
</br>$\frac{d^r M_X(t)}{dt^r}\bigm|_{t=0}=\int_{-\infty}^{\infty}  x^r f(x)dx$

is the r-moment of X

Moment generating function 
====================================================


If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
-  and  $f(x)=0$ for $x\leq 12.5$ 
 

 what are the moments of $f(x)$?

Moment generating function 
====================================================


</br>$M_X(t)=E(e^{tX}) = \int_{-\infty}^\infty e^{tx} f(x)dx$
</br>$= \int_{-\infty}^\infty 20 e^{tx} e^{-20(x-12.5)}dx$
</br>$= \int_{-\infty}^\infty 20 e^{-x(20-t)+20*12.5}dx$
</br>$= \frac{20}{-20+t}e^{-x(20-t)+20*12.5} \bigm|_{12.5}^\infty$
</br>$=  \frac{20}{20-t} e^{12.5t}$

Moment generating function 
====================================================

$M_X(t)= \frac{20}{20-t} e^{12.5t}$

</br>$\mu'_1=\frac{d M_X(t)}{dt}=\frac{20}{(20-t)^2} e^{12.5t}+\frac{20}{20-t}12.5 e^{12.5t}\bigm|_{t=0}$
</br>$=(\frac{1}{(20-t)} + 12.5)*M_X(t)\bigm|_{t=0}$
</br>$= \frac{1}{20}+ 12.5$
</br>$= 12.55 = \mu$

The first moment about the origin is the mean $\mu$

Moment generating function 
====================================================

The second moment about the mean is 

$\mu'_2=\frac{d^2 M_X(t)}{dt^2}\bigm|_{t=0}$
</br>$=\frac{d}{dt}\{(\frac{1}{(20-t)} + 12.5)*M_X(t))\}\bigm|_{t=0}$
</br>$=\frac{1}{(20-t)^2}*M_X(t) + (\frac{1}{(20-t)} + 12.5)*\frac{d M_X(t)}{dt}\bigm|_{t=0}$
</br>$=\frac{1}{(20-t)^2}*M_X(t) + (\frac{1}{(20-t)} + 12.5)^2* M_X(t)\bigm|_{t=0}$
</br>$=\frac{1}{20^2} + \mu*\mu$

From the equation to change to the second moment about the mean (variance): $\mu'_2 =\mu_2+\mu^2$ we see that $\mu_2=\sigma^2=1/20^2$.


Moment generating function 
====================================================

The third moment is:

$\mu'_3=\frac{d^3 M_X(t)}{dt^3}\bigm|_{t=0}$
</br>$=\frac{d}{dt}\{ (\frac{1}{(20-t)^2} + (\frac{1}{(20-t)} + 12.5)^2)*M_X(t) \}\bigm|_{t=0}$
</br>$=(\frac{2}{(20-t)^3}+2(\frac{1}{(20-t)} + 12.5)\frac{1}{(20-t)^2})*M_X(t)\bigm|_{t=0}$ 
</br>$+(\frac{1}{(20-t)^2} + (\frac{1}{(20-t)} + 12.5)^2)*\frac{dM_X(t)}{dx}\bigm|_{t=0}$
</br>$=2\sigma^3+2\mu\sigma^2+(\sigma^2 + \mu^2)\mu$  
</br>$=2\sigma^3+3\mu\sigma^2+ \mu^3$  




Moment generating function 
====================================================

For our drill we have:
</br>$\mu'_3=2\sigma^3+3\mu\sigma^2+ \mu^3$  

from the transformation of moments
</br>$\mu'_3= \mu_3+3\mu\mu_2+\mu^3$

Equating both equations we find $\frac{\mu_3}{\sigma^3}=2$

And therefore the skweness for probability fuction of our drill is
</br>$skweness=\frac{\mu_3}{\sigma^3}=2$

Exponential probability model
====================================================


If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
-  and  $f(x)=0$ for $x\leq 12.5$ 
 
we can change variable: $z=x-12.5$ and $\lambda=20$

$$f(z)=\lambda e^{-\lambda z}, z\geq 0$$


Exponential probability model
====================================================

For a probability density function

$$f(z)=\lambda e^{-\lambda z}, z\geq 0$$

we have

- mean: $\mu_z=E(Z)=E(X-12.5) =12.5+\frac{1}{\lambda}-12.5=\frac{1}{\lambda}$ 

- variance: $\sigma^2_z=V(Z)=V(X)=\frac{1}{\lambda^2}$

- moment generating function: $M_Z(t)=\frac{\lambda}{\lambda-t}$


Exponential probability model
====================================================


We can then pose the question: if we suspect that our drill has a probability density of the form 

$$f(z)=\lambda e^{-\lambda z}, z\geq 0$$

What would be the value of $\lambda$ for a set of observations of a particular drill?



Exponential probability model
====================================================


- We call $f(z)$ an **exponential model** for the probability

- We call $\lambda$ the **parameter** of the model

We will see more about models and how to estimate parameters from data in following letctures



Cumulative distribution function
====================================================

For continuous random variables, the cumulative function distribution is

$$F(x)=P(X\leq x) =\int_{-\infty} ^x f(u)du$$

the accumulation of probability up to $x$, given by the area under the $f$ curve up to $x$.

Cumulative distribution function
====================================================

From the definition 
</br>$F(x)=P(X\leq x) =\int_{-\infty} ^x f(u)du$

we have

- $F(-\infty)= 0$ and $F(\infty)=1$
- if $a\leq b$ then $F(a)\leq F(b)$
- $P(a \leq X \leq b) = F(b)-F(a)$
- $f(x)=\frac{dF(x)}{dx}$ (Fundamental theorem of calculus)

Cumulative distribution function
====================================================


Let's see the second property: $P(a \leq X \leq b) = F(b)-F(a)$

We can see: 

$P(a \leq X \leq b) = 1-P(X \leq a)-P(b \leq X)$
</br>$= P(b \leq X) - P(X \leq a)$
</br>$=  F(b)-F(a)$ 

Cumulative distribution function
====================================================


If the drill has the probability density distribution

- $f(x)=20 e^{-20(x-12.5)}$ for $12.5 \leq x$ 
 
-  and  $f(x)=0$ for $x\leq 12.5$ 
 
What is the cumulative distribution function $F(x)$?


Cumulative distribution function
====================================================



$F(x) = \int_{-\infty}^x f(u)du$
</br>$= \int_{-12.5}^x 20 e^{-20(u-12.5)}du$
</br>$= -e^{-20(u-12.5)}\bigm|_{12.5}^x$
</br>$= 1 -e^{-20(x-12.5)}$

$F(x)=0$ for $x\leq 12.5$

or if $Z=X-12.5$

$F(z) = 1 -e^{-\lambda(z)}$, for $z\geq 0$

$F(z) = 0$, for $z < 0$

Cumulative distribution function
====================================================


![plot of chunk unnamed-chunk-3](Lecture5-figure/unnamed-chunk-3-1.png)

Cumulative distribution function
====================================================

We can use the cumulative distribution function to directly calculate the probability that $x \leq 12.6$

Which is the value of $F(x)$ at 12.6.

or $F(12.6)=0.86$

Chebyshev's Theorem
====================================================

A general property of probabilities discrete and continuos that is satisfied by all of them.

What should be the probability of a value that is far from the mean?


Intuitively we think that it should be low because

- the probability should concentrate about the mean. 
- the probability of high values should decrease far from the mean.

Is the definition of probability mass/density functions sufficient to sustain these ideas?

Chebyshev's Theorem
====================================================

For any random variable X with mean $\mu$ and variance $\sigma^2$,


**Theorem**

$$P(|X -\mu| \geq a\sigma) \leq \frac{1}{a^2}$$


for any $a>0$. 

- We are going to consider discrete variables $X \in \mathbb{Z}$

- The same arguments can be applied to the continuous case replacing summations for integrals.


Chebyshev's Theorem
====================================================

Consider $\sigma=1$ as an example, the probability of having values 1 standard deviation unit away from the mean is $\leq 1$ (trivial)


<img src="./figures/cheb1.JPG" style="width:75%"  align="center">


Chebyshev's Theorem
====================================================

consider $\sigma=2$ as an example, the probability of having measurements 2 standard deviation units away from the mean is $\leq 1/2^2=1/4$ 

<img src="./figures/cheb2.JPG" style="width:75%"  align="center">

Chebyshev's Theorem
====================================================


For our drill, we compute the probability between 

$P(|X -\mu| > a\sigma)=1 - P(|X -\mu| \leq a\sigma)$
</br>$=1 - P(\mu-a\sigma \leq X \leq \mu + a\sigma)$
</br>$=1 - [F(\mu + a\sigma) - F(\mu - a\sigma)]$
</br>$=1 - F(\mu + a\sigma)$

$F(\mu - a\sigma)$ = 0 , $x \leq \mu - \sigma$, that is $a>1$ 



Chebyshev's Theorem
====================================================

consider $\sigma=1$ as an example

| a | Chebyshev's rule for any prob distribution | drill $F(x)=P(X \leq x)$|
| ------- | ---------------------- | ---------------------- |
| 1.5 | less than 44% | $1 -F(\mu + 1.5*\sigma)=0.22$ |
| 2 | less than 25% | $1 - F(\mu + 2*\sigma)=0.13$ |
| 3 | less than 11.1% | $1 - F(\mu + 3*\sigma)=0.05$ |
| 4 | less than 6.3% | $1 - F(\mu + 4*\sigma)=0.01$ |

As we go further and further from the mean, as measured by the standard deviation, the probability drops, and the measurements are rarer. 



Chebyshev's Theorem
====================================================


</br> $\sigma^2 = \sum_{i=1}^n (x_i-\mu)^2 f(x_i)$
</br> $=  \sum_{i \in \{|x_i-\mu|\geq a\sigma\}(red\,zone)}  (x_i-\mu)^2 f(x_i)$
</br> $+   \sum_{i \in \{|x_i-\mu|\leq a\sigma\}(blue\,zone)}  (x_i-\mu)^2 f(x_i)$

$\sigma^2$ computed outside the distance $a\sigma$ (red) and inside $a\sigma$ (blue). Both integrals are positive.

Chebyshev's Theorem
====================================================



$\sigma^2 \geq   \sum_{i \in \{|x_i-\mu|\geq a\sigma\}(red\,zone)}  (x_i-\mu)^2 f(x_i)$
                
$\sigma^2$ is greater than the summation outside $a\sigma$ only  because all the terms are positive

Chebyshev's Theorem
====================================================


 $\sigma^2 \geq   \sum_{i \in \{|x_i-\mu|\geq a\sigma \}(red\,zone)}  (x_i-\mu)^2 f(x_i)$
</br> $\geq   \sum_{i \in \{|x_i-\mu|\geq a\sigma\}(red\,zone)}   a^2 \sigma^2 f(x_i)$

because for those X such that are in th red zone $|X-\mu|\geq a\sigma$ then $$(X-\mu)^2 \geq a^2\sigma^2$$ 

Chebyshev's Theorem
====================================================



 $\sigma^2 \geq \sum_{i \in \{|x_i-\mu|\geq a\sigma\}(red\,zone)} a^2 \sigma^2 f(x_i)$
</br> $=a^2\sigma^2 \sum_{i \in \{|x_i-\mu|\geq a\sigma\}(red\,zone)}  f(x_i)$
</br> $=a^2 \sigma^2 P(|X-\mu|\geq a\sigma)$


summing up

$\sigma^2\geq a^2 \sigma^2 P(|X-\mu|\geq a\sigma)$

then 

$\frac{1}{a^2} \geq P(|X-\mu|\geq a\sigma)$



