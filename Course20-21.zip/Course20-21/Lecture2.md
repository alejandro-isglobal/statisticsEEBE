Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 2</p>

Objective
========================================================

- Definition of probability
- Probability algebra
- Conditional probability

Statistics objective
========================================================

- Solve problems in a systematic way (science, engineering technology)

- Modern humans use a general **method** historically developed for thousands of years! ... and still under development.

- It has three main components: observation, logic, and generation of new knowledge 


Road map
========================================================


<img src="./figures/roadmap.JPG" style="width:75%"  align="center">



Scientific Method
========================================================

<img src="./figures/interaction.JPG" style="width:75%"  align="center">


Output
========================================================

<img src="./figures/output.JPG" style="width:75%"  align="center">



Statistics
========================================================

<img src="./figures/stats.JPG" style="width:75%"  align="center">



Models
========================================================

<img src="./figures/models.JPG" style="width:75%"  align="center">






Random experiment
====================================================

- Let´s think of an archetypical random experiment: **the dice**.

- Throw a dice 10 times and count the frequency of obtaining the possible values 1, 2, 3, 4, 5, and 6. Let's count the proportion of times each value was observed (we did not observe 4).


```
  outcome ni  fi
1       1  2 0.2
2       2  2 0.2
3       3  1 0.1
4       5  2 0.2
5       6  3 0.3
```


Random experiment
====================================================

- What happens when $N$ increases to 1,000?


```
  outcome  ni    fi
1       1 171 0.171
2       2 177 0.177
3       3 163 0.163
4       4 170 0.170
5       5 149 0.149
6       6 170 0.170
```

- What happens when $N \rightarrow \infty$?



Random experiment
====================================================

$$lim_{N\rightarrow \infty} f_i = P_i$$

![plot of chunk unnamed-chunk-3](Lecture2-figure/unnamed-chunk-3-1.png)


Probability
====================================================

We call **Probability** $P_i$ to the limit when $N \rightarrow \infty$ of the frequency of observing the value $i$ in a random experiment.

- We understand that these values belong to Nature, they do not depend on the experimenter or the observer: They describe things as they are.

- If so, can we work backward? If we believe that the $P_i$'s describe things as they are, can we **predict** the expected values of $f_i$ at lower $N$?

- What are the main logical properties of these $P_i$'s?

Sample space
====================================================

We start by reasoning what are all the possible values (outcomes) that a random experiment could give. 

Note that we do not have to observe them in a particular experiment: We are using logic and not observation. 

**Definition:**

The set of all possible values that an observation of a random experiment can take is called the sample space
of the experiment. The sample space is denoted as S.


Sample space
====================================================

- temperature 35 and 42 degrees Celcius 
- sugar levels: 70-80mg/dL
- size of one screw from a production line: 70mm-72mm
- number of emails received in an hour: 0-100
- a dice throw: 1, 2, 3, 4, 5, 6


Sample space
====================================================

**Discrete and continuous sample spaces**

- A sample space is discrete if it consists of a finite or countable infinite set of outcomes.
- A sample space is continuous if it contains an interval (either finite or infinite in length) of
real numbers.


Event
====================================================

**Definition:**

An event is a subset of the sample space of a random experiment. It is a collection of outcomes.



Observations Outcomes and Events
====================================================

Consider a throwing a dice 20 times with the following results:

1 5 1 2 2 1 2 2 3 1 1 3 3 1 6 3 5 6 4 4

- the 12th observation had the outcome value of 3:

1 5 1 2 2 1 2 2 3 1 1 **3** 3 1 6 3 5 6 4 4

- the outcome 3 was observed 4 times:

1 5 1 2 2 1 2 2 **3** 1 1 **3** **3** 1 6 **3** 5 6 4 4


Observations Outcomes and Events
====================================================

- the event less or equal to 3 had 14 observations:

**1** 5 **1** **2** **2** **1** **2** **2** **3** **1** **1** **3** **3** **1** 6 **3** 5 6 4 4

- the sample space is

S={1, 2, 3, 4, 5, 6}

- the random experiment is

a computer simulation of the throw of a dice 

Event
====================================================

Examples:
- The event of a healthy temperature: temperature 37-38 degrees Celcius 
- The event of producing a screw with size: 71.5mm
- The event of receiving more than 4 emails in an hour.

The event refers to a set of **values** that the outcomes can take.



Event
====================================================

Examples:
- The event of a healthy temperature: temperature 37-38 degrees Celcius 
- The event of producing a screw with size: 71.5mm
- The event of receiving more than 4 emails in an hour.

Note that the outcomes of different experiments can belong to the same event.



Operations of events
====================================================

- The **union** of two events is the event that consists of all outcomes that are contained in either of the two events. We denote the union as $E1\cup E2$ .


$E1$=hypothermia, $t<37$

$E2$=fever, $t>38$

$E1\cup E2= [35,37) \cup (38,42]$

The event of observing a patient with hypothermia **OR** fever.


Operations of events
====================================================


The **intersection** of two events is the event that consists of all outcomes that are contained in both of the two events. We denote the intersection as $E1 \cap E2$ .


$E1$=hypothermia, $t<37$

$E2$=fever, $t>38$

$E1\cap E2= \emptyset$

The event of observing a patient with hypothermia **AND** fever.



Operations of events
====================================================

The {\bf complement} of an event in a sample space is the set of outcomes in the sample space that are not in the event. We denote the component of the event $E$ as $E'$.

$E1$=hypothermia, $t<37$

$E1'$=no-hypotermina $t\geq 37$


Operations of events
====================================================

Note that

$E3=E1\cup E2= [35,37) \cup (38,42]$

$E3'= [37, 38]$=healthy

The event of observing a patient with no-hypothermia **OR** no-fever is the event of observing a healthy patient.


Venn diagrams
====================================================


<img src="./figures/venn.png" style="width:75%"  align="center">



Mutually exclusive
====================================================

**Definition:**

Two events denoted as E1 and E2, such that
$$E1\cap E2=\emptyset$$
are said to be mutually exclusive.


Probability
====================================================

**Classical Interpretation:**

Whenever a sample space consists of N possible events that are equally likely, the probability of each outcome is $\frac{1}{N}$.

Championed by [Laplace (1814)](https://plato.stanford.edu/entries/probability-interpret/#ClaPro).


Probability
====================================================

**Frequentist Interpretation:**

Frequentist interpretation: P(E) is the limiting **relative frequency** for the event E when the number of observations is infinite.


Championed by [Venn (1876)](https://plato.stanford.edu/entries/probability-interpret/#ClaPro)

There are many other interpretations and it is an active research field in Philosophy

Probability
====================================================


<img src="./figures/prob.JPG" style="width:75%"  align="center">


Probability
====================================================

The probability is a function of the events of S that take values between 0 and 1. It is a mathematical object (there is nothing random about it!)

$$P(E) \in (0,1)$$

what should their properties be?


Addition of probabilities
====================================================

For a discrete sample space, the probability of an event E, denoted as $P(E)$, equals the sum of the probabilities of the events in E.

Think of Laplace and brake all the possible events of E in equal parts.

Addition of probabilities
====================================================

What is the probability of throwing one dice and obtaining less than 3?

Possible outcomes: 1, 2, and 3 then


$$P(1)+P(2)+P(3)=1/6+1/6+1/6=1/2$$

Think of Venn and is clear that if P is a frequency in the limiting case then, as frequencies can be added so probabilities. 

Axioms of probability
====================================================

Probability is a number that is assigned to each member of a collection of events of a sample space from a random experiment that satisfies the following properties:

If S is the sample space and E is any event in a random experiment,
- $P(S)=1$ 
- $0 \leq P(E) \leq 1$
- when $E1\cap E2=\emptyset$ $$P(E1\cup E2) = P(E1) + P(E2)$$

Proposed by Kolmogorov’s (1933)

Addition Rule
====================================================

$$P(A\cup B) = P(A) + P(B) - P(A\cap B)$$


Think of the following events for a dice

$A=\{1,2,3,4\}$ and $B=\{4,5\}$

then $P(A\cup B)$: the probability that $A$ or $B$ occurs is given by
</br>$P(A\cup B) = [P(1)+ P(2)+P(3) +P(4)]+ [P(4)+P(5)]$ 
</br>$- P(4)=5/6$

$P(4)= P(A\cap B)$ appears twice: we need to subtract one of them.

Addition Rule
====================================================
Think of the following events for a dice

$A=\{1,2,3,4\}$

$B=\{4,5\}$

Note also that the probability of the outcome being or nor being in $A\cup B$ is one. 

$$P([A\cup B]')+P([A\cup B])=1$$

Therefore
$$P([A\cup B])=1-P([A\cup B]')=1-P(6)=1-1/6=5/6$$ 


Addition Rule
====================================================

When we have three events A, B, and C: 

$P(A\cup B \cup C) = P([A\cup B] \cup C)$

$= [P(A) + P(B) - P(A\cap B)] + P(C)-P([A\cup B] \cap C)$

$= [P(A) + P(B) - P(A\cap B)] + P(C)-P([A \cap C]\cup [B \cap C])$

...

</br>$= P(A) + P(B) + P(C) - P(A\cap B) - P(A\cap C) - P(B\cap C)$
</br>$+P(A\cap B \cap C)$


Addition Rule
====================================================

For a collection of mutually exclusive sets E1... En

$$P(E1\cup E2 .. \cup En) = P(E1)+P(E2)...+P(En)$$


Joint Probability
====================================================

Let´s imagine a random experiment that measures two different types of outcomes.

- height and weight of an individual: (h, w)

- time and place of an electric charge: (p, t)

- a throw of two dice: ($n_1$,$n_2$)

In many cases, we are interested in finding out whether the values of one outcome condition the values of the other.


Joint Probability
====================================================

- if we observe a tall individual is likely to be heavy: (w,h)

- the time it takes a charge to hit a detector at a particular place could tell us is it passed through an electric field: (p,t)

- if we observe a number in one dice it will not tell us what the number of the other dice is: ($n_1$,$n_2$)


Diagnostics
====================================================

Let's consider a diagnostic tool

We want to find the state of a system (s):

- inadequate (yes)
- adequate (no)

with a test (t):

- positive
- negative

We test a battery to find how long it can live. We stress a cable to find if it resists carrying a certain load. We perform a PCR to see if someone is infected.


Joint Probability
====================================================
Let's consider diagnosing infection with a new test.

Infection status:

- yes (infected) 
- no (not infected) 

Test:

- positive 
- negative 

Joint Probability
========================================================

Each individual is a random experiment with two measurements: (Infection, Test)

| -- Subject -- | -- Infection -- | -- Test -- |
| ------------- | ------------- | ---------- |
| $s_1$         |   yes        | positive |
| $s_2$         |   no         | negative |
| $s_3$         |   yes        | positive |
|...            |   ...        | ...      |
| $s_i$         |   no         | positive* |
|...            |   ...        | ...      |
|...            |   ...        | ...      |
| $s_n$         |   yes        | negative* |



Contingency table
====================================================

|  | - Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | 18 | 12 | 30 |
| -<b>Test: negative</b>- | 30 | 300 | 330 |
| -<b>sum</b>-      | 48  | 312| 360 |



|  | - Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | $n_{pos,yes}$ | $n_{pos,no}$ | $n_{pos}$ |
| -<b>Test: negative</b>- | $n_{neg,yes}$ | $n_{neg,no}$ | $n_{neg}$ |
| -<b>sum</b>-      | $n_{yes}$  | $n_{no}$| $n$ |


Relative frequencies
====================================================


|  | -Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | 18/360=0.05 | 12/360=0.0333.. | 30/360 =0.0833..|
| -<b>Test: negative</b>- | 30/360=0.0833 | 300/360 =0.833.. | 330/360=0.9166.. |
| -<b>sum</b>-      | 48/360=0.133  | 312/360=0.866..| 1 |



|  | - Infected: yes -- | -- Infected: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | $fr(positive,yes)$ | $fr(positive,no)$ | $fr(positive)$ |
| -<b>Test: negative</b>- | $fr(negative,yes)$ | $fr(negative, no)$ | $fr(negative)$ |
| -<b>sum</b>-      | $fr(yes)$  | $fr(no)$| $1$ |




Joint probability
====================================================

when $N \rightarrow \infty$ we assume that the frequencies converge to probability values


|  | -Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | $P(positive,yes)$ | $P(positive,no)$ | $P(positive)$ |
| -<b>Test: negative</b>- | $P(negative,yes)$ | $P(negative,no)$ | $P(negative)$ |
| -<b>sum</b>-      | $P(yes)$  | $P(no)$| $1$ |

- $P(yes, positive) = P(yes \cap positive)$: probability of observing $yes$ **AND** $positive$ 
- $P(yes)$: **Marginal** probability of observing $yes$

Conditional probability
========================================================

Let's think first in terms of those who are **infected**

<br />
Within those who are infected (**yes**), what is the relative frequency many tested positive?

- <b>Sensitivity</b> (true positive rate)

$$fr(positive|yes)=\frac{n_{positive,yes}}{n_{yes}}$$

We write the bar to indicate that the frequency is taken in the subgroup of those who tested positive




Conditional probability
========================================================

We write it in terms of frequencies.


$$fr(positive|yes)=\frac{n_{positive,yes}}{n_{yes}}=\frac{\frac{n_{positive,yes}}{n}}{\frac{n_{yes}}{n}}=\frac{fr(positive,yes)}{fr(yes)}$$

Therefore, in the limit, we expect to have a probability of the type


$$P(positive|yes)=\frac{P(positive \cap yes)}{P(yes)}$$

That we will call the conditional probability of a **positive** value in the test given a **yes** value in the disease.  

Conditional probability
========================================================

**Definition:**
The conditional probability of an event B given an event A, denoted as $P(A|B)$, is
$$P(A|B) = \frac{P(A\cap B)}{P(B)}$$

- you can prove that the conditional probability satisfies the axioms of probability. 
-  it is the probability with the sampling space given by $B$: $S_B$.


Conditional probability
========================================================

Let's look at another conditional probability
<br />
Within those who respond (**no**) what is the probability to test negative?

- <b>Especificity</b> (True negative rate)

$$P(negative|no)=\frac{P(negative \cap no)}{P(no)}$$


Diagnostic Matrix
========================================================

|  | -Infection: Yes -- | -- Infection: No -- |
| --------- | --------- | -------- |
| -<b>Test: positive</b>-   |   P(positive <span>&#124;</span> yes)   |   P(positive <span>&#124;</span> no)   | 
| -<b>Test: negative</b>-   |   P(negative <span>&#124;</span> yes)   |   P(negative <span>&#124;</span> no)   | 
| -<b>sum</b>-      | 1                | 1               |


- False-positive rate: The probability of testing positive **if** having the disease $P(positive|no)$

- False-negative rate: The probability of testing negative **if** having the disease $P(negative|yes)$



Diagnostic Matrix
========================================================

Let's assume that the frequencies are from large enough $n$ to **estimate** the probabilities

|  | -Infection: Yes -- | -- Infection: No -- |
| --------- | --------- | -------- |
| -<b>Test: positive</b>- | 18/48 = 0.375 | 12/312 = 0.038 | 
| -<b>Test: negative</b>- | 30/48 = 0.625 | 300/312 =0.962| 
| -<b>sum</b>-      | 1                | 1               |

Our diagnostic tool has low sensitivity (0.375) but high
specificity (0.962).





Diagnostic Matrix
========================================================

Let's go back to our diagnostics of infections

<br />
Within those whose test is positive what is the probability of having the infection (yes)?

- <b>Positive predictive value</b> 

$$P(yes|positive)=\frac{P(yes \cap positive)}{P(positive)}$$

Diagnostic Matrix
========================================================

In the same way, we can ask :


Within those whose test is negative what is the probability of not having the disease (no)?

- <b>Negative predictive value</b> 

$$P(no|negative)=\frac{P(no \cap negative)}{P(negative)}$$


Diagnostic Matrix
========================================================

|  | Infection: Yes | Infection: No | sum |
| --------- | --------- | -------- | ------ |
| <b>Test: positive</b> | PPV: P(yes <span>&#124;</span> positive) | P(no <span>&#124;</span> positive) | 1 |
| <b>Test: negative</b> | P(yes <span>&#124;</span> negative) | NPV: P(no <span>&#124;</span> negative) | 1 |


PPV: positive predicted value
NPV: negative predicted value

These are really the values that we want to know when we take a test!


Diagnostic Matrix
========================================================

Let's assume that the frequencies are from large enough $n$ to **estimate** the probabilities



|  | -Infection: Yes -- | -- Infection: No -- | -- sum -- |
| --------- | --------- | -------- | ------ |
| -<b>Test: positive</b>- | 18/66=0.272 | 48/66=0.728 | 1 |
| -<b>Test: negative</b>- | 30/360=0.0833.. | 300/360=0.833.. | 1 |

- if you test positive there is only about 27% chance that you are infectious. 

- if you test negative there is a high chance 83% chance that you are not infectious. 
</br>The test is good to discard infections but not to confirm them.
