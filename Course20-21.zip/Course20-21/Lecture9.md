Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 9</p>


Objective
========================================================

Estimation:

- Statistic
- Maximum likelihood
- Method of moments



Sample distributions
========================================================

You tested the loading of 8 cables until braking. Here are the results


```r
x1=13.34642, x2=13.32620, x3=13.01459, x4=13.10811, x5=12.96999, x6=13.55309, x7=13.75557, x8=12.62747 
```


Sample distributions
========================================================


We learned that:

- sample mean $\bar{x}=\frac{1}{n} \sum_{j=1}^n x_j=13.21$ is a number obtained from the observations. 

- $\bar{x}$ is an observation of the random variable $\bar{X}=\frac{1}{n} \sum_{j=1}^n X_j$ from the $n$-sample $X_1$, ...$X_n$.

- the sample variance $s^2=\frac{1}{n-1}\sum_{i=1}^n (x_i-\bar{x})^2=0.127$ is a number obtained from the observations.

- $s^2$ is an observation of the random variable $S^2=\frac{1}{n-1}\sum_{i=1}^n (X_i-\bar{X})^2$ from the $n$-sample $X_1$, ...$X_n$.


Sample distributions
========================================================

We also learned that when $X_i$ are all independent repetitions of the random experiment $X \hookrightarrow N(\mu_X, \sigma_X^2)$ then 

- $\bar{X} \hookrightarrow N(\mu_X, \sigma_X^2/n)$
</br>(also satisfied when $n$ is large regardless of how $X$ distributes: CLT)

- $S^2 \hookrightarrow \chi^2(n-1)$


And in general, no matter how $X$ distributes:

- $E(\bar{X})=E(X)=\mu_X$ and $V(\bar{X})=\frac{\sigma^2_X}{n}$

- $E(S^2)=V(X)=\sigma^2_X$


Sample distributions
========================================================


<img src="./figures/null0.JPG" style="width:35%"  align="center">


Statistic
========================================================


**Definition**

Given a random sample $X_1,...X_n$  a **statistic** is any real value function of the random variables that define the random sample: $f(X_1,...X_n)$

- $\bar{X}=\frac{1}{N} \sum_{j=1..N} X_j$ 
- $S^2=\frac{1}{n-1}\sum_{i=1}^n (X_i-\bar{X})^2$
- $\max{X_1, X_n}$

are statistics



Estimator
========================================================

**Definition**

An **estimator** is a statistic $\Theta$ whose values $\hat{\theta}$ are measures of a parameter $\theta$ of the population distribution on which the sample is defined: $E(\Theta)\sim \theta$   



$X \hookrightarrow f(x; \theta)$

Then

- $\theta$ is a **parameter** of the population distribution $f(x; \theta)$
- $\Theta$ is an **estimator** of $\theta$: A random variable
- $\hat{\theta}$  is the **estimate** of $\theta$: A realized value of $\Theta$


Estimator
========================================================

<img src="./figures/estimator.JPG" style="width:50%"  align="center">


Estimator
========================================================

Example of when $X \hookrightarrow N(\mu_X, \sigma^2_X)$

For the mean:

- $\mu_X$ is a **parameter** of the population distribution $N(\mu_X, \sigma^2_X)$
- $\bar{X}$ is an **estimator** of $\mu_X$
- $\bar{x}=\hat{\mu}=13.21 \, Tons$ is the **estimate** of $\mu_X$


For the variance:

- $\sigma^2_X$ is a **parameter** of the population distribution $N(\mu_X, \sigma^2_X)$
- $S^2$ is an **estimator** of $\sigma^2_X$
- $s^2=\hat{\sigma^2_X}=0.127 \, Tons^2$ is the **estimate** of $\sigma^2_X$


Estimator
========================================================

An estimator is unbiased if $E(\Theta)=\theta$

- $\bar{X}$ is an **unbiased** estimator of $\mu_X$ because $E(\bar{X})=\mu_X$

- $S^2$ is an **unbiased** estimator of $\sigma^2_X$ because $E(S^2)=\sigma^2_X$


Maximum likelihood: History
========================================================


<img src="./figures/ceresml.JPG" style="width:50%"  align="center">



Maximum likelihood: History
========================================================

- Ceres was thought to be a planet

- It disappeared behind the Sun 

- Predictions were needed to know where in the sky to look for it after it passed behind the sun

- The trajectory (parallel to the planets) would determine if it was likely a planet

- With several observations with errors, what would be the best representative of the true position of Ceres at a given time? 


Maximum likelihood: History
========================================================

What is the statistic that best represents the true position of Ceres?

<img src="./figures/cerestime.JPG" style="width:50%"  align="center">



Maximum likelihood: History
========================================================

Gauss proposed that at a **given** time  

- the **most likely** position of Ceres was the mean.
- the probabilities around the mean were symmetrical.

<img src="./figures/meanceres.JPG" style="width:50%"  align="center">



Maximum likelihood: History
========================================================

What is the distribution of errors for the position of Ceres?


- The result of the random experiment $Y$: measurement of Ceres position. The error $z=y-y_{true}$ follows a probability density function: $Z \hookrightarrow f(z)=f(y-y_{true})$ 


- We have $n$ repetitions of the random experiment: $y_1, ... y_n$

The probability of observing the event: ($y_1, y_2, ... y_n$) for the $n$-sample is the multiplication of the probability of each event because the observations are independent events

$f(y_1,y_2,...y_n;y_{true})=f(y_1-y_{true})*f(y_2-y_{true})*...f(y_n-y_{true})=\Pi_{i=0,..m} f(y_i-y_{true})$


Maximum likelihood: History
========================================================

- the function of the parameter $\theta$ defined as:

$L(\theta; y_1,y_2,...y_n)=f(y_1,y_2,...y_n;y_{true})$ is called the likelihood functin of $\theta$

- For Ceres position the likelihood function is 

$L(y_{true}; y_1,y_2,...y_n)=\Pi_{i=0,..m} f(y_i-y_{true})$

Gauss asked: If $y_{true}$ is the mean of the observations $\mu_Y=\frac{1}{n}\sum_i^n y_i$ and the most likely value of Ceres then what is $f( y_1,y_2,...y_n; \mu_Y)$?

- The most likely value is the value that maximizes the likelihood function

$\frac{d}{d\mu_Y}L(\mu_Y; y_1,y_2,...y_n)=0$


Maximum likelihood: History
========================================================

$\frac{d}{d\mu_Y}[L(\mu_Y; y_1,y_2,...y_n)] =\frac{d}{d\mu_Y}[f(y_1-\mu_Y)*f(y_2-\mu_Y)*...f(y_n-\mu_Y)] =0$
</br>$=-f'(y_1-\mu_Y)*f(y_2-\mu_Y)*...f(y_n-\mu_Y)$
</br>$-f(y_1-\mu_Y)*f'(y_2-\mu_Y)*...f(y_n-\mu_Y)-...$
</br>$-f(y_1-\mu_Y)*f(y_2-\mu_Y)*...f'(y_n-\mu_Y)$
</br>$=-[\sum_{i=1}^n\frac{f'(y_i-\mu_Y)}{f(y_1-\mu_Y)}]*L(\mu_Y; y_1,y2,...y_n)=0$

- if $\frac{f'(y)}{f(y)}=ky$ then we solve the equation above because

$\sum_{i=1}^n\frac{f'(y_i-\mu_Y)}{f(y_i-\mu_Y)}=\sum_{i=1}^n k(y_i-\mu_Y)=\sum_{i=1}^n y_i -n\mu_Y=0$ because
$\mu_Y= \frac{1}{n} \sum_{i=1}^n y_i$.

- The solution of $\frac{f'(y)}{f(y)}=ky$ is the normal distribution: $\frac{h}{\sqrt{\pi}}e^{-h^2(y-\mu_Y)^2}$ with $k/2=-h^2$


Maximum likelihood: History
========================================================

Gauss discovered that if the **mean** is the most likely estimate of the measurements then the probability density for the errors is the function 

$\frac{h}{\sqrt{\pi}}e^{-h^2(y-\mu_Y)^2}$

that we call the Gaussian and that Pearson (1920) baptized it as the normal curve. 




Maximum likelihood: Application
========================================================

- When often suspect a shape for the probability function $X \hookrightarrow f(x; \theta)$. 

- If we have some observations, we try to find the best member of the function family that describes the observations.


How can we estimate $\theta$ from data when we know $f(x; \theta)$?


Maximum likelihood: Application
========================================================
Normal distribution: Undoing Gauss...

- Imagine that we already **know**  that $X \hookrightarrow N(\mu_X, \sigma_X^2)$. 

- What are estimators of $\mu_X$ and $\sigma_X^2$ from an $n$-sample?

<img src="./figures/normpar.JPG" style="width:35%"  align="center">




Maximum likelihood: Normal distribution
========================================================


- Imagine we make $n$ observations and obtain the values $(x_1, ....x_n)$ is 

The likelihood function, the probability of having observed $(x_1, ....x_n)$  is 
</br>$L(\mu, \sigma^2)=\Pi_{i=1..n} N(x_i;\mu,\sigma)$
<br>$=\big( \frac{1}{\sigma \sqrt{2 \pi}}\big)^n e^{-\frac{1}{2\sigma^2} \sum_i(x_i-\mu)^2}$

We can take the log of $L$, 
</br>$\ln L(\mu, \sigma^2)=-n \ln(\sigma \sqrt{2 \pi})-\frac{1}{2\sigma^2} \Sigma_i(x_i-\mu)^2$

this is called the **log-likelihood** function


Maximum likelihood: Normal distribution
========================================================

The estimates of $\mu$, $\sigma$ are where the likelihood is maximum, and give the highest probability for the data.

- Therefore we differentiate with respect to $\mu$ and $\sigma^2$ and equate to 0

</br>$\frac{d \ln L(\mu, \sigma^2)}{d\mu}=\frac{1}{\sigma^2} \sum_i(x_i-\mu)=0$

</br>$\frac{d \ln L(\mu, \sigma^2)}{d\sigma^2}=-\frac{n}{2 \sigma^2}+\frac{1}{2\sigma^4} \sum_i(x_i-\mu)^2=0$


Maximum likelihood: Normal distribution
========================================================

The solutions of equations 
</br>$\frac{1}{\sigma^2} \sum_i(x_i-\mu)=0$
</br>$-\frac{n}{2 \sigma^2}+\frac{1}{2\sigma^4} \sum_i(x_i-\mu)^2=0$

are at
</br>$\hat{\mu}=\frac{1}{n}\sum_i x_i=\bar{x}$
</br>$\hat{\sigma^2}=\frac{1}{n}\sum_i(x_i-\bar{x})^2$

The maximum likelihood method assigns the estimators 
</br>$\hat{\mu}=\bar{x}$
</br>$\hat{\sigma^2}=\frac{1}{n}\sum_i(x_i-\bar{x})^2$
</br>for $\mu$ and $\sigma^2$ in a poulation that distributes  $X \hookrightarrow N(\mu_X, \sigma_X^2)$


Maximum likelihood: Normal distribution
========================================================

This is almost what we expected!

- $\hat{\mu}=\bar{x}$, as Gauss thought us 

but

- $\hat{\sigma^2}=\frac{1}{n}\Sigma_i(x_i-\bar{x})^2=s^2_{ML}$ is not $s^2=\frac{1}{n-1}\Sigma_i(x_i-\bar{x})^2$

remember that $E(S^2)=\sigma^2$ then $E(S^2_{ML})=\frac{n-1}{n}E(S^2)=\frac{n-1}{n}\sigma^2$

The maximum likelihood estimator $S^2_{ML}$ of $\sigma^2$ is a **biased** estimator as: $E(S^2_{ML})\neq \sigma^2$




Estimator
========================================================

<img src="./figures/ML.JPG" style="width:50%"  align="center">




Maximum likelihood
========================================================
Why is it the maximum likelihood method useful?

Imagine we suspect that variable has a probability density distribution

\[
    f(x)= 
\begin{cases}
\frac{1}{\alpha}x^{\frac{1-\alpha}{\alpha}},& \text{if } x \in (0,1)\\
    0,& x \notin (0,1)\\
\end{cases}
\]

Where $\alpha$ is a parameter.

If we were to perform a $n$-sample: $X_1,...X_n$ 

- What would be the maximum likelihood estimator for $\alpha$ ($\hat{\alpha_v}$)?


Maximum likelihood
========================================================




<img src="./figures/dist.JPG" style="width:50%"  align="center">




Maximum likelihood
========================================================


Remember that the likelihood function for a random sample is
</br>$L(\theta)= \Pi_{i=1..n} f(x_i, \theta)$

then 
</br>$L(\alpha;x_1,..x_n)= \frac{1}{\alpha^n} \Pi_{i=1..n} x_i^{\frac{1-\alpha}{\alpha}}= \frac{1}{\alpha^n}  (x_1x_2...x_n)^{\frac{1-\alpha}{\alpha}}$

and we use the the Log-likelihood 
</br>$\ln L(\alpha;x_1,..x_n)= -n \ln(\alpha) + {\frac{1-\alpha}{\alpha}} \Sigma_{i=1...n} \ln (x_i)$

to find its maximum.


Maximum likelihood
========================================================

We differentiate with respect to $\alpha$
</br>$\frac{d \ln L(\alpha)}{d \alpha}= -\frac{n}{\alpha} - \frac{1}{\alpha^2}  \Sigma_{i=1...n} \ln (x_i)=0$

Solving for $\alpha$
</br>$\alpha=-\frac{1}{n}\Sigma_{i=1...n} \ln (x_i)$

and therefore the maximum likehood estimate for $\alpha$ is 
</br>$\hat{\alpha_v}=-\frac{1}{n}\Sigma_{i=1...n} \ln (x_i)$

That is: When we have performed $n$ measurements $x_1, ...x_n$ we use the formula above to estimate the parameter $\alpha$ from the data. We thus **infer** (fix) the probability density for $X$.  


Maximum likelihood
========================================================

Another important application is in regression:
</br>$N(y_i;\mu_i=m+b*t_i,\sigma^2)= \frac{1}{\sigma \sqrt{2 \pi}} e^{-\frac{1}{2\sigma^2} (y_i-\mu_i)^2}= \frac{1}{\sigma \sqrt{2 \pi}} e^{-\frac{1}{2\sigma^2} (y_i-m-b*t_i)^2}$ 
</br> what are the maximum likelihood estimates for $m$ and $b$?
<img src="./figures/regression.JPG" style="width:50%"  align="center">



Maximum likelihood
========================================================

The likelihood function, the probability of having observed $(x_1, ....x_n)$  at $t_i, ...t_n$ 
</br>$L(\mu_i, \sigma)=\Pi_{i=1..n} N(m+b*t_i;\mu,\sigma)$
<br>$=\big( \frac{1}{\sigma \sqrt{2 \pi}}\big)^n e^{-\frac{1}{2\sigma^2} \sum_i(y_i-m-b*t_i)^2}$

The log-likelihood is
</br>$\log(\Pi_{i=1..n} N(m+b*t_i;\mu,\sigma))=-\frac{n}{2}\log(2\pi)-n\log( \sigma) - \frac{1}{2\sigma^2} \sum_i(y_i-m-b*t_i)^2$

that we differentiate with respect to $m$ and $b$ and equate to 0 to find the maxima.

After some algebra (exercise) we have

$b=\frac{\sum_i (t_i-\bar{t})(y_i -\bar{y})}{\sum_i (t_i-\bar{t})^2}$

$m = \bar{y} - b \bar{t}$

Maximum likelihood
========================================================
These are the values we obtained when we adjust a line to observations 
$(x_1, y_1)...(x_n, y_n)$ by minimum squares (when we had $x$ instead o $t$).

$b=\frac{\sum_i (x_i-\bar{x})(y_i -\bar{y})}{\sum_i (x_i-\bar{x})^2}$

$m = \bar{y} - b \bar{x}$

The difference now is that we know that $b$ is the realization of the random variable 

$B=\frac{\sum_i (x_i-\bar{x})(Y_i -\bar{Y})}{\sum_i (x_i-\bar{x})^2}$

That is the sum of the normal variables $Y_1, ... Y_n$, and therefore is normal.


Maximum likelihood
========================================================

What have we gained?

- We can then test the probability that $P(B>0)$ or that Ceres is moving in the sky. 

- As we fix the values of $m$ and $b$ we can compute $E(Y_{t_n})$ as the most likely prediction of the position of Ceres at time $t_n$.

Gauss's story is one of the most important advancements of science. To predict where to find Ceres in the sky in 1802, he discovered the normal distribution, and invented the maximum likelihood method and regression analysis. 

Astronomers pointed their telescopes where Gauss told them, and there Ceres was!


Method of Moments
========================================================


The method of maximum likelihood is aimed to produce the estimators of probability distributions from data. 

- Is there another way to produce those estimators? would they be equal?

Let's look again at the maximum likelihood estimators for $\mu$ and $\sigma^2$ for a random variable that distributes normally: $X \hookrightarrow N(\mu, \sigma^2)$

- $\hat{\mu}=\frac{1}{n}\sum_i x_i$
- $\hat{\sigma^2}=\frac{1}{n}\sum_i(x_i-\bar{x})^2$


Method of Moments
========================================================

Let's re-write the estimators in terms of the values of $X$ (outcomes), not of the observations

For instance:

$\hat{\mu}=\frac{1}{n}\sum_i x_i= \sum_x x \frac{n_x}{n}$

and remember that in the limit $n \rightarrow \infty$ the frequentist interpretation requires $\frac{n_x}{n} \rightarrow P(X=x)$ and therefore in the limit 

$\hat{\mu}=\frac{1}{n}\sum_i x_i \rightarrow E(X)$

The method of moments assigns a random variable 

$M'_1 = \frac{1}{n}\sum_i X_i$ as the estimator of $E(X)$, we had just called $M'_1=\bar{X}$ 


What does the method of moments tell us about the probabilistic models?




Summary of probability models
========================================================


| Model |  f(x) | E(X) | Parameter estimates from $E(X)=\bar{x}$|
| -----------  | ----- | ---- | ----------- |
| Bernoulli             |  $p^x(1-p)^{1-x}$ | $p$ | $\hat{p}=\bar{x}$ |
| Binomial | $\binom n x p^x(1-p)^{n-x}$ | $np$ | $\hat{p}=\frac{\bar{x}}{n}$ |
| Shifted geometric | $p(1-p)^{x-1}$ | $\frac{1}{p}$ |$\hat{p}=\frac{1}{\bar{x}}$  |
| Negative Binomial |$\binom {x+r-1} x p^r(1-p)^x$ | $r\frac{1-p}{p}$ | $\hat{p}=\frac{r}{\bar{x}-r}$ | 
| Poisson | $\frac{e^{-\lambda}\lambda^x}{x!}$ | $\lambda$ | $\hat{\lambda}=\bar{x}$ |
| Exponential | $\lambda e^{-\lambda x}$ | $\frac{1}{\lambda}$ | $\hat{\lambda}=\frac{1}{\bar{x}}$ |
| Normal | $\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}$ | $\mu$ |$\hat{\mu}=\bar{x}$,$\hat{\sigma}^2=\frac{1}{n}\sum_ix_i^2-\bar{x}^2$ |



Method of Moments
========================================================
The parameter of $f(x;\theta)$ should then be found from the estimator equation: 

$E(X)=\mu'_1=\frac{1}{n}\sum_i x_i$, where $\mu'_1$ is an obervation of $M'_1$

$\mu'_1$ is the **sample** first moment, it is a number that is computed from data. 



$\mu'_1=\frac{1}{n}\sum_i x_i=\hat{\mu}$

Method of Moments
========================================================

If there are more parameters we use the higher **sample** moments

- The second **sample** moment $\mu'_2=\frac{1}{n}\sum_i x^2_i$ is the estimator of the second moment about the origin $E(X^2)$


For the normal probability density, we have

$\frac{1}{n}\sum_i x^2_i = E(X^2) = \hat{\mu}^2 + V(X)= \hat{\mu}^2+\hat{\sigma}^2$ 

then 

$\hat{\sigma}^2= \frac{1}{n} \sum_i x^2_i -\hat{\mu}^2=\frac{1}{n} \sum_i(x_i-\hat{\mu})^2$


Method of Moments
========================================================

Let $X_1, ...X_n$ be a random sample of the probability distribution $f(x; \theta_1, ..\theta_r)$ (continuous or discrete). The $k$'th **sample moment**   
is defined by 

$\mu'_k=\frac{1}{n}\sum_{i=1}^2 x_i^k$

**Method of moments:** 

The estimators of $\theta_1... \theta_k$ are obtained from the r equations: 

$\mu'_k=E(X^r), \, \,\,\,k=1,..r$


Method of Moments
========================================================

Suppose that $f(x;a)$ is a uniform distribution, where we do not know the minimum value that $x$ can take, but we know that the maximum is 1
\[
f(x)=
\begin{cases}
    \frac{1}{1-a},& \text{if } x\in (a,1)\\
    0,& otherwise 
\end{cases}
\] 

What is the estimator of $a$?

- We run an experiment and obtain $x_1,...x_n$ how can we estimate $a$ form the data?

Method of Moments
========================================================

The distribution has one parameter. The method of moments gives us one equation

$\mu'_1=E(X)$

$\bar{x}=\frac{\hat{a}+1}{2}$

therefore
$\hat{a}=2\bar{x}-1$
is the estimator of the minimum measurement we could observe. 

Method of Moments
========================================================

Note that taking the minimum of the measurements is clearly suboptimal.

The method gave us a clever answer:

- we can compute $\bar{x}$ with increasing presicion given by $n$
- We know that no measurement surpass $b=1$
- Then compute the distance between $\bar{x}$ and $b$: $1-\bar{x}$
- Substract it from $\bar{x}$: $\bar{x}-(1-\bar{x})=2\bar{x}-1$ 


Method of Moments
========================================================

Imagine we suspect that variable has a probability density distribution

\[
    f(x)= 
\begin{cases}
\frac{1}{\alpha}x^{\frac{1-\alpha}{\alpha}},& \text{if } x \in (0,1)\\
    0,& x \notin (0,1)\\
\end{cases}
\]

Where $\alpha$ is a parameter.

If we were to perform a $n$-sample: $X_1,...X_n$ 

- What would be the estimator for $\alpha$ ($\hat{\alpha_M}$) by the method of moments?



Method of Moments
========================================================

The method of moments equals the moments of the sample to the moments of the probability density distribution.

$\mu'_r=E(X^r)$

The first moment of the sample is given by the sample average

$\mu'_1=\frac{1}{n}\sum_{i=1}^n x_i$

The first moment of the probability density distribution of a random variable is the variable's expected value $E(X)$ 

$E(X)= \frac{1}{\alpha} \int_0^1 x x^{\frac{1-\alpha}{\alpha}}dx= \frac{1}{\alpha} \int_0^1 x^{1+\frac{1-\alpha}{\alpha}}dx$

Method of Moments
========================================================


$E(X)= \frac{1}{\alpha} \big[\frac{x^{2+\frac{1-\alpha}{\alpha}}}{{2+\frac{1-\alpha}{\alpha}}}\big]_0^1=\frac{1}{1+\alpha}$


Therefore, the method of moments gives us the equation

$\bar{x}=\frac{1}{1+\hat{\alpha}}$ which solving for $\hat{\alpha}$ gives us the estimate for $\hat{\alpha}_m$

</br>$\hat{\alpha}_m=\frac{1-\bar{x}}{\bar{x}}$


Method of Moments
========================================================

Note that this is an example for which the estimates by maximum likelihood and the method of moments are different

- $\hat{\alpha}_v=-\frac{1}{n}\sum_{i=1}^n \ln (x_i)$


- $\hat{\alpha}_m=\frac{1-\bar{x}}{\bar{x}}$


Method of Moments
========================================================

We can simulate the distribution of the estimators for each method but remember in real life we only have one experiment of $n$ samples and one single value for the estimators. 


<img src="./figures/alpha.JPG" style="width:35%"  align="center">


