Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 1</p>

Objective
========================================================

- Introduction to statistics
- Data Vs Models
- Data: discrete, continuous
- Summarizing data in tables and figures


Statistics objective
========================================================

- Solve problems in a systematic way (science, engineering technology)

- Modern humans use a general **method** historically developed for thousands of years! ... and still under development.

- It has three main components: observation, logic, and generation of new knowledge 



Road map
========================================================


<img src="./figures/roadmap.JPG" style="width:75%"  align="center">



Scientific Method
========================================================

<img src="./figures/interaction.JPG" style="width:75%"  align="center">


Output
========================================================

<img src="./figures/output.JPG" style="width:75%"  align="center">



Statistics
========================================================

<img src="./figures/stats.JPG" style="width:75%"  align="center">





Data
========================================================

<img src="./figures/data.JPG" style="width:75%"  align="center">




Outcome
========================================================

**Observation** or *Realization*

- and **observation** is the acquisition of a number or a characteristic from an experiment

 ... 1 0 0 1 0 **1** 0 1 1  ... (the number in bold is an observation)

**Outcome**

- An **outcome** is a possible observation that is the result of an experiment.

**1** is an outcome, **0** is the other outcome

Outcome
========================================================

Outcomes can be:

- Categorical: If the result of an experiment can only take discrete values (number of car pieces produced per hour, number of leukocytes in blood)

- Continuous: If the result of an experiment can only take continuous values (battery state of charge, Engin temperature).



Random experiment
========================================================

Experiments produce *signals* and *noise*.

- Signals are reliable/predictive measurements 
- Noise are unreliable/unpredictive measuremnets

Most experiments

$outcome = signal + noise$

The objective is to extract the noise from the outcome.

Random experiment
========================================================

When the noise is not zero we have a **random experiment**

**Definition:**
An experiment that is repeated in the same manner every time results in different outcomes.


Random experiment
========================================================

Examples:
- on the same object (person): temperature, sugar levels.  
- on different objects but the same measurement: the size of one screw from a production line.
- a number of emails received in an hour.

Power plants 
========================================================

In the [World Global Resource Institute](
https://www.wri.org/publication/global-power-plant-database)
they gather global data on power plants:

They have a record on: 
- 299910 plants 
- from 2014-2017
- across 164 countries 
- type of plant and capacity (GWH)

The data can be downloaded and different measures can be obtained.


Wind farms
========================================================

Let's look at the wind farms. This is an example of only **6** farms from a total of 5091.


```
                           name country primary_fuel
539      Mortons Lane Wind Farm     AUS         Wind
542      Mount Millar Wind Farm     AUS         Wind
545         Mt Mercer Wind Farm     AUS         Wind
553           Mumbida Wind Farm     AUS         Wind
560                   Musselroe     AUS         Wind
569 North Brown Hill  Wind Farm     AUS         Wind
```
 


Categorical variables
========================================================


When we repeat a random experiment, we record a list of outcomes.<br> 


We summarize the **categorical** observations by counting how many times we saw a particular outcome.

$n_i$ is the number of times we observed the outcome $i$

In our example, let´s think of  AUS (Australia) as a possible **outcome** for the variable **country** of a wind farm. 

Frequencies
========================================================

How many wind farms are in each country?


```
    outcome frequency
n1      ARG        12
n2      AUS        58
n3      BEL        12
n4      BRA       412
n5      CAN       241
n6      CHL        18
n7      CHN       835
n8      DEU        25
n9      DNK        19
n10     ESP       342
n11     EST        13
n12     FIN        12
n13     FRA       721
n14     GBR       727
n15     GRC        12
n16     IND       108
n17     IRL        38
n18     KOR        12
n19     LKA        14
n20     MAR        11
n21     MEX        20
n22     NLD        40
n23     POL        59
n24     PRT       224
n25     URY        39
n26     USA      1043
n27     ZAF        24
```



Relative frequencies
========================================================


We can also summarize the observations by computing the **proportion** of how many times we saw a particular outcome.

$$f_i=n_i/N$$ where $N$ is the total nunber of observations

In our example there are recorded $N=5091$ wind farms, so we ask for the proportion of wind farms in each country from 5091.


Relative frequencies
========================================================


```
   outcome   ni          fi
1      ARG   12 0.002357101
2      AUS   58 0.011392654
3      BEL   12 0.002357101
4      BRA  412 0.080927126
5      CAN  241 0.047338440
6      CHL   18 0.003535651
7      CHN  835 0.164014928
8      DEU   25 0.004910627
9      DNK   19 0.003732076
10     ESP  342 0.067177372
11     EST   13 0.002553526
12     FIN   12 0.002357101
13     FRA  721 0.141622471
14     GBR  727 0.142801021
15     GRC   12 0.002357101
16     IND  108 0.021213907
17     IRL   38 0.007464152
18     KOR   12 0.002357101
19     LKA   14 0.002749951
20     MAR   11 0.002160676
21     MEX   20 0.003928501
22     NLD   40 0.007857003
23     POL   59 0.011589079
24     PRT  224 0.043999214
25     URY   39 0.007660577
26     USA 1043 0.204871342
27     ZAF   24 0.004714202
```



Frequencies
========================================================


Clearly, we must have

$$\sum_{i=1..m} n_i =N$$

and 

$$\sum_{i=1..m} f_i =1$$

where $m$ is the total amount of possible outcomes observed in the data.



Pie chart
========================================================
We can further visualize the relative frequencies with a pie chart- Where the area of the circle represents 100% of observations (proportion = 1) and the sections the relative frequencies of al the outcomes.

![plot of chunk unnamed-chunk-4](Lecture1-figure/unnamed-chunk-4-1.png)


Outcome Vs Observation
========================================================

This is one **observation** of the experiment/survey (one windfarm)

```
                   name country primary_fuel
1459 Campo dos Ventos V     BRA         Wind
```

This is the frequency of observing the **outcome** BRA (or number of wind farms in Brazil)


```
  outcome  ni         fi
4     BRA 412 0.08092713
```

Categorical and ordered variables
========================================================

Countries are not meaningfully ordered concerning the outcomes. However, sometimes **categorical** variables can be **ordered** (days, months, years)  




```
                   name country year_of_capacity_data
1459 Campo dos Ventos V     BRA                  2017
1462            Camurim     BRA                  2017
1469            Candiba     BRA                  2017
1472     Canoa Quebrada     BRA                  2017
1482  CapÃ£o do InglÃªs     BRA                  2017
1488           Caravela     BRA                  2017
```


Categorical and ordered variables
====================================================

- We can again see how many times each year was observed (in which year the data for the wind farms was collected)

- and the proportion of outcomes for each year (years are the observations now) 


```
  outcome   ni         fi
1    2015   12 0.00673023
2    2016  273 0.15311273
3    2017 1459 0.81828379
4    2018   39 0.02187325
```

Absolute cumulative frequency 
====================================================


When outcomes can be ordered then it is useful to ask how many outcomes were observed up to a given value we call this number the absolute cumulative frequency up to the outcome $i$: 
$$N_i=\sum_{k=1..i} n_k$$


```
  outcome   ni         fi   Ni
1    2015   12 0.00673023   12
2    2016  273 0.15311273  285
3    2017 1459 0.81828379 1744
4    2018   39 0.02187325 1783
```

Relative cumulative frequency 
====================================================

The same definition can be done for the relative frequency. 

$$F_i=\sum_{k=1..i} f_k$$


```
  outcome   ni         fi   Ni         Fi
1    2015   12 0.00673023   12 0.00673023
2    2016  273 0.15311273  285 0.15984296
3    2017 1459 0.81828379 1744 0.97812675
4    2018   39 0.02187325 1783 1.00000000
```

up to 2017 0.97% of the data on 1783 windfarms was collected. 


Bar plot
====================================================

We can plot $n_i$ Vs the outcomes, giving us a bar plot

![plot of chunk unnamed-chunk-11](Lecture1-figure/unnamed-chunk-11-1.png)

Continuous variables 
====================================================


The result of a random experiment can also give continuous outcomes, like the MW capacity of the farm


```
                           name country capacity_mw
539      Mortons Lane Wind Farm     AUS        20.0
542      Mount Millar Wind Farm     AUS        70.0
545         Mt Mercer Wind Farm     AUS       131.0
553           Mumbida Wind Farm     AUS        55.0
560                   Musselroe     AUS       168.0
569 North Brown Hill  Wind Farm     AUS       132.3
```
 
Continuous variables 
====================================================
- We can know the range of the observation by it minimum and maximum obverved outcomes

- For the wind farms capacity they range between: (1MW, 200MW)


Continuous variables 
====================================================

- Continuous outcomes cannot be counted!

- We cover range into little regular intervals of the same size (bins)


```r
[0.801,20.9], (20.9,40.7], (40.7,60.6], (60.6,80.5], (80.5,100], (100,120], (120,140], (140,160], (160,180], (180,200]
```

- creating an **ordered categorical** variable; in this case with 10 posible outcomes  


Continuous variables 
====================================================

So the for instance the list of values 

```r
16.56  1.80  2.02 25.20 25.20  6.30
```

are mapped to the intervals

```r
[0.801,20.9], [0.801,20.9], [0.801,20.9], (20.9,40.7], (20.9,40.7], [0.801,20.9]
```

Continuous variables 
====================================================
And our data will look like


```
                           name country bined.capacity
560                   Musselroe     AUS      (160,180]
569 North Brown Hill  Wind Farm     AUS      (120,140]
575     Oakland Hills Wind Farm     AUS    (60.6,80.5]
618          Royalla Solar Farm     AUS   [0.801,20.9]
624              Snowtown North     AUS      (140,160]
625              Snowtown South     AUS      (120,140]
```

Frequencies for continuous variables 
====================================================


```
        outcome   ni          fi   Ni        Fi
1  [0.801,20.9] 2251 0.460515548 2251 0.4605155
2   (20.9,40.7]  964 0.197217676 3215 0.6577332
3   (40.7,60.6]  965 0.197422259 4180 0.8551555
4   (60.6,80.5]  171 0.034983633 4351 0.8901391
5    (80.5,100]  161 0.032937807 4512 0.9230769
6     (100,120]  139 0.028436989 4651 0.9515139
7     (120,140]   56 0.011456628 4707 0.9629705
8     (140,160]  102 0.020867430 4809 0.9838380
9     (160,180]   41 0.008387889 4850 0.9922259
10    (180,200]   38 0.007774141 4888 1.0000000
```

Histogram
====================================================

The histogram is the plot of $n_i$ or $f_i$ Vs the outcomes (bins). The histogram depends on the size of the bins

![plot of chunk unnamed-chunk-18](Lecture1-figure/unnamed-chunk-18-1.png)



Histogram
====================================================


![plot of chunk unnamed-chunk-19](Lecture1-figure/unnamed-chunk-19-1.png)

cumulative frequency plot
====================================================

We can also plot the cumulative frequency Vs the outcomes

![plot of chunk unnamed-chunk-20](Lecture1-figure/unnamed-chunk-20-1.png)


Summary statistics
====================================================

The summary statistics are numbers computed from the data that tell us important features of numerical variables (categorical or continuous). 

Limiting values:

- minimum: the minimum outcome observed
- maximum: the maximum outcome observed

Summary statistics
====================================================

Central value for the outcomes


- The average is defined as

$$\bar{x}=\frac{1}{N} \sum_{j=1..N} x_j$$

where $x_j$ is the **observation** $j$ (wind farm) from a total of $N$. 


Summary statistics
====================================================

In terms  of the **outcomes** that categorical variables can take

$$\bar{x}= \sum_{x \in R_x} x \frac{n_x}{N}$$

from a total of $m=dim(R_x)$ values observed (number of countries). $\bar{x}$ computes the **central value** or center of gravity of the outcomes. As if each outcome was a mass with weight $n_i$.

In terms of the relative frequency
$$\bar{x}= \sum_{x \in R_x} x f_x$$



Summary statistics
====================================================

The average capacity can be computed directly from the **observations** 
</br>$\bar{capacity}= \frac{1}{N}\sum_j x_j$
</br>$= \frac{1}{N}(16.56  1.80  + 2.02 + 25.20+ 25.20 + 6.30+...) = 35.751$


Summary statistics
====================================================

The year average for the wind farms data can **also** be computed from the frequencies
</br>$\bar{year}=\sum_{year} year*f_{year}$
</br>$=2015*f_{2015}+2016*f_{2016}+2017*f_{2017}+2018*f_{2018}=2016.85$



Summary statistics
====================================================

The averages are not the result of one observation (random experiment) but a series of observations. They describe the number where the observed values balance.

Thas is why we hear, for instance, that a coronavirus patient can infect an average of 2.5 people. 





Summary statistics
====================================================

![plot of chunk unnamed-chunk-22](Lecture1-figure/unnamed-chunk-22-1.png)


Summary statistics
====================================================

Another measure of centrality is the median. The median $q_{0.5}$ is the value $x_p$ 
</br>$median(x)=q_{0.5}=x_p$ 

below which we find half of the observations
</br>$\sum_{x\leq x_p} 1 = \frac{N}{2}$

or in terms of the frequencies, is the value $x_p$ that makes the cumulative frequency $F_p$ equal to 0.5
</br>$q_{0.5}=\sum_{x\leq x_p} f_x =F_p=0.5$


Summary statistics
====================================================

- Average: Center of mass (compensates distant values)
- Median: Half of the mass

![plot of chunk unnamed-chunk-23](Lecture1-figure/unnamed-chunk-23-1.png)



Summary statistics
====================================================

An important measure for the outcomes is their **dispersion**. Many experiments can share their mean but differ on how dispersed the values are.


![plot of chunk unnamed-chunk-24](Lecture1-figure/unnamed-chunk-24-1.png)

Summary statistics
====================================================


![plot of chunk unnamed-chunk-25](Lecture1-figure/unnamed-chunk-25-1.png)

Summary statistics
====================================================

Dispersion about the mean is measured with the 

- The sample variance:

$$s^2=\frac{1}{N-1} \sum_{j=1..N} (x_j-\bar{x})^2$$


It measures the average square distance of the **observations**  to the average. The reason for N-1 will be explained when we talk about inference. 


Summary statistics
====================================================

- In terms of the frequencies of **categorical** variables observed (moment of inertia)

$$s^2=\frac{N}{N-1} \sum_{x} (x-\bar{x})^2 f_x$$



Summary statistics
====================================================

The squared root of the sample variance is called the **standard deviation** $s$.


The standard deviation of the wind farms capacity is
</br>$s= [\frac{1}{N-1}((16.56-35.751)^2+  (1.80-35.751)^2$  
</br>$+ (2.02-35.751)^2 + ...)]^{1/2} = 37.487$

The capacity of wind farms deviates from their mean in 37.487MW.

Summary statistics
====================================================

- Dispersion of data can also be measured with respect to the media by the **Interquartile range**

- We define the first quartile as the value $p$ **under** which there are the first 25% of the observations

$$q_{0.25}=\sum_{i=1..p} f_i =F_p=0.25$$

- We also define the third quartile as the value $p$ **above** which there are the first 25% of the observations


Summary statistics
====================================================
The distance between the third quartile  and the first quartile is called the **interquartile range** (IQR) and captures the central 50% of the observations


![plot of chunk unnamed-chunk-26](Lecture1-figure/unnamed-chunk-26-1.png)

Summary statistics
====================================================
The interquartile range, the median, and the 5% and 95% of the data can be visualized in a **boxplot**, here the values of the outcomes are in the y-axis. The IQR is the box, the median the line in the middle and the whiskers mark the 5% and 95% of the data.

![plot of chunk unnamed-chunk-27](Lecture1-figure/unnamed-chunk-27-1.png)

Summing up
====================================================

- We have seen **observational** data: Each windmill had some variables measured: 

-- Categorical: year, country
-- Continous: Capacity on MW

We consider that observing a wind farm is the observation of a random experiment: observing wind farms around the world. Every time we observe a wind farm the variables take different values. Each variable has a **frequency** of being observed.

Summing up
====================================================

- The frequencies of the variables **f_i** or its accumulation **F_i** (in ordered variables) are characteristics of the system (humans constructing wind farms).

- They do not (should not) depend on who is running the experiment, unlike $n_i$ or $N$. 

- But they depend on $n_i$ and $N$. When do they lose their dependence on $n_i$?

Summing up
====================================================

- Let´s think of an archetypical random experiment: **the dice**.

- Throw a dice 10 times and count the frequency of obtaining the possible values 1, 2, 3, 4, 5 and 6


```
  outcome ni  fi Ni  Fi
1       1  1 0.1  1 0.1
2       2  1 0.1  2 0.2
3       3  3 0.3  5 0.5
4       4  3 0.3  8 0.8
5       5  2 0.2 10 1.0
```


Summing up
====================================================

- What happens when $N$ increases to 1,000?


```
  outcome  ni    fi   Ni    Fi
1       1 174 0.174  174 0.174
2       2 164 0.164  338 0.338
3       3 186 0.186  524 0.524
4       4 154 0.154  678 0.678
5       5 163 0.163  841 0.841
6       6 159 0.159 1000 1.000
```

- What happens when $N \rightarrow \infty$?



Summing up
====================================================

$$lim_{N\rightarrow \infty} f_i = P_i$$

![plot of chunk unnamed-chunk-30](Lecture1-figure/unnamed-chunk-30-1.png)


Next
====================================================

We call **Probability** $P_i$ to the limit when $N \rightarrow \infty$ of the frequency of observing the value $i$ in a random experiment.

- We understand that these values belong to Nature, they do not depend on the experimenter or the observer: They describe things as they are.

- If so, can we work backward? If we believe that the $P_i$'s describe things as they are, can we **predict** the expected values of $f_i$ at lower $N$?

- What are the main logical properties of these $P_i$'s?
