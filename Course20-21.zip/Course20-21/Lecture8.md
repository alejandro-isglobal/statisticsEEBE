Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politecnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 8</p>

Objective
========================================================

- Sample mean distributions
- Sample variance distribution
- Central limit theorem

Sample mean distributions
========================================================

- Probability motivated by the difference in observations we obtain each time we run a random experiment.

- Mass and density probability distributions define the probability of one outcome.

- Probability models define likely probabilities for natural/engineered phenomena. We have assumed **we know** the parameters of the models and can then compute probabilities. 

Sample mean distributions
========================================================

What do we do in real life?

- We perform one random experiment many times.

Imagine your company is asked to sell metallic cables for the port of Barcelona that can carry up to 12 Tons. 

- You have on  **stock** one type of cable that could do the job but they have never been used to carry more than 10 tons.

Can you use the cables in stock or you need to produce another one? 


Sample mean distributions
========================================================

- If one cable in stock cannot take the load and breaks it can injure workers.

However

- Let's imagine that testing the resistance of 8 cables in stock is cheaper than producing a new product. 

- You save money on design and manufacturing. Even if you manufactured a new product you still have to run tests.   



Sample mean distributions
========================================================

You convince the company to invest in testing loading each cable until braking. Here are the results


```r
x1=13.34642, x2=13.32620, x3=13.01459, x4=13.10811, x5=12.96999, x6=13.55309, x7=13.75557, x8=12.62747 
```



Sample mean distributions
========================================================

let's plot them

![plot of chunk unnamed-chunk-2](Lecture8-figure/unnamed-chunk-2-1.png)


Sample mean distributions
========================================================

- None of them broke at 12 Tons.

- How sure are we that the one we sell does not break at 12 Tones?

- There was one that broke at 12.62747 Tons.

Do you take the risk?



Sample mean distributions
========================================================

- In real life we repeat and experiment $n$ times and don't know the probability distribution of the outcomes or its parameters.


- Let's assume that the load at which cables brake follows a normal distribution ($N(\mu, \sigma^2)$).

- We do not know what $\mu$ and $\sigma^2$ are.

So we **estimate** them from data.

Sample mean distributions
====================================================

- The average is defined as
</br>$\bar{x}=\frac{1}{N} \sum_{j=1..N} x_j$

where $x_j$ is the **observation** $j$ from a total of $N$. 

In terms  of the **outcomes** that categorical variables can take
</br>$\bar{x}= \sum_{i=1..m} outcome_i \frac{n_i}{N}$

from the total of $m$ values observed. When the number of observations goes to infinity then we **should** have
</br>$\bar{x} \rightarrow \sum_{i=1..m} x P(X=x)= E(X)$



Sample mean distributions
====================================================
- $\bar{x}$ is one the result of averaging the repetition of $n$- independent experiments. 

The repetition of an experiment $n$ times is called an $n$-sample. 

Remember the repetition of $n$-Bernoulli trials and counting the number of events? 

That is a Binomial experiment:  A random experiment composed of $n$ random experiment.  

- If we performed another $n$-sample then we would get another result for $\bar{x}$. 

$\bar{x}$ is the observation of one random experiment: sampling $X$ $n$-times! 


Sample mean distributions
====================================================
**Definition**

The sample mean (or average) of a **random sample** of size $n$ is defined as

$\bar{X}=\frac{1}{n}\Sigma_{i=1}^n X_i$

Our experiment with cables in stock results in the realization of this random variable 

$\bar{X}=\bar{x}_{stock}=13.21Tons$

Sample distributions functions
========================================================

<img src="./figures/sample.JPG" style="width:75%"  align="center">



Sample mean distributions
====================================================

There are two distributions:

- The population distribution: the same for each random variable $X_i$ of each random experiment.

$f_x(x)dx=P(x\leq X\leq x+dx)$

$E(X_i)=E(X)=\mu$ and $V(X_i)=V(X)=\sigma^2$

- The distribution of $\bar{X}$, that it the sample mean distribution

$f_{\bar{x}}(\bar{x})d\bar{x}=P(\bar{x}\leq \bar{X}\leq \bar{x}+d\bar{x})$

$E(\bar{X})=\mu_{\bar{X}}$ and 
$V(\bar{X})=\sigma_{\bar{X}}^2$


Sample mean distributions
====================================================

What are $\mu_{\bar{X}}$ and $\sigma^2_{\bar{X}}$, in terms of  $\mu$ and $\sigma^2$?

$E(\bar{X})=\mu_{\bar{X}}=E(\frac{1}{n}\Sigma_{i=1}^n X_i)$
</br>$=\frac{1}{n} \Sigma_{i=1}^n (X_i)$
</br>$=\frac{1}{n} \Sigma_{i=1}^n \mu$
</br>$=\mu$

This makes sense:
</br>$\mu_{\bar{X}}$ the expectation of the average is the expectation of a single experiment. This allows us to use $\bar{x}$ to **estimate** $\mu$.  


Sample mean distributions
====================================================

What is the variance of the average $\bar{X}$?
</br>$V(\bar{X})=\sigma^2_{\bar{X}}=V(\frac{1}{n}\sum_{i=1}^n X_i)=\frac{1}{n^2} V(\sum_{i=1}^n X_i)$
</br>$= \frac{1}{n^2} \sum_{i=1}^n \sigma^2=\frac{1}{n^2} n \sigma^2$
</br>$= \frac{\sigma^2}{n}$
</br>This is an important general result!


The second line 

$V(\sum_{i=1}^n X_i)=\sum_{i=1}^nV(X_i)$

follows for the independence of $n$ random variables -we are not showing



Sample mean distributions
====================================================

$V(\bar{X})= \frac{\sigma^2}{n}$
</br>As $n\rightarrow \infty$ then $\sigma^2_{\bar{X}}\rightarrow 0$

- The more repetitions we have of the experiment, the less disperse the average $\bar{X}$ is. 

- This is fully consistent with the frequentist interpretation of probabilities: the more we repeat the experiment the closer we get to the probabilities of the outcomes; in our case precise knowledge of $\mu$. 

- We have to repeat an experiment as much as possible!


Sample mean distributions
====================================================



<img src="./figures/null0.JPG" style="width:35%"  align="center">


Sample mean distributions
====================================================

Before we can use data to learn about the distributions. We are going to remain in the model (abstract) space and first answer the question: 


How does the distribution of $X$, $f_x(x)$, determines the distribution of $\bar{X}$, $f(\bar{x})$?

This question is important because if we want to use the observed value $\bar{x}$ of an $n$-sample experiment to **estimate** $\mu_X$, we need to know how $\bar{X}$ distributes so we can compute probabilities of $\bar{X}$ it-self. 


Sample mean distributions
====================================================

How is the distribution of $\bar{X}$ when $X$ comes from

- A Bernoulli trial
- A normal distribution
- Any distribution but large $n$

Sample mean distributions: Bernoulli trials
====================================================

The probability mass function of a Bernoulli random variable $X$ with values $k \in {0,1}$ defined by $A\rightarrow k=1$ and $B\rightarrow k=0$ 

$f(k)=(1-p)^{1-k} p^k$

- $p$ is the probability of $A$ and the parameter of the distribution

- $E(X)=p$ and $V(X)=p(1-p)$

Sample mean distributions: Bernoulli trials
====================================================

For a random sample $X_1, ...X_n$ of $n$ Bernoulli trials the random variable 

$Y=\sum_{i=1}^n X_i$

distributes binominaly 
</br>$Y \hookrightarrow Bin(p,n)$ and
$P(Y=i)=f(i)=\binom n i p^i(1-p)^{n-i}$ for $i=0,1,...n$

Remember

- $E(Y)=np$ 
- $V(Y)=np(1-p)$

Sample mean distributions: Bernoulli trials
====================================================

The sample mean $\bar{X}$ is simply

$\bar{X}=\frac{Y}{n}=\frac{1}{n}\sum_{i=1}^n X_i$

Then, the mean of $\bar{X}$ is

$E(\bar{X})=E(\frac{Y}{n})= \frac{np}{n}=p$
</br>$E(\bar{X})=E(X)=p$

Since $\bar{X}$ is $E(\bar{X})=E(X)=p$ we say that is $\bar{X}$ is and **unbiased** estimator of $p$.


Sample mean distributions: Bernoulli trials
====================================================
The variance of $\bar{X}$

$V(\bar{X})=V(\frac{Y}{n})= \frac{1}{n^2}V(Y)$
</br>$=\frac{p(1-p)}{n}$
</br>$=\frac{V(X)}{n}$

or in $\sigma$-notation, we recover the **general** result
</br>$\sigma^2_{\bar{X}}=\frac{\sigma^2_X}{n}$

Sample mean distributions: Bernoulli trials
====================================================

Now, we have finally built a mathematical tool that accounts for the empirical observation of probabilities. 

- When we toss a coin many times $n\rightarrow \infty$ we have a mathematical **justification** to take the average of how many heads we **observed** $\bar{x}$ to estimate the probability of heads $p$. 

Because:

- the number that we obtain $\bar{x}$ is one realization of the random variable $\bar{X}$ that has expectation $E(\bar{X})=p$.

- while the number $\bar{x}$ is not $p$ it concentrates around it as we increase $n$: $V(\bar{X})=\frac{1}{n}V(X) \rightarrow 0$ when $n \rightarrow \infty$

Sample mean distributions: Bernoulli trials
====================================================

$\lim_{n\rightarrow \infty} \bar{x} = \lim_{n\rightarrow \infty} \frac{n_{heads}}{n} = P_{heads}=p$

![plot of chunk unnamed-chunk-4](Lecture8-figure/unnamed-chunk-4-1.png)



Sample mean distributions
====================================================

How is the distribution of $\bar{X}$ when $X$ comes from

- A Bernoulli trial
- A normal distribution
- Any distribution but large $n$

Sample mean distributions: Normal
====================================================
If $X$ is a continuous random variable with normal distribution
</br>$X \rightarrow N(\mu_X, \sigma_X^2)$
with **parameters**: $\mu_X$ and $\sigma_X$.

The mean and variance of $X$ are: $E(X)=\mu$, $V(X)=\sigma^2$

- For a random sample $X_1, ...X_n$ of $n$ normal random variables, $X_i \hookrightarrow N(\mu_X, \sigma_X^2)$,  we define again the sample mean random variable 

$\bar{X}=\frac{1}{n}\sum_{i=1}^n X_i$.

How is the distribution of $\bar{X}$?

Sample mean distributions: Normal
====================================================

Imagine we **know** exactly how $X$ distributes; that is $X \rightarrow N(\mu_X, \sigma_X^2)$ and we know exactly what the values of $\mu_X$ and the variance $\sigma_X$ are

we can then show that 
</br>$\bar{X}\rightarrow N(\mu_X, \frac{\sigma_X^2}{n})$

We had already showed that in the general case </br>$E(\bar{X})=E(X)=\mu_x$ and </br>$V(\bar{X})=\frac{V(X)}{n}=\frac{\sigma_X^2}{n}$.

The tricky part is to show that the **sum** of independent **normal** variables is also a normal random variable. 


Sample mean distributions: Normal
====================================================
**Moment generating function**

We used the moment generating functio $M_x$, defined as:
</br>$M_X(t)=E(e^{tX})=\int_{-\infty}^{\infty}  e^{tx} f(x)dx$
to produce the moments by a simple differentiation:
</br>$\mu'_r =\frac{d^r M_X(t)}{dt^r}\bigm|_{t=0}$

We use the moment generating function of the normal distribution to show that the sum of independent normally distributed variables is normal.

Sample mean distributions: Normal
====================================================
Sketch of the prof (additional material):

- The moment generating function for a standard distribution $N(\mu,\sigma^2)$ can be obtained by integration:
</br>$M_{X}(t)=\int_{-\infty}^{\infty}  e^{tx} \frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma}}dx=e^{t\mu+\frac{1}{2}\sigma^2t^2}$

- for $X_1, .... X_n$ random independet variables we have
$df(x_1,x_2,..,x_n)=f(x_1)f(x_2)..f(x_n)dx_1..dx_n$
The moment generating function for $\sum_i X_i$ is then

$M_{\sum_i X_i}(t)=E(e^{t\sum_i x_i})=\int_{-\infty}^{\infty}  e^{t(x_1+..+x_n)} f(x_1)..f(x_n)dx_1..dx_n$
</br>$=\Pi_{i=1}^{n} M_{X_i}(t)=\Pi_{i=1}^{n} e^{t\mu+\frac{1}{2}\sigma^2t^2}$
</br>$= e^{\sum_i t\mu+\sum_i \frac{1}{2}\sigma^2t^2}= e^{nt\mu+\frac{1}{2}(n\sigma^2) t^2 }$

this is the moment generation function of a normal distribution
</br>$\sum_{i=1}^n x_i \hookrightarrow N(n\mu, n\sigma^2)$


Sample mean distributions: Normal
====================================================

- The sum $\sum_{i=1}^n X_i$ of $n$ random normally distributed variables $X_1$,...$X_n$ all with mean $\mu_X$ and variance $\sigma^2_X$ is a normal distribution: 

$\sum_{i=1}^n X_i \hookrightarrow N(n*\mu_X, n*\sigma_X^2)$ with 
</br>$E(\sum_{i=1}^n X_i)=n*\mu_X$ 
</br>$V(\sum_{i=1}^n X_i)=n*\sigma_X$

- Since the sample mean is $\bar{X}=\frac{1}{n}\sum_{i=1}^n X_i$ then </br>$\bar{X}\hookrightarrow N(\mu_X, \frac{\sigma_X^2}{n})$, with  </br>$E(\bar{X})=\frac{n}{n}E(X)=\mu_X$ </br>$V(\bar{X})=nV(\frac{1}{n}\sum_{i=1}^n X_i)=\frac{n}{n^2}\sigma^2_X=\frac{\sigma^2_X}{n}$

Sample mean distributions: Normal
====================================================

Imagine we **knew** that our cables' braking load distributes normally with a mean of 13 Tons and a standard deviation of 0.35.

- What is the probability that one cable breaks at 12 Tons?

The population mean is 
$\mu_X=13$ and the standard deviation is $\sigma_X=0.35$

We want to compute $P(X\leq 12)$
</br>$P(X\leq12 T)=P(\frac{X-\mu_X}{\sigma_X} \leq \frac{12-\mu_X}{\sigma_X})$

Let's standardize 
$P(Z \leq \frac{12-\mu_X}{\sigma_X})=\Phi(\frac{12-\mu_X}{\sigma_X})$, where  $\Phi$ is the cumulative probability function for the standard distribution, as  $Z \hookrightarrow N(0,1)$.

Replacing $\Phi(-2.857143)=0.002$. The probability that one cable breaks is 0.2%.



Sample mean distributions: Normal
====================================================

For the sample mean

- What is the probability that the 8-sample mean is lower than 12 Tons?

The **sample** mean is 
$E(\bar{X})=13$
and its the standard deviation is 
$\sigma_\bar{X}=\sigma_X/\sqrt{n}=0.35/\sqrt{8}=0.1237437$

We want to compute $P(\bar{X}\leq 12)$

$P(\bar{X}\leq12 T)=P(\frac{X-\mu_\bar{X}}{\sigma_\bar{X}} \leq \frac{12-\mu_\bar{X}}{\sigma_\bar{X}})=P(Z \leq \frac{12-\mu_\bar{X}}{\sigma_\bar{X}})$

Since $\bar{X}$ distributes normally then $Z$ follows a standard distribution and
</br>$P(Z \leq \frac{12-\mu_\bar{X}}{\sigma_\bar{X}})=\Phi(-8.08)\sim 0$


Sample mean distributions: Normal
====================================================

However, what if they want to use the 8 cables to carry 8*12=96 tons. What is the probability that the 8 cables can carry that load?

- The **sum** $Y=\sum_{i=1}^8 x_i$ mean is 
$E(Y)=8*13=104$
and the standard deviation 
$\sigma_Y=n\sigma_X=8*0.35=2.8$


We want to compute $P(Y\leq 12)$
</br>$P(Y\leq12 T)=P(\frac{Y-\mu_Y}{\sigma_Y} \leq \frac{12-\mu_Y}{\sigma_Y})=P(Z \leq \frac{12-\mu_Y}{\sigma_Y})$

and because $Y$ also distributes normally then 

$\Phi(-2.857143)= 0.002$

Sample mean distributions
====================================================

How is the distribution of $\bar{X}$ when $X$ comes from

- A Bernoulli trial
- A normal distribution
- Any distribution but large $n$

Sample mean distributions: Large n
====================================================

- Let's relax the condition that the random variable $X$, from which the n-sample is taken, is normal. 

- Instead, imagine that we take many samples $n\rightarrow \infty$ 

Under this condition how does $\bar{X}$ distributes?

Sample mean distributions: Large n
====================================================

**Central Limit Theorem (CLT)** (we won't prove*)

For a random sample $X_1,...X_2$ on a population distribution of the variable $X$ with mean $\mu_X$ and variance $\sigma_X^2$ then the standardized variable of $\bar{X}$ given by 
</br> $Z=\frac{\bar{X}-E(\bar{X})}{\sqrt{V(\bar{X})}}=\frac{\bar{X}-\mu_X}{\sigma_X/\sqrt{n}}$
follows a standard distribution; that is

$Z\hookrightarrow N(0,1)$,

when $n\rightarrow \infty$

(*a prove using moment generating functions can be found in Freund's Mathematical Statistics with applications)


Sample mean distributions: CLT
====================================================
The central limit theorem:

$Z=\frac{\bar{X}-\mu_X}{\sigma_X/\sqrt{n}} \rightarrow N(0,1)$
when $n\rightarrow \infty$

Justifies the approximation of 

$\bar{X}\sim N(\mu_X, \frac{\sigma_X^2}{n})$
when $n >30$


Sample mean distributions: CLT
====================================================

The central limit theorem tells us that:

- the distribution of $\bar{X}$ can be **approximated** by a normal distribution for large values of $n$

- no matter what the population distribution $f_X$ is; that is, how measurements $X_i$ distribute

Note that when $X$ **actually** distributes normally then the distribution of $\bar{X}$ is **exactly normal**, as we previously showed.

Sample mean distributions: CLT
====================================================
Let's see an application of the central limit theorem to the binomial distribution


We are going to show that the Binomial distribution tends to the Normal distribution when the number of Bernoulli trials is large. 

Let's consider the randon variable $Y$ that follows a binomial distribution </br>$Y\hookrightarrow Bin(n,p)$, that is

$P(Y=y)=f(y)=\binom n y p^y(1-p)^{n-y}$ $y=0,1,...n$


Sample mean distributions: CLT
====================================================

Let's standardize $Y$

</br>$Z=\frac{Y-E(Y)}{\sqrt{V(Y)}}=\frac{Y-np}{\sqrt{np(1-p)}}$

because $E(Y)=np$ and $V(Y)=np(1-p)$

divide by $n$ both the numerator and the denominator
$Z=\frac{Y/n-p}{\sqrt{p(1-p)}/\sqrt{n}}$

Now, $Y$ can be written as
</br>$Y=\sum_{i=1}^n x_i$ 
</br>where $X$ is a Bernulli trial $P(X=x)=p^x(1-p)^{1-x}$, $x=0,1$ 

Therefore $Y/n=\frac{1}{n}\sum_{i=1}^n x_i=\bar{X}$

Sample mean distributions: CLT
====================================================

So we can write 
</br>$Z=\frac{Y/n-p}{\sqrt{p(1-p)}/\sqrt{n}}$
as
</br>$Z=\frac{\bar{X}-p}{\sqrt{p(1-p)}/\sqrt{n}}=\frac{\bar{X}-\mu}{\sigma/\sqrt{n}}$

This is clearly the normalization of $\bar{X}$ the **sample** of **n** independent Bernulli trials each with mean $p$ and variance $p(1-p)$.

Therefore by the central limit theorem
</br>$Z\rightarrow N(0,1)$
when $n\rightarrow \infty$

and

-  the distribution of $\bar{X}$ can be approximated by
</br>$\bar{X} \sim N(p,p(1-p)/n)$



Sample mean distributions: CLT
====================================================

- the distribution of $X$ can **also** be approximated by
</br>$X \rightarrow Bin(n,p)\sim N(np,np(1-p))$

because they share the same estandardized statistic $Z$

Therefore we have the approximation of one distribution into another

$Bin(n,p)\sim N(np,np(1-p))$

Which is consider good when $n>30$ and both $np$ and $n(1-p)$ are both greater than 5



Sample mean distributions
====================================================

Summary:

When $X$ comes from

- A Bernoulli trial then 

$\bar{X} \hookrightarrow Bin(n,p)$

- A normal distribution then 

$\bar{X} \hookrightarrow N(\mu_X,\sigma^2_X/n)$

- Any distribution but large $n>30$  then 

$\bar{X} \sim N(\mu_X,\sigma^2_X/n)$


Sample variance distribution
====================================================

Our intention is to take one observed value of $\bar{X}$ (big $X$); that is  $\bar{x}$ (litte $x$), as an experimental **estimate** of for $\mu$. 

- That is enough when $X$ follows a Bernulli trial distribution, where we have only one parameter $p$, $E(\bar{X})=\mu_\bar{X}=\mu_X=p$

- When $X$ follows a normal distribution we have two parameters $\mu_X$ and $\sigma_X$.

As $E(\bar{X})=\mu_X$, could we also take $V(\bar{X})$ as a mesurement of $\sigma$?

</br>$V(\bar{X})=E[(\bar{X}-\mu)^2]$

But we don't know $\mu$! and it gives us the dispersion of $\bar{X}$ about the mean not the dispersion of the $x_i$. 


Sample variance distribution
====================================================

**Definition**

The **sample variance** $S^2$ is the **random variable**, function of the $n$-random sample $X_1, ...X_n$, given by  
</br>$S^2= \frac{1}{n-1}\sum_{i=1}^n (X_i-\bar{X})^2$

- $S^2$ (big $S$) is the random variable and $s^2$ (little $s$) is the **observation** of $S^2$.

- $s^2$ is the **sample** variance and it is computed from **data** (little $x_i$ and $\bar{x}$) as:
</br>$s^2= \frac{1}{n-1}\sum_{i=1}^n (x_i-\bar{x})^2$ 
its square root is the standard deviation of the sample $s$.

- $S^2$ is the average distances of the observations to $\bar{X}$ (except it is divided by n-1). $S$ is known as the **standard error**

Sample variance distribution
====================================================

Remember that $\bar{X}$ disperses around $\mu_X$ with variance $\sigma^2_X/n$. To estimate the dispersion of the measurements around $\mu_X$ then we need to correct for the deviation given by $\bar{X}$.


![plot of chunk unnamed-chunk-5](Lecture8-figure/unnamed-chunk-5-1.png)

Sample variance distribution
====================================================

Let's compute the expected value of $S^2$

$E(S^2)=E[\frac{1}{n-1}\sum_{i=1}^n (X_i-\bar{X})^2]$
</br>$=\frac{1}{n-1}E[\sum_{i=1}^n \{(X_i-\mu)-(\bar{X}-\mu)\}^2]$
</br>$=\frac{1}{n-1}E[\sum_{i=1}^n \{(X_i-\mu)^2-2(X_i-\mu)(\bar{X}-\mu)+(\bar{X}-\mu)^2\}]$
</br>$=\frac{1}{n-1}E[\sum_{i=1}^n (X_i-\mu)^2-2(\bar{X}-\mu)\sum_{i=1}^n\{(X_i-\mu)\}+(\bar{X}-\mu)^2]$
</br>$=\frac{1}{n-1}E[\sum_{i=1}^n (X_i-\mu)^2-2n(\bar{X}-\mu)^2+n(\bar{X}-\mu)^2]$
</br>$=\frac{1}{n-1}\sum_{i=1}^n E[(X_i-\mu)^2]-E[2n(\bar{X}-\mu)^2]+E[n(\bar{X}-\mu)^2]$
</br>$=\frac{1}{n-1}[n\sigma_X^2- n \frac{\sigma_X^2}{n} ]=\sigma_X^2$

$S^2$ is an **unbiased** estimator $\sigma_X^2$!

Sample variance distribution
====================================================


For our experiment of 8 cables breaking loads we have

- $\bar{x}=13.21\,\,Tons \sim \mu_X$, (simulated $\mu_X=13$)

- $s^2=0.127\,\,Tons^2 \sim \sigma^2_X$, (simulated $\sigma^2_X=0.1225$)

As, we **assume** that $X \hookrightarrow N(\mu_X,  \sigma^2_X)$, then $\bar{X} \hookrightarrow N(\mu_X,  \sigma^2_X/\sqrt{n})$.

How does $S^2$ distribute?

Sample variance distribution
===================================================

For a random sample $X_1,...X_n$ with a normal population distribution $X_i \hookrightarrow N(\mu_X, \sigma_X^2)$ the random variable defined by 
</br>$Y=\frac{(n-1)S^2}{\sigma_X^2}$

has a $\chi^2$ (chi-squared) distribution with $df=n-1$ degrees of freedom given by

$f(y)=C_n  y^{\frac{n-3}{2}} e^{-\frac{y}{2}}$

where:

- $C_n=\frac{1}{2^{(n-1)/2\sqrt{\pi(n-1)}}}$ ensures  $\int f(t)dt=1$
- $\Gamma(x)$ is Euler's factorial for real numbers 

 
Sample variance distribution
====================================================

Note that the distribution is for $Y=\frac{(n-1)S^2}{\sigma_X^2}$
and not for $S^2$

- What is the probability that the sample variance of the 8 cables we sold is greater than $0.2\,\,Tons^2$?

 We compute $P(S^2 > 0.2)=P(\frac{(n-1)S^2}{\sigma_X^2} > \frac{(n-1)0.2}{\sigma_X^2})=P(Y > \frac{(n-1)0.2}{\sigma_X^2})$
</br> $=1-P(Y \leq \frac{(n-1)0.2}{\sigma_X^2})=1-P(Y\leq \frac{(8-1)0.2}{0.1225})$
</br> $= 1- F_{chi^2,df=7}(11.42857)=0.12$

There is a probability of $12\%$ of obtaining a value of $s^2=0.2$ in 8 cables.

Sample variance distribution
====================================================

In R we compute the cumulative probability function of a $\chi^2$ density function with $df=n-1$ degrees of freedom using the function <code>pchisq(y,df)</code>

In tables: $P(Y > \chi^2_{0.05,7})=1-F(\chi^2_{0.05,7})$ 

<img src="./figures/chi.png" style="width:50%"  align="center">
