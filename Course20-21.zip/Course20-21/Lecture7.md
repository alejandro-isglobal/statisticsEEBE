Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 7</p>

Objective
========================================================

Discrete probability models

- Poisson probability function

Continuous probability models

- Exponential probability density function
- Normal probability density function

Bernoulli distribution
========================================================

When we have two different outcomes and allow the probability of one ($k=1$) to be a parameter $p$, we have the Bernoulli probability function
</br>$f(k)=(1-p)^{1-k} p^k$.

As the parameter $p$ is allowed to change then the Bernoulli is really a **family** of distributions. 

We will posit our confidence in the knowledge of a Bernoulli trial in the knowledge of $p$.

Binomial distribution
========================================================

The binomial probability function is the probability mass function of observing $k$ outcomes of type $A$ in $n$ independent Bernoulli trials, where $A$ has the same probability $p$ in each trial. The function is given by

$f(k)=\binom n k p^k(1-p)^{n-k}$, $k=0,1,...n$

A binomial experiment is a random experiment made of multiple more basic random experiments (Bernoulli trials).


Discrete probability models
========================================================

We are building up more complex models from simple ones:

**Uniform**: Classical interpretation of probability 
</br>$\downarrow$ 
</br>**Bernoulli**: Introduction of a **parameter** $p$ (family of functions)
</br>$\downarrow$ 
</br>**Binomial**: **Repetition** of a random experiment ($n$-times Bernoulli trials)
</br>$\downarrow$ 
</br>**Poisson**: repetition of random experiment within an continuous interval (having **no control** on when/where to repeat the experiment).  


Poisson distribution
========================================================

Imagine that we are observing events that **depend** on time or distance **intervals**.
- cars arriving at a traffic light
- getting messages on your mobile phone
- flaws occurring at random in a copper wire

Suppose that the events are outcomes of **independent** random experiments each appearing randomly on a continuous interval. 

Poisson distribution
========================================================

- When we studied the binomial process we thought of repeating the flip of a coin $n$ times. 

- We implicitly assumed that we **controlled** when the repetitions occurred. 

- Now we consider another layer of randomness: we do not control when the flip of the coin happens!


Poisson distribution
========================================================
What is the probability of observing $X$ events in an interval's unit (time or distance)?

Imagine that some impurities in a copper wire deposit randomly along a wire 

- at each centimeter, you would count an average of $\lambda=10/cm$.
- divide the centimeter into micrometers ($0.0001cm$) 

Poisson distribution
========================================================
micrometers are small enough so 
- either there is or there is not an impurity in each micrometer
- each micrometer can be considered a **Bernoulli trial**


<img src="./figures/poiss.JPG" style="width:75%" style="height:100%"  align="center">

Poisson distribution
========================================================

The probability of observing $X$ impurities in $n=10,000\mu$ (1cm)  approximately follows a binomial distribution

$P(X=x)=\binom n x p^x(1-p)^{n-x}$

where $p$ is the probability of finding an impurity in a micrometer. 

Remember that
$E(X)=np$
so for $\lambda=np$ (average number of impurities per 1cm), we can write

$P(X=x)=\binom n x \big(\frac{\lambda}{n}\big)^x(1-\frac{\lambda}{n})^{n-x}$

Poisson distribution
========================================================

- There **could** still be two flaws in a micrometer so we need to increase the partition of the wire ($n$).

- The Bernoulli trials are only true in the limit ($n \rightarrow \infty$).

$P(X=x)=\binom n x \big(\frac{\lambda}{n}\big)^x(1-\frac{\lambda}{n})^{n-x}$

Where $\lambda$ is constant because it is the density of flaws per centimeter, given by $E(X)$.



Poisson distribution
========================================================

$P(X=x)=\binom n x \big(\frac{\lambda}{n}\big)^x(1-\frac{\lambda}{n})^{n-x}$

in the limit ($n \rightarrow \infty$)

- $\frac{1}{n^x}\binom n x =\frac{1}{n^x}\frac{n!}{x! (n-x)!}=\frac{(n-x)!(n-x+1)...(n-1)n}{n^x x! (n-x)!}=\frac{n(n-1)..(n-x+1)}{n^x x!} \rightarrow \frac{1}{x!}$
- $(1-\frac{\lambda}{n})^{n} \rightarrow e^{-\lambda}$ (definition of exponential)
- $(1-\frac{\lambda}{n})^{-x} \rightarrow 1$

Therefore
$P(X=x)= \frac{e^{-\lambda}\lambda^x}{x!}$

Poisson distribution
========================================================

**Definition**

Given

- an interval in the real numbers 
- counts occur at random in the interval 
- the average number of counts on the interval is known ($\lambda$)
- if one can find a small regular partition of the interval such that each of them can be considered Bernoulli trials  

Then...

Poisson distribution
========================================================

**Definition**

The random experiment of counting across the interval is a **Poisson** process and the counts $X$ follow the probability mass function  
$f(x)= \frac{e^{-\lambda}\lambda^x}{x!}, \lambda>0$

Poisson distribution
========================================================


![plot of chunk unnamed-chunk-1](Lecture7-figure/unnamed-chunk-1-1.png)



Poisson distribution
========================================================

![plot of chunk unnamed-chunk-2](Lecture7-figure/unnamed-chunk-2-1.png)

Poisson distribution
========================================================

for the Poisson distribution
</br>$f(x)=\frac{e^{-\lambda}\lambda^x}{x!}, \lambda>0$

we have 

- mean $E(X)= \lambda$
- variance $V(X)= \lambda$

That can be obtained by the moment generation function $M_X(t)=E[e^{tx}]$. 

Poisson distribution
========================================================

The average number of radioactive particles hitting a Geiger  counter is 2.3 seconds. 

What is the probability of counting exactly 2 particles in a second?

$f(x; \lambda)=\frac{e^{-\lambda}\lambda^x}{x!}, \lambda>0$

$f(2, \lambda=2.3)=\frac{e^{-2.3}2.3^2}{2!}=0.26, \lambda=2.3\, counts/s$

Poisson distribution
========================================================

The average number of radioactive particles hitting a Geiger counter is 2.3 counts/second. 

What is the probability of counting exactly detecting 10 particles in 5 seconds?

$f(x; \lambda)=\frac{e^{-\lambda}\lambda^x}{x!}, \lambda=2.3\, counts/s$


Then the random variable $Y$ that counts how many particles hit the detector every 5 seconds has a mean

$\lambda_{5s}=E(Y)= 5 \times 2.3\, counts/5s=11.5 \, counts/5s$

and distributes:

$f(y; \lambda_{5s})=\frac{e^{-\lambda_{5s}}\lambda_{5s}^x}{x!}, \lambda_{5s}=11.5 \, counts/5s$


$f(y=10; \lambda_{5s})=\frac{e^{-11.5}11.5^{10}}{{10!}}=0.11, \lambda=11.5 \,counts/5s$



Poisson distribution
========================================================

What is the probability of at least one count in two seconds?


The average counts per 2 seconds 

$\lambda_{2s}=E(Z)= 2 \times 2.3 \, counts/2s=4.6 \, counts/2s$

which is the mean of the the random variable $Z$ that counts how many particles hit the detector every 2 seconds. $Z \hookrightarrow Poiss(\lambda_{2s})$ and 

$P(Z > 0)=1-F_{Pois}(0; \lambda_{2s})=1-f(0; \lambda_{2s})=1-e^{-4.6}=0.98 \nonumber$



Continuous probability models
========================================================

Continuous probability models follow from considering probability density functions $f(x)$ of a continuous random variable $X$ that we **believe** describe processes like real random experiments.

Definition:

- $f(x) \geq 0$
- $\int_{-\infty}^{\infty} f(x) dx = 1$
- $P(a\leq X \leq b)=\int_{a}^{b} f(x) dx$

Continuous probability models
========================================================

- remember that these are abstract objects and may or may not represent any natural/engineered process. 


- as in the discrete case we will build up the models from the basic requirements of what we believe natural natural processes could satisfy. 



Exponential distribution
========================================================

Let's go back to the Poisson distribution for the number of counts ($k$) in an interval

$f(k)=\frac{e^{-\lambda}\lambda^k}{k!}, \lambda>0$ 

Remember that we introduced additional randomness at which the Bernoulli trials happen, but still expected that within an interval we know the average number of trials $\lambda$.


Exponential distribution
========================================================

- Let's now consider only two different consecutive (length/time) trials. 

- the distance between them is a **continuous** random variable.


We can ask for the probability that two events are distanced $X$. 


Exponential distribution
========================================================

When we asked for the probability across different intervals lengths we had to re-escale $\lambda$ in some units by the interval of interest

$E_x(K)=x \lambda$

$K$ is now in $x$ units of $\lambda^{-1}$ and where $x$ is the length of the new interval. $K$ is therefore the number of events in the interval $x$.

$f(k)=\frac{e^{-x\lambda}{(x\lambda)}^k}{k!}, x\lambda>0$

Let us consider an interval of size $x$ that measures the length between any two events (say between 0 counts and 1 count).


What is the probability of counting less than one event in the interval x?



Exponential distribution
========================================================

The distribution is of the form

$f(k=0;x)= \frac{e^{-x\lambda}{(x\lambda)}^0}{0!}=e^{-\lambda x}$

Let's think of $x$ as the result of measuring the interval we need to wait between two counts (in units of $\lambda^{-1}$).  The interval $X$ is a random variable and $x$ is one value of an experiment. 

Exponential distribution
========================================================

What is the probability of observing $x$ as the interval with no counts? We want the probability on $x$; $f(x;k=0)$

The distribution is of the form

$P(X=x) = f(x; k=0) dx = \frac{f(k;x)f(x)}{f(k=0)}$

We can consider that the marginal probability of observing $f(x)$ is a constant: it is the probability of selecting an interval of size $x$ randomly, not conditioned to the Poisson process. Therefore,

$P(X=x) = f(x; k=0) dx = C e^{-\lambda x}$

$C$ is a constant that ensures: $\int f(x; k=0) dx =1$, then by integration $C=\lambda$

We have seen this distribution before!

Exponential distribution
========================================================

A line production process requires to drill a hole of $12.5mm$ in a metallic disc. Sometimes the drill moves and opens slightly larger holes 

-  We **believed** that $$f(x)=20 e^{-20(x-12.5)}$$ for $12.5 \leq x$ and  $f(x)=0$ for $x\leq 12.5$ 

we changed the variable: $z=x-12.5$ and $\lambda=20$

$f(z)=\lambda e^{-\lambda z}, z\geq 0$


Exponential distribution
========================================================

For the exponential distribution 
$f(z)=\lambda e^{-\lambda z}, z\geq 0$

we showed 

- Mean: $\mu_z=E(Z)=\frac{1}{\lambda}$ 

 
- Variance: $V(Z)=\frac{1}{\lambda^2}$

Exponential distribution
========================================================

What is the probability of observing $x$, as the interval between 0 and 1 counts? 

The distribution is then

$f(x)=\lambda e^{-x\lambda}$

and the probability on a small $dx$ is 

$P(x\leq X\leq x+dx)=\lambda e^{-x\lambda}dx,  0\leq x\leq \infty$

Where $E(X)=1/\lambda$ and $V(X)=1/\lambda^2$

Exponential distribution
========================================================

Note: the exponential distribution can describe the drilling of a whole or the times (distances) between Poisson counts.

- Probability models can be used to describe very different natural/engineered processes. 

- The main challenge in real-world statistics: 

Which model to chose in a particular experiment? 


Uniform distribution
========================================================

A probability density function can also be obtained from the discrete uniform probability function 

- $n$ outcomes have each $P(X=x)=1/n$  
- when $n \rightarrow \infty$

If $X$ takes values in $(a,b)$, the probability density will be constant on the interval
\[
    f(x)= 
\begin{cases}
    \frac{1}{b-a},& \text{if } x\in (a,b)\\
    0,& otherwise 
\end{cases}
\]

Uniform distribution
========================================================

<img src="./figures/unifc.png" style="width:50%"  align="center">

Uniform distribution
========================================================

What are the mean and variance of the uniform distribution?

- For the mean we have
</br>$E(X)=\int_{a}^{b} \frac{1}{b-a} x dx$
</br>$=\frac{1}{2}\frac{x^2}{b-a}\big|_a^b=\frac{a+b}{2}$

- For the variance we have
</br>$V(X)=\int_{a}^{b} \frac{1}{b-a} (x-\mu)^2 dx$
</br>$=\frac{1}{3}\frac{\big(x -\frac{a+b}{2}\big)^3}{b-a}\big|_a^b=\frac{(b-a)^2}{12}$

the same as the discrete case! because $E(X)$ and $V(X)$ do not depend on $n$.


Normal distribution
========================================================

- The normal density probability function is the Queen of the distributions

- Discovered by the prince of mathematics Carl Friedrich Gauss

- It also called the Gaussian distribution

Normal distribution
========================================================

In 1801 Gauss analyzed the orbit of Ceres (large asteroid between Mars and Jupiter). 

- People suspected it was a new planet.
- The measurements had errors. 
- He was interested in finding how the observations were distributed so he could find the most probable orbit.
- He wanted to predict where astronomers could point their telescopes to find it after it cross in front of the Sun.



Normal distribution
========================================================

<img src="./figures/ceres.JPG" style="width:75%"  align="center">


Normal distribution
========================================================

He assumed that  

- small errors were more likely than large errors 
- error at a distance $-\epsilon$ or $\epsilon$ from the most likely measurement were equally likely 
- the most **likely** altitude of Ceres at a given time in the sky was the **average** of multiple altitude measurements at that latitude.


Normal distribution
========================================================

That was enough to show that the random deviations $y$ **from the orbit** distributed like

$f(y)=\frac{h}{\sqrt{\pi}}e^{-h^2y^2}$

*The evolution of the Normal distribution, Saul Stahl, Mathematics Magazine, 2006.

Normal distribution
========================================================

$f(y)=\frac{h}{\sqrt{\pi}}e^{-h^2y^2}$

Let's write it in a more general form:

Imagine measurements $X$ for the altitude of Ceres from an origin (horizon) that concentrate around a value $x_0$, then $y=x-x_0$. If $x$ is one measurement of altitude from the horizon then its probability density function is 

$f(x)=\frac{h}{\sqrt{\pi}}e^{-h^2(x-x_0)^2}$

and its mean is:
</br>$E(X)=\int_{-\infty}^{\infty} x \frac{h}{\sqrt{\pi}}e^{-h^2(x-x_0)^2}dx =x_0$

Wich can be proven by its moment generating function:

$M_X(t)= E(e^{tx})=e^{x_0 t+\frac{t^2}{2h^2}}$; $M'_X(t)=E(X)=\mu=M_X(t)(x_0+\frac{t}{2h^2})\Big|_{t=0}=x_0$

Normal distribution
========================================================
And, for the variance, we find: 

$E(X^2)=M''_X(t)(\mu^2+\frac{1}{2h^2})\Big|_{t=0}=\mu^2+\frac{1}{2h^2}$

and since
$E(X^2)=V(X)+\mu^2=\sigma^2+\mu^2$ then $\sigma^2=\frac{1}{2h^2}$

Replacing the values of $\mu=x_0$ and $h^2=\frac{1}{2\sigma^2}$ in $f(x)$ we can write the normal density function of **parameters** $\mu$ and $\sigma$

$f(x; \mu, \sigma^2)=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}, x \in {\Bbb R}$

with mean $E(X)=\mu$ and variance $V(X)=\sigma^2$.


Normal distribution
========================================================

**Definition**

A random variable X defined in the real numbers has a  **Normal** density distribution if its distribution takes the form

$f(x; \mu, \sigma^2)=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}, x \in {\Bbb R}$

When $X$ follows a Normal distribution we write
$X\hookrightarrow N(\mu,\sigma^2)$


Normal distribution
========================================================
Remember the higher-order moments respect the mean

- Skewness:$\frac{\mu_3}{\sigma^3}$
- kurtosis: $\frac{\mu_4}{\sigma^4}$

For the Normal distribution

- Skewness:$\frac{E(x-\mu)^3}{\sigma^3}=0$ (It is symmetric!)
- kurtosis: $\frac{E(x-\mu)^4}{\sigma^4}=\frac{3\sigma^4}{\sigma^4}=3$


Normal distribution
========================================================


![plot of chunk unnamed-chunk-3](Lecture7-figure/unnamed-chunk-3-1.png)


Normal distribution
========================================================

Remember our motivations for Chebyshev's theorem. 

We wanted to know if

- the outcomes should concentrate on probability around the mean 
- the outcomes should decrease in probability far from the mean.

Theorem:
$P(|X -\mu| \geq a\sigma) \leq \frac{1}{a^2}$


Normal distribution
========================================================

| a | Chebyshev's rule for any prob distribution | $N(\mu, \sigma)$ |
| ------- | ---------------------- | ---------------------- |
| 0 | less than 100% | $P(|X -\mu| \geq 0)=0.5$ |
| 1 | less than 100% | $P(|X -\mu| \geq 1\sigma)=0.317$ |
| 1.5 | less than 44% | $P(|X -\mu| \geq 1.5\sigma)=0.1373$ |
| 2 | less than 25% | $P(|X -\mu| \geq 2\sigma)=0.045$ |
| 3 | less than 11.1% |$P(|X -\mu| \geq 3\sigma)=0.0026$ |
| 4 | less than 6.3% | $P(|X -\mu| \geq 4\sigma)=6.3\times 10^{-5}$ |

Normal distribution
========================================================

- $\mu$ splits the measurements in two 
- $x$ values that fall farther than 2$\sigma$ are considered **rare** $5\%$
- $x$ values that fall farther than 3$\sigma$ are considered **extremely rare** $0.2\%$

Normal distribution
========================================================

<img src="./figures/probs.png" style="width:50%"  align="center">

Normal distribution
========================================================

$f(x; \mu, \sigma^2)=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}, x \in {\Bbb R}$

Changing variables to a **standardized variable** 

$Z=\frac{X-\mu}{\sigma}$

replacing $x=\sigma z+\mu$ and $dx=\sigma dz$ in the probability expression

$P(x\leq X \leq x +dx)=P(z\leq Z \leq z +dz)$
</br>$=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}dx=\frac{1}{ \sqrt{2\pi}}e^{-\frac{z^2}{2}} dz$

we obtain the **standardized** form of the normal distribution.

Normal distribution
========================================================

**Definition**

A random variable $Z$ defined in the real numbers has a  **standard** density distribution if its distribution takes the 

$f(z)=\frac{1}{\sqrt{2\pi}}e^{-\frac{z^2}{2}} dz,z \in {\Bbb R}$


Normal distribution
========================================================

</br>$f(z)=\frac{1}{\sqrt{2\pi}}e^{-\frac{z^2}{2}} dz,z \in {\Bbb R}$

- the standard distribution is the normal distribution $N(\mu=0,\sigma^2=1)$
- any normally distributed variable $X$ can be transformed to a variable $Z$ that distributes normally by standardization $Z=(x-\mu)/\sigma$


Normal distribution
========================================================

The cumulative probability function of the standard distribution is the **error** function defined by 

$\Phi (z)=P(Z\leq z)=\int_{-\infty}^{z} \frac{1}{\sqrt{2\pi}}e^{-\frac{z^2}{2}} dz$

<img src="./figures/st.png" style="width:75%" style="height:100%"  align="center">

You can find it tabulated or in computer programs


Normal distribution
========================================================

![plot of chunk unnamed-chunk-4](Lecture7-figure/unnamed-chunk-4-1.png)


Normal distribution
========================================================


For any normally distributed variable $X$, such that 

$X\hookrightarrow N(\mu, \sigma^2)$

its cumulative distribution can be computed from 

$F(x)= \Phi \big(\frac{x-\mu}{\sigma}\big)$

Standard distribution
========================================================

For computing $P(a\leq X \leq b)$, we use the property of the cumulative distributions 

$P(a\leq X \leq b) = F(b)-F(a)=P(X\leq b)-P(X\leq a)$

Let's standardize

$=P(\frac{X-\mu}{\sigma}\leq \frac{a-\mu}{\sigma})-P(\frac{X-\mu}{\sigma}\leq \frac{b-\mu}{\sigma})$
</br>$=P(Z \leq \frac{b-\mu}{\sigma})-P(Z \leq \frac{a-\mu}{\sigma}\big)$
</br>$=\Phi \big(\frac{b-\mu}{\sigma}\big)-\Phi \big(\frac{a-\mu}{\sigma}\big)$

Standard distribution
========================================================

All normal distributions can be obtained from the standard distribution with the values of $\mu$ and $\sigma$


<img src="./figures/stand.png" style="width:50%" style="height:100%"  align="center">



Normal distribution
========================================================

Why is the normal distribution so important?

- The average of the measurements of many random variables can be approximated by a normal distribution (it doesn't matter how the measurements distribute themselves) 

- Binomial and Poisson processes with many trials ($n \rightarrow \infty$) tend to the normal distribution 




Summary of probability models
========================================================


| Model | outcome    | x  |  f(x) | E(X) | V(X) |
| ----------- | ------------- | ------ | ----- | ---- | ---- |
| Uniform | $n$ discrete values | a,... b| $\frac{1}{n}$ |$\frac{b+a}{2}$ |  $\frac{(b-a+1)^2-1}{12}$ | 
| Bernoulli             | A event | 0,1 | $p^x(1-p)^{1-x}$ | $p$ | $p(1-p)$ |
| Binomial | \# of A events | 0,1,...| $\binom n x p^x(1-p)^{n-x}$ | $np$ | $np(1-p)$ |
| Geometric | \# of B events until event A | 0,1,...|$p(1-p)^{x}$| $\frac{1-p}{p}$ |$\frac{1-p}{p^2}$ |
| Shifted geometric | \# of **trials** until event A | 1,2,...| $p(1-p)^{x-1}$ | $\frac{1}{p}$ | $\frac{1-p}{p^2}$ |
| Negative Binomial | \# of B events until r A events | 0,1,.. |$\binom {x+r-1} x p^r(1-p)^x$ | $r\frac{1-p}{p}$ | $r\frac{1-p}{p^2}$ |
| Hypergeometric | \# of A events in a sample $n$ |$\max(0, n+K-N)$, ... $\min(K, n)$ | $\frac{1}{\binom N n}\binom K x \binom {N-K} {n-x}$ | $np$ | $np(1-p)\frac{N-n}{N-1}$ |
| Poisson | \# of A events in an interval | 0,1, ..| $\frac{e^{-\lambda}\lambda^x}{x!}$ | $\lambda$ | $\lambda$ |
| Exponential | Interval between two events A | $[0,\infty)$ | $\lambda e^{-\lambda x}$ | $\frac{1}{\lambda}$ | $\frac{1}{\lambda^2}$ |
| Normal | measurement with symmetric errors whose most likely value is the average  | $(-\infty, \infty)$|$\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}$ | $\mu$ |$\sigma^2$ |



