Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 11</p>


Objective
========================================================


- Hypothesis 
- Hypothesis testing


Estimation
========================================================

From data, we can estimate

-  the mean $\mu$ by $\bar{x}$ 
-  the random confidence interval by 
$CI=(l,u)=(\bar{x}-z_{\alpha/2} \frac{\sigma}{\sqrt{n}}, \bar{x}+z_{\alpha/2}  \frac{\sigma}{\sqrt{n}})$

When we believe that the random variable follows a normal distribution and we know the variance.  

Estimation
========================================================

<img src="./figures/obs.png" style="width:50%"  align="center">



Estimation
========================================================

However, we do not (**will never**) know where the true sample and population distribution are.

All these sample distributions could produce the observed mean.

<img src="./figures/obs2.png" style="width:50%"  align="center">




Hypothesis
========================================================


Whenever we take measurements we have and ``idea'' of what we want to do with them

- Measurements provide  **evidence** for that idea.


- We can formulate that idea in terms of our **assumption** of the true distribution.

- We do not know the true distribution but are interested to know what type of observation we will get if we make assumptions about it.



Hypothesis
========================================================

If we are interested in braking loads, can we **suppose** that the cables on average break at 12 Tons, or at 14 Tons?

![plot of chunk unnamed-chunk-3](Lecture11-figure/unnamed-chunk-3-1.png)


Hypothesis
========================================================

Examples:

- Tyre manufacturers want to know whether the half-life of the tires the produce is at least 20,000 km 
- Fertilizer developers want to test whether their new product has a real effect on the growth of plants 
- Pharmaceutical companies need to know if chemotherapy can cure 90% of cancer patients

These questions can be translated into statements of probability distributions


Hypothesis
========================================================

- Tyre manufacturers want to know whether the half-life of the tires the produce is at least 20,000 km 

Assuming that the life of tires follows a population probability distribution, we are interested in finding if the mean of the distribution is at least 20,000Km. 


This can be done is two dichotomic statements

- The mean life of tires is **less** than 20,000km 
- The mean life of tires is **greater** than 20,000km 


Hypothesis
========================================================

or being $\mu$ the mean of the population distribution

- $H_0: \mu \leq 20,000km$ 
- $H_1: \mu \geq 20,000km$ 

Hypothesis
========================================================

**Definition**

In statistics, a statement (conjecture) about the distribution of a random variable is called a **hypothesis**.

The hypothesis is usually written in two dichotomous statements

- The **null** hypothesis: $H_0$ when the conjecture is False 
- The **alternative** hypothesis: $H_1$ when the conjecture is True


Null hypothesis
========================================================

So what are the null and the alternative hypothesis for these situations?

- Tyre manufacturers want to know whether the half-life of the tires the produce is at least 20,000 km 

- Fertilizer developers want to test whether their new product has a real effect on the growth of plants 

- Pharmaceutical companies need to know if chemotherapy can cure 90\% of cancer patients



Null hypothesis
========================================================

- Fertilizer developers want to test whether their new product has a real effect on the growth of plants 

Being $\mu_1$ the mean growth of the plants **without** fertilizer and $\mu_2$ the mean growth of the plants with the fertilizer

- $H_0:\mu_1=\mu_2$ (The fertilizer does nothing: null effect)
- $H_1:\mu_1 \leq \mu_2$ (The fertilizer has the desired effect)

What could be a suitable distribution of $\mu_1$?

Hypothesis
========================================================

Hypotheses are tested by the integration of **data** with **models** in three equivalent ways:

- Rejection zone
- Confidence intervals
- P-values

They are of two types:

- two-tailed
- one-tailed


Hypothesis
========================================================

As in the case of CI, we are going to consider a test for  

- the means with known variance
- the means with unknown variance
- the variance

all of which assume underlying probability **models** for the random variables, such as the normal distributions (CLT).


Test of means with known variance
========================================================

- Aircrew escape systems are powered by some solid propellant. 

- The burning rate of this propellant is an important product characteristic. Specifications require that the mean burning rate must be $50cm/s$. 

- We know that the standard deviation of the burning
rate is $\sigma=2cm/s$. 

- The experimenter designs a new propellant and produces a sample of $n=25$ with a sample average burning rate of $\bar{x}=51.3cm/s$ 

- can the experimenter warrant the safe combustion, not too **low** not too **high** of the new product with 95% confidence?


Test of means with known variance
========================================================

The propellant needs to be reliably burnt at $50cm/s$

Using real **data** the experimenter is interested in finding whether 

- $H_0: \mu= 50cm/s$ (null hypothesis)
- $H_1: \mu\neq 50cm/s$ (alternative hypothesis)



Test of means with known variance
========================================================

There are cases were the critical region is given by construction guidelines: 

- Accept $H_0$ when $48.5 \leq \bar{x}\leq 51.5$.

If the result of an $n$-sample random experiment is: $\bar{x}=51.3cm/s$ then the experimented accepts $H_0$

<img src="./figures/reject.png" style="width:50%"  align="center">


Test of means with known variance
========================================================

When we do not have guidelines we use **statistics**, we ask: 

How probable is our observation under the **null hypothesis**?

General procedure for hypothesis testing with a predefined significance level $\alpha$

State the problem:

- From the problem context, identify the parameter of interest: $\mu$ the burning rate
- State the null hypothesis: $H_0: \mu=50$.
- Specify an appropriate alternative hypothesis: $H_1 \neq 50$ .
- Choose a significance level: $\alpha=0.05$ (95% confidence).



Rejection zone
========================================================

- Define rejection zone:

**Assume** $H_0$ is **true** and a **probability model**: $X \hookrightarrow N(\mu=50, \sigma^2=4)$

![plot of chunk unnamed-chunk-4](Lecture11-figure/unnamed-chunk-4-1.png)


Rejection zone
========================================================
Define the rejection zone:

- Determine an appropriate test statistic and its distribution to transform the **null hypothesis**: $Z_0=\frac{\bar{X}-50}{2/\sqrt{25}}\rightarrow N(\mu=0,\sigma^2=1)$

- State the rejection region for the statistic (95\% confidence, leave out 5%):
$z_0 < z_{0.975}=-1.96$ or $z_0 > z_{0.025}=1.96$

Rejection zone
========================================================
Define rejection zone:


![plot of chunk unnamed-chunk-5](Lecture11-figure/unnamed-chunk-5-1.png)

Test of means with known variance
========================================================

Now use **data** to draw conclusions:

- Compute any necessary sample quantities, substitute these into the equation for the test statistic, and compute the **observed** value.
$z=\frac{51.3-50}{2/\sqrt{25}}=3.25$

- **Decide** whether or not $H_0$ should be rejected and report that in the problem context: $z>1.96$ and $H_0$ is rejected.


According to the estimator value, the experimenter **cannot accept** with confidence of 95% that the burning rate of its prototype is the expected $50 cm/s$


- $H_0$ could still be true but then the observation would be **very rare**.

Imagine the case of an innocent man from a murdering ($H_0$) who is found with a gun in his hand ($z>>z_{0.025}$): he can still be innocent but it would be very unlikely.

Test of means with known variance: confidence intervals
========================================================

Let's look at the problem from the point of view of the estimate.

The 95\% confidence interval for $\bar{x}$ is given by

$CI=(\bar{x}-z_{\alpha/2}\sigma/\sqrt{n},\bar{x}+z_{\alpha/2}\sigma/\sqrt{n})$ 

$=(50.516,52.084)$

which clearly does not contain $50$ but in addition gives a sense of the range and distance falling out of the CI.

Test of means with known variance: confidence intervals
========================================================

The confidence interval does not **capture** the hypothesis. 

![plot of chunk unnamed-chunk-1](Lecture11-figure/unnamed-chunk-1-1.png)

Test of means with known variance: confidence intervals
========================================================
If the $H_0$ is true then this is a rare observation of the CI that happens only 5% of the times. 

![plot of chunk unnamed-chunk-2](Lecture11-figure/unnamed-chunk-2-1.png)

Test of means with known variance: confidence intervals
========================================================

Remember our discussion on confidence intervals:
From the estimator distribution of $\Theta$ define a **confidence limit** $\alpha$ such that

$P(f_{1-\alpha/2} < \mu < f_{\alpha/2} ) = 1-\alpha$


Since $1-\alpha$% of the times we capture the mean, if the CI does not contain the null hypothesis then

- the experimenter was very unlucky ($\alpha$; 5%)
- the real mean was really captured by the CI and it **is not** the null hypothesis ($1-\alpha$; 95%)  


According to the confidence interval, the experimenter **cannot accept** with confidence of 95% that the burning rate of its prototype is the expected $50 cm/s$.

If you had to bet where would you put your money on?


Hypothesis testing
========================================================

Given a hypothesis $H_0: \theta=\theta_0$ and some data $x_1,...x_n$, we compute the estimate of $\theta$ by an estimator $\Theta$ (i.e. $\bar{X}$) and its confidence interval $(l,u)$, whose expressions we know, or can derive using for example maximum likelihood, assuming a distribution for $\Theta$.

We reject the null hypothesis with false-positive probability $\alpha$ when 

- the estimator falls in the critical region of $H_0$ that gives a probability of $\alpha$
- the $(1-\alpha)100\%$ confidence interval does not contain $\theta_0$

Otherwise, we cannot reject the null hypothesis. We assume that the data could have been produced by it. 

Test of means with known variance: P-value
========================================================


One can then test whether a null hypothesis can be rejected or not.

- However, if the estimate falls outside the acceptance region it is useful to know how far is from the limits.

- Estimates that are far from the limits, way into the critical region are more credible.

- How do we report how significant is our estimate in rejecting the null hypothesis, or far from the boundaries of the acceptance region?


Test of means with known variance: P-value
========================================================

Rejecting the hypothesis with a P-value:

When the experimenter tested the null hypothesis by transforming it to a standard distribution we transformed the **observed** average to:

$z=\frac{51.3-50}{2/\sqrt{25}}=3.25$

In fact, the value of $z=3.25$ gives strong evidence for the rejection of $H_0$ .


If the null hypothesis is **true** and we performed another experiment the probability of improving our result is extremely low

$P=2(1-\Phi(|z|))= 0.0011<<\alpha=0.05$

Test of means with known variance: P-value
========================================================

Interpretation: 

- The data indicate that if $H_0$ is true then the probability of obtaining a result that is at least the value of the data is $0.0011$

- That the data is such a very **rare** event for $H_0$ that we can reject it with confidence.


Test of means with known variance: P-value
========================================================

**Definition**

The **P-value** is the smallest level of significance that would lead to rejection of the null hypothesis $H_0$ with the given data.

Summing up: With some data $x_1,...x_n$ from a random variable $X \hookrightarrow f(x; \theta)$, We

- obtain the estimate $\hat{\theta}$
- compute the probability that the estimator $\Theta$ that is further than the estimate $\hat{\theta}$ when $H_0$ is true: $X \hookrightarrow f(x; \theta_0)$.
- then reject $H_0$ if $P<\alpha$

$P$ gives us how far we are from $\theta_0$.

The null hypothesis can be tested with the rejection zone, CI or P-values. All three are equivalent.

One or two-tailed hypothesis
========================================================

**Two-tailed** test:
When we consider the two tails of the distribution, or when the null hypothesis is expected to take one value $\mu_0$.


- $H_0$ when $\mu=\mu_0$
- $H_1$ when $\mu \neq \mu_0$

The alternative can be either greater or lower.

Our Burning rate example is a two-tailed test

- $H_0: \mu= 50cm/s$ (null hypothesis)
- $H_1: \mu\neq 50cm/s$ (alternative hypothesis)

Two-tailed hypothesis
========================================================

It is important that the experimenter burns the propellant at an adequate rate. If the rate is too high or too low the propulsion won't work 

$$P=2(1-F(|z|))$$

if $Z \hookrightarrow N(0,1)$ then $F=\Phi$

<img src="./figures/pval.jpg" style="width:50%"  align="center">



Upper tailed hypothesis
========================================================

**Upper tailed** test:

When we consider the upper tail of the distribution, or when the estimate $\hat{\theta}$ is expected to take only **greater** values than $\theta_0$

The efficacy of some drug treatment is 70%. If we think we have improved the efficacy of treatment then 

- $H_0: \mu=\mu_0= 0.70$ (null hypothesis)
- $H_1: \mu > \mu_0$ (alternative hypothesis)

Upper tailed hypothesis
========================================================

$$P=(1-F(z))$$

if $Z \hookrightarrow N(0,1)$ then $F=\Phi$

<img src="./figures/pvalup.jpg" style="width:50%"  align="center">


Lower tailed hypothesis
========================================================

When we consider the upper tail of the distribution, or when the estimate $\hat{\theta}$ is expected to take only **lower** values than $\theta_0$

The mean combustion efficiency of a car is $6Lt/100Km$. If we think we have improved the efficiency of its combustion then 

- $H_0:\mu=\mu_0=6Lt/100Km$
- $H_1:\mu < \mu_0$

Lower tailed hypothesis
========================================================

when $$P=F(z)$$

if $Z \hookrightarrow N(0,1)$ then $F=\Phi$

<img src="./figures/pvallow.jpg" style="width:50%"  align="center">



Test of means with unknown variance
========================================================

- Aircrew escape systems are powered by some solid propellant. 

- The burning rate of this propellant is an important product characteristic. Specifications require that the mean burning rate must be $50cm/s$. 

- We **know** that the standard deviation of the burning
rate is $\sigma=2cm/s$. **How do we know it?**

- The experimenter designs a new propellant and produces a sample of $n=25$ with a sample average burning rate of $\bar{x}=51.3cm/s$ 

- can the experimenter warrant the safe combustion not too **low** not too **high** of the new product with 95% confidence?


Test of means with unknown variance
========================================================

Similar arguments are easily extended when we do not know the variance.

In general, if we consider the case where

- sample $X_1, ...X_n$ from a population sample $X\rightarrow N(\mu, \sigma)$
- $H_0: \mu=\mu_0$ is the null hypothesis 
- $H_1$ is the alternative hypothesis 

and we estimate $\sigma^2$ with $S^2$,

What should be the statistic and its distribution in this case?

Test of means with unknown variance
========================================================

Remember that if we estimate the variance $\sigma^2_X$ with the sample variance $S^2$ and $X\rightarrow N(\mu_X, \sigma^2_X)$ then the standardized statistics

$T=\frac{\bar{X}-\mu}{\frac{S}{\sqrt{n}}}$ follows a T distribution with $n-1$ degrees of freedom.

Then, when we perform a **two-tailed** test for $H_0$, we should reject $H_0$ at level $\alpha$ if:

- the observed value under the null hypothesis $t=\frac{\bar{x}-\mu_0}{\frac{s}{\sqrt{n}}}$ falls outside the rejection zone: 

$t<-t_{\alpha/2,n-1}$ or $t_{\alpha/2,n-1}\lt t$

- $CI=(\bar{x}-t_{\alpha/2,n-1}s/\sqrt{n},\bar{x}+t_{\alpha/2,n-1}s/\sqrt{n})$ does not contain $\mu_0$

- OR, $P=2(1-f_{t(n-1)}(|t|))<\alpha$

which are all equivalent


Test of means with unknown variance
========================================================

- A tape is designed to break at 185 pounds. 

- Five samples are selected randomly and tested for braking with values;

171.6, 191.8, 178.3, 184.9, 189.1.

- test the null hypothesis $\mu=185$ against the alternative $\mu < 185$ at the $0.05$ significant level. 


Test of means with unknown variance
========================================================

Therefore we have the


- $H_0:\mu=185$ 
- $H_1:\mu < 185$ 
- $\alpha=0.05$
-  data: 171.6, 191.8, 178.3, 184.9 and 189.1.

What is the critical region?


Test of means with unknown variance
========================================================


We are looking for the upper limit of the region at the lower tail of a $t(n-1)$ that has a probability $\alpha=0.05$  

That is:

$P(T \leq t_{0.95,n-1=4})=0.05$
</br>$F(t_{0.95,n-1=4})=0.05$
</br>$t_{0.95,4}=F^{-1}_{t,4}(0.05)=$<code>qt(0.05,4)</code>$=-2.13$


<img src="./figures/t.jpg" style="width:50%"  align="center">

let's look it up on a table...

Test of means with unknown variance
========================================================
Remember the distribution is symmetric!

<img src="./figures/ttable.jpg" style="width:50%"  align="center">


Test of means with unknown variance
========================================================

You should find
$t_{0.05,4}=2.132$ and $t_{0.95,4}=-2.132$

Then we have:

- $H_0:\mu=185$ 
- $H_1:\mu < 185$ 
- $\alpha=0.05$
-  data: 171.6, 191.8, 178.3, 184.9 and 189.1.
- the critical region is: $t<-2.132$

What is the value of the statistic t?


Test of means with unknown variance
========================================================

Under the null hypothesis $t$ is the standardized variable 
$t=\frac{\bar{x}-\mu_0}{s/\sqrt{5}}$

from the data: 171.6, 191.8, 178.3, 184.9 and 189.1. we get
$\bar{x}=183.1$ and $s=8.2$

$$t=\frac{183.1-185}{8.2/\sqrt{5}}=-0.49$$

which is not lower than the critical value $-2.132$ and therefore we conclude that the data is consistent with $H_0$ and we cannot reject it.


Test for variances
========================================================

In many cases, experiments are run to test specific values of the dispersion of data.

Such as

- for complying with strict design standards where measurements must be between certain values
- when relative measurements are taken such as the reaction of a treatment on an individual (insulin administration on an individual's sugar levels)

Test for variances
========================================================

For a random sample $X_1,...X_n$ with a normal population distribution ($X_i \rightarrow N(\mu, \sigma^2)$) the statistics defined by 

$$X=\frac{(n-1)S^2}{\sigma^2}$$

Has a $\chi^2$ (chi-squared) distribution with n-1 degrees of freedom given by

$$f(x)=C_n  x^{\frac{n-3}{2}} e^{-\frac{x}{2}}$$



Test for variances
========================================================

Suppose we want to test whether the variance of the population distribution is equal to a given value $\sigma_0$

- $H_0:\sigma=\sigma_0$

Alternative hypothesis

- two tailed: $H_1:\sigma \neq \sigma_0$

- upper tailed: $H_1:\sigma > \sigma_0$

- lower tailed: $H_1:\sigma < \sigma_0$

Test for variances
========================================================


We know that

- $S^2$ is an unbiased estimate of $\sigma^2$: $E(S^2)=\sigma^2$



Then under the null hypothesis, $H_0:\sigma=\sigma_0$ the statistic
$$X=\frac{(n-1)S^2}{\sigma_0^2} \rightarrow \chi^2(n-1)$$ 


Test for variances
========================================================

For a two-tailed test then $H_0$ is rejected if data falls

$\chi_0^2< \chi^2_{1-\alpha/2,n-1}$ or $\chi_0^2>\chi^2_{\alpha/2,n-1}$ 

<img src="./figures/chi2.PNG" style="width:50%"  align="center">



Test for variances
========================================================

<img src="./figures/chitable.jpg" style="width:50%"  align="center">



Test for variances
========================================================

- The production of a semiconductor chip is regulated by a process that requires that the thickness of a particular layer is not greater than $\sigma_0=0.6mm$.  


- To keep control of the process every so often a sample of 20 specimens. 

- If on one occasion the standard error of the sample $s=0.84$ is the process is out of control at 0.01 confidence and should be stoped?

Test for variances
========================================================

- $H_0:\sigma=\sigma_0=0.6$
- upper tailed: $H_1:\sigma > \sigma_0$
- Statitstic: $Y=\frac{(n-1)S^2}{\sigma_0^2} \rightarrow \chi^2(n-1)$
- $\alpha=0.01$
- critical region: $Y>\chi^2_{0.01,19}$

What is the critical value?

Test for variances
========================================================
$P(Y > \chi^2_{0.01,19})=0.01$

$1-P(Y \leq \chi^2_{0.01,19})=0.01$

$P(Y \leq \chi^2_{0.01,19})=0.99$

$F(\chi^2_{0.01,19})=0.99$

$\chi^2_{0.01,19}=F^{-1}(0.99)=$<code>qchisq(0.99,19)</code>$= 36.19$

let's look it up on a table...

Test for variances
========================================================
$P(Y > \chi^2_{0.01,19})=0.01$

<img src="./figures/chitable.jpg" style="width:50%"  align="center">


Test for variances
========================================================

The process will be out of control if 

$$\frac{(n-1)S^2}{\sigma_0^2}$$

with $n=20$ and $\sigma=0.60$ is greater than

$$\chi^2_{0.01,19}=36.191$$

$$\frac{19 (0.84)^2}{0.60^2}=37.24$$

Since the value of our experiment is greater than the critical value then: Yes! the process is out of control.



Errors in hypothesis testing
========================================================

When we infer a parameter with a statistic and then apply a criterion to decide on a hypothesis we have four possibilities

- $H_0$ unknown reality: **true**, **false** 
- $H_0$ observed testing : **accept**, **reject**

| $H_0$ | reality: true | reality: false |
|-----  | ----- | ----- |
| **test: accept** (negative result)  | true negative  | false negative | 
| **test: reject** (positive result)  | false positive | true positive | 

We usually aim to reject $H_0$ (prosecutor)


Errors in hypothesis testing
========================================================

You take a PCR test $H_0$ you are not infected

- $H_0$ unknown reality: **true**, **false** 
- $H_0$ observed testing : **accept** (negative), **reject** (positve)

| $H_0$ | not infected: true | not infected: false   (infected: true)|
|-----  | ----- | ----- |
| **negative** (accept)  | true negative: $P(accept|H_0:true)$  | false negative:$P(accept|H_0:false)$ | 
| **positive**  (reject) | false positive: $P(reject|H_0:true)$ | true positive: $P(reject|H_0:false)$ | 
| **sum**  | 1 | 1 | 


Errors in hypothesis testing
========================================================

Errors are also known as 

- Type I error: false positive
$P(reject|H_0:true)$

- Type II error: false negative
$P(accept|H_0:false)$ 

| $H_0$ | not infected: true | not infected: false   (infected: true)|
|-----  | ----- | ----- |
| **negative** (accept)  | true negative: $P(accept|H_0:true)$  | Type II error: $P(accept|H_0:false)$ | 
| **positive**  (reject) | Type I error: $P(reject|H_0:true)$ | true positive: $P(reject|H_0:false)$ | 
| **sum**  | 1 | 1 | 


Bayesian statistics
========================================================


What happens if we apply the Bayes theorem to the previous table? 

$$P(H_0|data)=\frac{P(data|H_0)P(H_0)}{P(data)}$$

We subvert the meaning of an event and apply it to a hypothesis 

Can we assign a probability to a hypothesis?

Bayesian interpretation of probability

- The probability is our state of belief on the veracity of a hypothesis given the data.

But this opens a whole new world on statistics and on the scientific method and our understanding of random experiments.


From statistics to data science
========================================================


- Integration of data and models

- Prediction and inference (hypothesis testing)


*Data*: Most valuable commodity. Processes generate massive amounts of data. 

*Models*: Computer driven (AI). Massive amounts of models.  



