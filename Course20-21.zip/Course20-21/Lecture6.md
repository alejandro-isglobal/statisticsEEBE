Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 6</p>

Objective
========================================================

Discrete probability models:

- Uniform and Bernoulli probability functions
- Binomial, geometric and negative binomial probability functions
- Hypergeometric probability function

Discrete probability models
========================================================

<img src="./figures/modis.JPG" style="width:50%"  align="center">


Discrete probability models
========================================================

A mass probability function of a discrete random variable X with possible values $x_1 , x_2 , .. , x_m$ is **any function** such that

- $f(x_i)\geq 0$
- $\sum_{i=1}^m f(x_i)=1$  
- $f(x_i)=P(X=x_i)$

They are abstract objects with general properties that may or may not **describe** a natural or engineered process. 



Discrete probability models
========================================================

Discrete probability models are probability mass functions that we **believe** describe processes like real random experiments. 

Analogy: Think of the function $f(x,y)=x^2+y^2$ 

- $f(x,y)=a^2$ is a circle of radius $a$.  
- it is an abstract object. 
- it represents the shape of many real objects.
- the shape of real objects is an approximation of the circle. 


Discrete probability models
========================================================

Discrete random models are functions that are **idealizations** of random experiments on discrete variables. 


- What is the simplest model?


Discrete probability models
========================================================

The classical interpretation of probability (Laplace)

Whenever a sample space consists of N possible events that are equally likely, the probability of each outcome is $\frac{1}{N}$.

On many occasions:

- we can reason the possible values that a random variable can take.

- we have no reason to suppose that one outcome is more probable than the other. 


Uniform distribution
========================================================

<img src="./figures/dice.JPG" style="width:5%"  align="center">

Think of a dice or the lottery:

- we can count all possible outcomes (dice:1-6, lottery:0000-9999) 

- we have a strong belief that they all are equally probable (dice: $1/6$, lottery: $10^{-4}$) because the game is fair and before the game, we are completely ignorant of the outcome!


Uniform distribution
========================================================

**Definition** 
A random variable X has a discrete uniform distribution if each of the n values in its range, say, has equal probability. Then,
$f(x)=\frac{1}{n}$

![plot of chunk unnamed-chunk-1](Lecture6-figure/unnamed-chunk-1-1.png)

Uniform distribution
========================================================

- If $f(x)$ for $x\in\{a, a+1, ...b\}$, where $a$ and $b$ are integer, the size of the sample space is: $n=b-a+1$

- If all the the events are equally probable then 
$$f(x)=\frac{1}{b-a+1}$$


Uniform distribution
========================================================
Let's compute the mean of the uniform distribution. 

changing variables for $Y=X-a+1$, $y\in\{1, 2, ...n\}$ then $f(Y)=\frac{1}{n}$.

and the fact that
$\sum_{y=1}^n y = \frac{n(n+1)}{2}$

then the mean $E(Y)$, is given by
$E(Y)\sum_{y=1}^n y\big(\frac{1}{n}\big)=\frac{n+1}{2}$

and $E(X)=E(Y+a-1)=\frac{n+1}{2}+a-1=\frac{(b-a+1)+1}{2}+a-1=\frac{b+a}{2}$

Uniform distribution
========================================================


The variance of 
$f(Y)=\frac{1}{n}$

$V(Y) = \mu'_2-\mu^2$
</br>$= \sum_{y=1}^n y^2\big(\frac{1}{n}\big) -\mu^2$
</br>$= \frac{1}{n}\frac{n(n+1)(2n+1)}{6} -\big(\frac{n+1}{2}\big)^2$
</br>$= \frac{n^2-1}{12}$


because $V(Y)=V(X)$ then 
$V(X)=\frac{(b-a+1)^2-1}{12}$


Uniform distribution
========================================================

What is the mean and variance of a dice?

Sample space $X\in\{1,2,3,4,5,6\}$ then $n=6$

 
- $E(X)=\frac{n+1}{2}=3.5$. Note that the expected value is not in the sample space! (is not a possible outcome)

- $V(X)=\frac{n^2-1}{12}=2.91$


Bernoulli trials
========================================================


The simplest case of a mass probability function is where there are **two possible** outcomes ($A$ and $B$). If they are equally probable we have the flip of a coin.

- let's try to advance from the equal probability case and suppose that the outcomes have unequal probabilities


Bernoulli trials
========================================================
What if we let them have different probabilities

- outcome A (success): has probability $p$
- outcome B (failure): has probability $q=1-p$ ($q+p=1$)

Then we define the random variable $K$ (big $K$) where $k=1$ (little $k$) when the observation is $A$ and $k=1$ abd $k=0$ when the observation is $B$.

Bernoulli trials
========================================================

The probability mass function of $K$ is
\[
    P(K=k)=f(k)= 
\begin{cases}
    q=1-p,& \text{if } k=0\, (event\, B)\\
    p,& k=1\, (event\, A) 
\end{cases}
\]

or more shortly

$f(k)=(1-p)^{1-k} p^k$, for $k=(0,1)$

Bernoulli trials
========================================================

Every time we have two different outcomes, where we can define a variable $k=0$ for one outcome and $k=1$ for the other.

We think of a Bernulli probability function $f(k)=(1-p)^{1-k} p^k$.

- In the uniform distribution, if we know the outcomes the mass probability distribution is fully known.

- In a Bernoulli trial we allow ourselves the flexibility of not knowing the number $p$ (the probability relationship between the outcomes). 

Bernoulli trials
========================================================

$p$ is a **parameter** of the distribution: it is allowed to change.

- Bernoulli trial is really a **family** of distributions
- when we fix the value of $p$ then we have a single probability mass function $f(k;p)$.


Why do we let $p$ free? because our hope is that data, the real observations, will tell us what its value is (from lecture 7 on estimation onwards).

Bernoulli trials
========================================================

For the following lectures, we are going to assume we know the value of $p$.


- When we flip a coin then we  "know" that $A$:Tail$\rightarrow k=1$ and $B$:Head $\rightarrow k=0$ have equall probabilities and therefore $p=1/2$  and $f(k)=\frac{1}{2}^{1-k} \frac{1}{2}^k= \frac{1}{2}$.

- If we **assume** that the probability of erroneously transmiting ($k=1$) one bit of information is $p=1/10$ then
$f(k)=\frac{9}{10}^{1-k} \frac{1}{10}^k$ ($k=0$ no error)

Bernoulli trials
========================================================

What is the mean and variance of $f(k)=(1-p)^{1-k} p^k ?$

- The mean  $E(K)= \sum_{k=0}^1 k f(k)=f(1)=p$

- The variance 
$V(K)= \sum_{k=0}^1 (k-p)^2 f(k)$
</br>$=  p^2(1-p)+(1-p)^2p$ 
</br>$=  (1-p)(p^2 + p-p^2)$ 
</br>$=  (1-p)p = pq$

Binomial distribution
========================================================

Suppose that we are interested in learning about a particular Bernoulli trial.

- We repat the Bernoulli trial $n$ times and count how many times we obtained $A$. 

- We define a random variable $K$ such that it counts in $n$ trial how many times we obtained the outcome $A$. $k \in {0,1,...n}$

What is the probability of $P(K=k)$?

Binomial distribution
========================================================
- tossing a coin $n$ times and counting the number of tails. What is the probability of observing $k$ tails in $n$ throws?

- transmitting $n$ bits and counting the number of errors, when the transmission of a single error is $p$. What is the probability of observing $k$ errors when transmitting $n$ bits?

- asking $n$ people whether they will vote for the political party in government when the probability that someone votes for the ruling party is $p$. What is the probability of observing $k$ likely votes for the ruling party in $n$ people?


Binomial distribution
========================================================

- each outcome $A$ of a Bernoulli trial is observed with probability $p$.
- each outcome $B$ (not $A$) of a Bernoulli trial is observed with probability $1-p$.

Important! The random experiment here is the outcome of $n$ independent random experiments (Bernoulli trials): the outcome is the sum of Bernoulli outcomes. 



Binomial distribution
========================================================

- When we ask 100 people for their voting preferences we will get one $k$, say 45; when we ask another 100 people we will get other $k$ say 40; and so on...

Therefore every time we run a poll, we obtain a different $k$, and then it makes sense to ask for the probability of $k$ events $P(K=k)$ when the probability that a single event is $p$.

We want to find $P(K=k)$ in terms of $p$.

Binomial distribution
========================================================

What is the probability of observing $k$ errors when transmitting $n$ bits, when the probability of a single error is $p$?

Let's observe first the probability of one particular event defined by $k$ errors over $n$ trials. In one particular experiment, we observe, for instance, $k$ errors and $n-k$ no errors.


| trial | 1 | 2 | 3 | 4 | ...  | n | 
| ------- | ------- | ------- | ------- | ------- | -------  | ------- | 
| Bernulli outcome | no error | error | no error | error | ... | no error | 
| Bernulli probability | (1-p) | p | (1-p) | p | ... | (1-p) | 




Binomial distribution
========================================================

For obtaining the probability of one particular outcome of the n-trial experiment such as (error, no error, ..., no error), with $k$ errors ($A$ outcomes) overall Bernoulli trials, we need to consider that

- $k$ independent errors were observed with a probability $p*p...p$ ($k$ times)

- $n-k$ independent no errors were observed with probability $(1-p)*(1-p)...(1-p)$ ($n-k$ times)

Then the observation (error, no error, ..., no error) with $k$ errors and $n-k$ no errors has probability $p^k(1-p)^{n-k}$



Binomial distribution
========================================================

However, both outcomes 
</br>(**error**, **no error**, ..., no error) 
</br>and 
</br>(**no error**, **error**, ..., no error) 
</br>with opposite values only in the 1st and 2nd Bernoulli outcomes, have the same amoun of $k$ errors. 


- $k$ errors can appear $\binom n k$ different $n$-transmission outcomes: The number of subsets of $k$ elements from a set of $n$ elements. 


Therefore, the probability of observing the **transmission** event made on **any** $k$ errors (single Bernoulli outcomes) is

$f(k)=\binom n k p^k(1-p)^{n-k}$, $k=0,1,...n$


Binomial distribution
========================================================

**Definition**

The binomial probability function is the probability mass function of observing $k$ outcomes of type $A$ in $n$ independent Bernoulli trials, where $A$ has the same probability $p$ in each trial. 

The function is given by

$f(k)=\binom n k p^k(1-p)^{n-k}$, $k=0,1,...n$

When a variable $K$ has a binomial probability function we say its distributes binomially and write 

$K\hookrightarrow Bin(n,p)$


Binomial distribution
========================================================

The mean of the binomial distribution requires some algera, but is result is simple and very intuitive.

$E(K)= \sum_{k=0}^n\binom n k  k p^k(1-p)^{n-k}$
</br>$= \sum_{k=0}^n \frac{n!}{k! (n-k)!}  k p^k(1-p)^{n-k}$
</br>$= \sum_{k=0}^n \frac{n!}{(k-1)! (n-k)!} p^k(1-p)^{n-k}$
</br>$= n\sum_{k=0}^n \frac{(n-1)!}{(k-1)! (n-1-(k-1)!)} p^k(1-p)^{n-k}$
</br>$= n\,\, \sum_{k=0}^n \binom {n-1} {k-1} p^k(1-p)^{n-k}$
</br>$= np\,\,\sum_{k=1}^n \binom {n-1} {k-1} p^{k-1}(1-p)^{(n-1)-(k-1)}$
</br>$= np\,\, \sum_{k-1=0}^{n-1} f(k-1)= np$

Binomial distribution
========================================================

The mean and variance of $K\hookrightarrow Bin(n,p)$ are 

- $E(K)=np$
- $V(K)=np(1-p)$

For demonstrating the variance 

- we first find the result of $E(K^2)=E(K(K-1))-E(K)=n(n-1)p^2 +np$ 

- and then use $V(K)=E(K^2)-E(K)^2$



Binomial distribution
========================================================
- The binomial distribution has two parameters: $n$ and $p$.

- The expectation of runing multiple Bernulli trials and summing their results is the result of multiplying the expectation of a single Bernulli trial by $n$: 

$E(K)=np$.

... so by tossing many times a coin, we can get to know the probability of a single tossing of the coin. 


Binomial distribution
========================================================

Let's briefly jump ahead. 

- What if we replace $E(K)$ by the result of a single $n$-trail experiment? If we observed $k=n_{tail}\sim E(K)=np$ 

- then $n_{tail}/n \sim p$. 


- We can get to know $p$ from repeating an experiment!  

Binomial distribution
========================================================

Consider noisy channel where bits (0,1) are transmitted randomly with  **the same probability** the mass probability function of transmitting $k$ number of 1's in a 5-bit transmission is 

$f(k)= \binom 5 k (\frac{1}{2})^5$

|trial outcome | k=0 | k=1  |k=2 | k=3 | k=4  |k=5 | total   
| -------------- | -------------- | --------------  |-------------- | -------------- | --------------  |-------------- | --------------|   
|| $1/32$ | $5/32$ | $10/32$ | $10/32$ | $5/32$ | $1/32$ | 1 |  

Binomial distribution
========================================================

![plot of chunk unnamed-chunk-2](Lecture6-figure/unnamed-chunk-2-1.png)



Binomial distribution
========================================================

![plot of chunk unnamed-chunk-3](Lecture6-figure/unnamed-chunk-3-1.png)


Binomial distribution
========================================================

![plot of chunk unnamed-chunk-4](Lecture6-figure/unnamed-chunk-4-1.png)

Binomial distribution
========================================================

![plot of chunk unnamed-chunk-5](Lecture6-figure/unnamed-chunk-5-1.png)


Shifted geometric distribution
========================================================

Suppose performing Bernoulli trials until we observe **the first time** the outcome A appears.

- when $p=1/2$ think of tossing a coin until observing a tail: 
What is the probability of tossing the coin $k$ times until the first tail appears?


Shifted geometric distribution
========================================================

- when transmitting bits and counting the number of bits transmitted **until we find the first error** if the transmission of a single error is $p$: 

What is the probability of sending $k$ correct bits until the first error appears?

- when asking people whether they will vote for the political party in government, if the probability that someone votes for the ruling party is $p$: 

What is the probability 
asking $k$ times **until we observe the first person** likely to vote for the ruling party?

Shifted geometric distribution
========================================================

We are asking for the number of **trials** (a black disk is the appearance of the event A with probability $p$)

<img src="./figures/geom.png" style="width:50%"  align="center">


Shifted geometric distribution
========================================================

If in the $k$ trial the event $A$ appeared then the outcome of this experiment has a probability

$P(X=k)=f(k)=(1-p)^{k-1}p,$ $k=1,2,3,...$

This is called a **shifted geometrical** probability function with 

- mean:$E(X)= \Sigma_{k=1}^\infty k(1-p)^{k}p=\frac{1}{p}$

- variance: $V(X)= \frac{1-p}{p^2}$


Shifted geometric distribution
========================================================

- How many **tosses** of a coin on average before the first tail? 

- What is the expected number **bits** that we can transmit before the first error occurs if the probability of an error for one bit is 0.1?



Geometric distribution
========================================================

A more common random variable is the number of **events** $B$ that we need to observe before the event $A$ appears

- How many **tails** of a coin on average before the first tail? 

- What is the expected number of bits **with no error** that we can transmit before the first error occurs if the probability of an error for one bit is 0.1?

Geometric distribution
========================================================

The geometric distribution is for the number of $B$ events before the first event $A$ is produced. Therefore its first value is for k=0 (when we get $A$ with no previous $B$). 

The probability function distribution is

$P(Y=k)=f(k)=(1-p)^{k}p,$ $k=0,1,2,...$

Note that I use $Y$ for outcomes and $X$ for trials, it is just notation to emphasize the difference. 

Geometric distribution
========================================================

The (non-shifted) geometric distribution has 

- mean: $E(Y)= \sum_{k=0}^\infty k(1-p)^{k}p=\frac{1-p}{p}$

- variance: $V(Y)= \frac{1-p}{p^2}$

the change of variable $X=Y+1$ leads to the shifted distribution.

Geometric distribution
========================================================

![plot of chunk unnamed-chunk-6](Lecture6-figure/unnamed-chunk-6-1.png)

Geometric distribution
========================================================

![plot of chunk unnamed-chunk-7](Lecture6-figure/unnamed-chunk-7-1.png)



Negative binomial distribution
========================================================

- Now let us imagine that we can be tolerant of a given number of errors in the signal transmission of bits. Say we can tolerate $r$ errors in a transmission:

What is the probability of observing $k$ well-transmitted bits before $r$ errors?

Note: we are asking for the probability of the number of $B$ events (not trials). 

Shifted negative binomial on trials will not be explained.

Negative binomial distribution
========================================================

Let's observe first the probability of one particular event with $k$ no errors ($B$) before $r$ errors ($A$). 

We then observed $k$ with no errors in a total of $k+r$ trials.


|trial| 1 | 2  | 3 | 4 | ... | k+r |
| ------- | ------- | -------  | ------- | ------- | ------- | ------- |
|Bernulli outcome | no error | error | no error | error |  ...  | no error |
|Bernoulli probability | (1-p) | p  | (1-p) | p |  ...  | (1-p) |

Negative binomial distribution
========================================================
We consider:

- The probability of our observation is $(1-p)^kp^r$ where $p$ is the probability of one error. However, the transmissions:

(**no error**,  **error**, no error, error,  ... no error)

(**error**,  **no error**, no error, error,  ... no error)

transmitted the same amount of no errors.

- All events finish by an $A$ outcome then the total number of events with $B$ outcomes are chosen from the number of subsets of $k$ elements from a set of $k+r-1$: $\binom {k+r-1} k$


Negative binomial distribution
========================================================

Therefore, the probability of observing **any** event with $k$ events $B$ before $r$ events $A$ of probability $p$ is

$P(X=k)=f(k)=\binom {k+r-1} k (1-p)^kp^r$ $k=0,1,...$

When the distribution $X$ is a negative binomial we write

$X\hookrightarrow NB(r,p)$

Negative binomial distribution
========================================================

A random variable with $X\hookrightarrow NB(r,p)$  has

- mean: $E(X)= r\frac{1-p}{p}$

- variance: $V(Y)= r\frac{1-p}{p^2}$

Note that this is $r$-times those of the geometric distribution. 

If we perform $r$-geometric experiments (composed on Bernoulli trials) the expectation for the sum the total amount $B$ events is the same performing a single negative binomial experiment with parameter $r$.  



Negative binomial distribution
========================================================

- A website has three servers. 

- One server operates at a time and only when a request fails another server is used. 

- If the probability of failure for a request is known to be $p=0.0005$ then 

- what is the expected number of successful requests before the three computers fail? 

Negative binomial distribution
========================================================

This is a negative binomial process for the number of successes $k$ $(k=0,1,2,...)$ before $r=3$ and $p=0.0005$ therefore

$E(X)=r\frac{1-p}{p}=3\frac{1-0.0005}{0.0005}=5997$


- Note that there are actually 6000 trials

Negative binomial distribution
========================================================

What is the probability of dealing with at most with 5 successful requests before the system fails?

Recall the cumulative function distribution $F(x)=P(X\leq 5)$

$F(5)=P(X\leq 5)=\Sigma_{k=0}^5 f(k)$
</br>$=\sum_{k=0}^5\binom {k+2} k  (0.9995)^k(0.0005)^3$
</br>$=\binom {2} 0 (0.0005)^3 +\binom {3} 1 (0.9995)^1*(0.0005)^3$
</br>$+\binom {4} 2 (0.9995)^2*(0.0005)^3 +\binom {5} 3 (0.9995)^3*(0.0005)^3$
</br>$+\binom {6} 4 (0.9995)^4*(0.0005)^3 +\binom {7} 5 (0.9995)^5*(0.0005)^3$
</br>$= 6.9\times 10^{-9}$


Negative binomial distribution
========================================================

![plot of chunk unnamed-chunk-8](Lecture6-figure/unnamed-chunk-8-1.png)

Negative binomial distribution
========================================================

![plot of chunk unnamed-chunk-9](Lecture6-figure/unnamed-chunk-9-1.png)


Hypergeometric distribution
========================================================

- Imagine we have a manufacturing process that for every 850 devices it produces per hour 50 tend to be defective ($5\%$). 
- We don't have time to count them all so we select 100 at random.

- what is the probability that we choose 5 ($5\%$) defective devices?

Hypergeometric distribution
========================================================

What do we know

- From a population of $N$
- There are $K$ that are not good ($N-K$ are good)
- A sample of $n$ is chosen  
- In the sample, there are $k$ not good

Let's think of what is the probability of observing a given value $k$

Hypergeometric distribution
========================================================

What do we know

- From a population of $N$ 
- There are $K$ that are not good ($N-K$ are good)

Let's imagine we can mark each Good devise $G_1,...G_K$ and each Bad one $B_1,...B_{N_K}$. 


The population of devices is
$\{G_1,...G_K,B_1,...B_{N_K}\}$

Hypergeometric distribution
========================================================

From the population $\{G_1,...G_{N-K},B_1,...B_{K}\}$ a sample of size $n$ is chosen.

there are 
$\binom N n$
of those


Hypergeometric distribution
========================================================


Since each possible $n$-sample is obtained with the same probability, one single draw of n devices will have a probability 

$P(Z=\{G_3, G_{10}, ... B_5,..B_{610}\})=\frac{1}{\binom N n}$

from these, we are going to add int a single event those that have the same number of $k$ B's ($n-k$ G's)

Hypergeometric distribution
========================================================


- In how many ways we could get k different bad devises from a pool of K?

$\binom K k$



- In how many ways we could get n-k different good devices from a pool of n-k?

$\binom {N-K} {n-k}$


Hypergeometric distribution
========================================================

Therefore the probability of obtaining $k$ bad devises in a sample of $n$ drawn from a population of $N$ where $K$ are bad is

$P(X=k)=P(single\,observation)$
</br>$\times (Number\, of\, ways\, of\, obtaining\, k)$
</br>$=\frac{1}{\binom N n}\binom K k \binom {N-K} {n-k}$

where $k \in \{\max(0, n+K-N), ... \min(K, n) \}$

Hypergeometric distribution
========================================================

Let's think about the range of $k$

$k \in \{\max(0, n+K-N), ... \min(K, n) \}$

if there are few good devices and all get selected then there are at least $n-(N-K)$ bad ones.

Hypergeometric distribution
========================================================

- Imagine we have a manufacturing process that for every 850 devices it produces per hour 50 tend to be defective ($5\%$).

- We don't have time to count them all so we select 100 at random.

- what is the probability that we choose 5 defective devices?

Hypergeometric distribution
========================================================

- From a population of N=850 
- There are K=50 that are not good 
(N-K=800 are good)

-  A sample of n=100 is chosen  

The probability that in the sample there are $k=5$ devices that are not good:

$P(X=k) =\frac{1}{\binom N n}\binom K k \binom {N-K} {n-k}$
</br>$P(X=5) =\frac{1}{\binom {850} {100}}\binom {50} {5} \binom {800} {95} = 0.17\,\, (17\%)$

Hypergeometric distribution
========================================================

Note that:

- there are 5.8% of bad devices in the population (850)
- 5 bad devises in the sample (100) represent the 5% 


Only $\sim 20\%$ of the times, we would get exactly the same proportion of bad devices as in the population because the events **are not independent**

Hypergeometric distribution
========================================================

These are not Bernoulli trials. 

- Independent Bernoulli trials will result if we inspect one device, drop it back, and take a new one (it can be the same).
- In this case, we have sampling **without replacement**
- At each draw of a device the sampling population change!

Hypergeometric distribution
========================================================

If a random variable follows a hypergeometric mass probability function

$P(X=k)=f(k)=\frac{1}{\binom N n}\binom K k \binom {N-K} {n-k}$
$k \in \{\max(0, n+K-N), ... \min(K, n) \}$

It has 

- mean: $E(X)= \mu=n*K/N=np$ 

- variance: $V(X)= np(1-p)\frac{N-n}{N-1}$ 

when $p$ is the proportion of $K$ items in an $N$-population. 

Hypergeometric distribution
========================================================


Let's compare the **Hypergeometric** and the **binomial** means and variances:

- $E(X)=np$ and variance $V(X)= np(1-p)\frac{N-n}{N-1}$

- $E_B(X)=np$ and variance $V_B(X)= np(1-p)$

The variance of the hypergeometric distribution is corrected for the sampling without replacement in a population with finite size. 



Hypergeometric distribution
========================================================

![plot of chunk unnamed-chunk-10](Lecture6-figure/unnamed-chunk-10-1.png)

Hypergeometric distribution
========================================================

![plot of chunk unnamed-chunk-11](Lecture6-figure/unnamed-chunk-11-1.png)
