Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 3</p>

Objective
========================================================

- Total probability theorem
- Independence
- Bayes' theorem


Sample space
====================================================

**Definition:**

The set of all possible values that the observations of a random experiment can take is called the sample space
of the experiment. The sample space is denoted as S.


**Definition:**

An event is a subset of the sample space of a random experiment.



Operations of events
====================================================

complement: $E'$.


- $E1\cap E2$: $E1$ **AND** $E2$

- $E1\cup E2$: $E1$ **OR** $E2$


Probability
====================================================

**Frequentist Interpretation:**

the probability P(E) of an event E in the sample space S is a function such 

- $P(S)=1$ 
- $0 \leq P(E) \leq 1$
- when $E1\cap E2=\emptyset$ $$P(E1\cup E2) = P(E1) + P(E2)$$

Frequentist interpretation: P(E) is the limiting **relative frequency** for the event E when the number of observations is infinite.

Addition Rule
====================================================
When we have three events A, B, and C: 

$P(A\cup B \cup C)=P(A) + P(B) + P(C)$
</br>$- P(A\cap B) - P(A\cap C) - P(B\cap C)$
</br>$+P(A\cap B \cap C)$

Joint and Conditional probability
====================================================

Joint probability $P(A,B)=P(A\cap B)$

|  | -- A -- | -- A' -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b> B </b>- | $P(B \cap A)$ | $P(B \cap A')$ | $P(B)$ |
| -<b> B' </b>- | $P(B' \cap A)$ | $P(B' \cap A')$ | $P(B')$|
| -<b>sum</b>-      | $P(A)$  | $P(A')$| 1 |


Conditional probability
========================================================

Conditional probability is defined as:
$$P(A|B) = \frac{P(A\cap B)}{P(B)}$$

- Diagnosis is an important application of the conditional probability


- We are now going to use it to ask different questions, using the **multiplication** and the **total probability** rules.



Multiplication rule
========================================================

For two events $A$ and $B$ we have the multiplication rule

$$P(A \cap B) =  P(A|B) P(B)$$


that follows from the definition of the conditional probability


Multiplication rule
========================================================

Hard drives have to types of errors:

- Command timeout: when a program hangs/freezes accessing the disk (SMART statistics 188).

- Offline Uncorrectable error: when writing there is an error with loss of information (SMART statistics 198).


Multiplication rule
========================================================

- The probability that a hard drive shows a timeout error is 0.02. 

- **When** there is a timeout error, the probability for an uncorrectable error is 0.0077. 

This is the real data obtained from [data.world](https://data.world/scuttlemonkey/hard-drive-reliability-sample) 

- What is the probability of a timeout **AND** uncorrectable errors?




Multiplication rule
========================================================

What are the mathematical expressions of the following two sentences?

- The probability that a hard drive shows a timeout error is 0.02.  

- **When** there is a timeout error, the probability for an uncorrectable error is 0.0077. 

- The probability of a timeout **AND** uncorrectable errors

Multiplication rule
========================================================


What are the mathematical expressions of the following two sentences?

- The probability that a hard drive shows a timeout error is 0.02:  $P(T)=0.02$ 

- **When** there is timeout error, the probability for an uncorrectable error is 0.0077: $P(U|T)=0.0077$ 

- The probability of a timeout **AND** uncorrectable errors:  $P(U \cap T)=?$ 

Multiplication rule
========================================================
From the definition of conditional probability

$$P(U|T) = \frac{P(U \cap T)}{P(T)}$$
The **multiplication rule** is

$$P(U \cap T) =  P(U|T) P(T)$$
We have have

$$P(U \cap T) =  P(U|T) P(T)=0.0077 \times 0.02 =0.00015$$

or 3 hard drives in 2000 show both errors. 




Total probability rule
========================================================


We are going to think of a situation where we observe the values of an event under all possible **conditions** and then we ask:

</br>
What is the probability of the event?



Total probability rule
========================================================

**Total probability rule**

$$P(A)= P(A|B')P(B') + P(A|B)P(B)$$

when B' and B are mutually exclusive ($B \cap B'=\emptyset$). 

The rule follows from: 
</br>$P(A)= P(A \cap S)= P(A \cap [B \cup B'])$
</br>$= P([A \cap B] \cup  [A \cap B'])$ 
</br>$=P(A \cap B) +P(A \cap B'))$
</br>$=P(A|B')P(B') + P(A|B)P(B)$


Total probability rule
========================================================

For many mutually exclusive events $\{E1, E2, ...En\}$, the **total probability rule** is

$$P(A)= P(A|E1)P(E1) + P(A|E2)P(E2) + ... +P(A|En)P(En)$$



Total probability rule
========================================================

What is the probability of cancer $P(C)$ when we know its conditional probabilities for men and women? 

Cancer is strongly dependent on sex

Probability of cancer for women: $P(C|W)=0.05$ 
</br>Probability of cancer for men: $P(C|W')=0.07$
</br>Probability of being a woman: $P(W)=0.5$
</br>Probability of being a man: $P(W')=0.5$


Total probability rule
========================================================

- indiviauls with cancer = men with cancer $\cup$ women with cacner
- $C= (C\cap W') \cup (C\cap W)$

$(C\cap W')$ and $(C\cap W)$ are mutually exclusive then

$$P(C)= P(C\cap W') + P(C\cap W)$$

Total probability rule
========================================================
$P(C)= P(C\cap W') + P(C\cap W)$
</br>$= P(C|W')P(W') + P(C|W)P(W)$

The probability of having cancer is 
- the probability of having cancer when being a man times the probability of being a man 

**plus**

- the probability of having cancer when being a woman times the probability of being a woman 

Total probability rule
========================================================

$P(C)= P(C|W')P(W') + P(C|W)P(W)$
</br>$= 0.07\times 0.5 + 0.05\times 0.5$
</br>$= 0.06$

It's clearly in between the conditional probabilities (0.07, 0.05)




Statistical independence
========================================================

In many applications, we want to know if the knowledge of one event conditions the outcome of another event. 

- there are cases where we want to know if the events are not conditioned 


Statistical independence
========================================================

Consider conductors for which we measure their surface flaws and if their conduction capacity is defective

|  | -Surface flaws: yes -- | -- Surface flaws: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Defective: yes</b>- | 2 | 18 | 20 |
| -<b>Defective: no </b>- | 38 | 342 | 380 |
| -<b>sum</b>-      | 40  | 360| 400 |

Does the probability of having flaws increase the probability of being defective?

Statistical independence
========================================================

We compute the relative joint frequencies and suppose they estimate correctly the joint probabilities when $n=400$   

|  | - flaws (F) -- | -- no flaws (F') -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>defective (D) </b>- | $P(D \cap F)=0.005$ | $P(D \cap F')=0.045$ | $P(D)=0.05$ |
| -<b>no defective (D') </b>- | $P(D' \cap F)=0.095$ | $P(D' \cap F')=0.855$ | $P(D')= 0.95$|
| -<b>sum</b>-      | $P(F)=0.1$  | $P(F')=0.9$| 1 |

The marginals are
- $P(D)=P(D \cap F) + P(D \cap F')=0.05$
- $P(D')=P(D' \cap F) + P(D' \cap F')= 0.95$. 



Statistical independence
========================================================

What is the conditional probability of observing a defective conductor if they have a flaw?

|  | -- F -- | -- F' --
| --------- | --------- | -------- |
| -<b> D </b>- | P(D<span>&#124;</span>F)=$P(D\cap F)/P(F)$ = 0.05 | P(D<span>&#124;</span>F')=$P(D\cap F')/P(F')$=0.05 | 
| -<b> D' </b>- | P(D'<span>&#124;</span>F)=$P(D'\cap F)/P(F)$=0.95 | P(D'<span>&#124;</span>F')=$P(D'\cap F')/P(F')$=0.95 | 
| -<b>sum</b>-      | 1                | 1               |

The marginals and the conditional probabilities are the same!

- $P(D|F)=P(D|F')=P(D)$
- $P(D'|F)=P(D'|F')=P(D')$


Statistical independence
========================================================


The probability of observing a defective conductor **does not** depend on having observed or not a flaw.  

$$P(D) = P(D|F)$$


Statistical independence
========================================================


Two events A and B are statistically independent if

- $P(A|B)=P(A)$; A is independent of B
- $P(B|A)=P(B)$; B is independent of A

and by the multiplication rule, their joint probability is

- $P(A\cap B)=P(A|B)P(B)=P(A)P(B)$

the multiplication of their marginal probabilities.


Statistical independence
========================================================



|  | -- F -- | -- F' -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b> D </b>- | $P(D \cap F)=0.005$ | $P(D \cap F')=0.045$ | $P(D)=0.05$ |
| -<b> D' </b>- | $P(D' \cap F)=0.095$ | $P(D' \cap F')=0.855$ | $P(D')= 0.95$|
| -<b>sum</b>-      | $P(F)=0.1$  | $P(F')=0.9$| 1 |


Confirm that all the entries of the matrix are the product of the marginals. 

For example: 

- $P(F)P(D)= P(D \cap F)$
- $P(D')P(F')=P(D' \cap F')$



Statistical independence
========================================================

Two coins: S={(H,H), (H,T), (T,H), (T,T)}

|  | -- H -- | -- T -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b> H </b>- | $P(H \cap H)=1/4$ | $P(H \cap T)=1/4$ | $P(H)=1/2$ |
| -<b> T </b>- | $P(T \cap H)=1/4$ | $P(T \cap T)=1/4$ | $P(T)= 1/2$|
| -<b>sum</b>-      | $P(H)=1/2$  | $P(T)=1/2$| 1 |

- Obtaining a head in the first coin does not condition obtaining a tail in the result of the second coin $P(T|H)=P(T)=1/2$ 
- the proabability of abtaining a head and then a tail is the product of each independent outcome $P(H,T)=P(H)*P(T)=1/4$


Bayes' theorem
========================================================
Let's remember our diagnostics example.


Each individual is a random experiment with two measurements: (Infection, Test)



|  | -Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | $P(pos,yes)$ | $P(pos,no)$ | $P(pos)$ |
| -<b>Test: negative</b>- | $P(neg,yes)$ | $P(neg,no)$ | $P(neg)$ |
| -<b>sum</b>-      | $P(yes)$  | $P(no)$| $1$ |


We assumed **we knew** all the entries in the **joint probability matrix**.

Bayes' theorem
========================================================

we calculated the **conditional matrix** 

|  | -Infection: Yes -- | -- Infection: No -- |
| --------- | --------- | -------- |
| -<b>Test: positive</b>- | P(positive<span>&#124;</span>yes) | P(positive<span>&#124;</span>no) | 
| -<b>Test: negative</b>- | P(negative<span>&#124;</span>yes) | P(negative<span>&#124;</span>no) | 
| -<b>sum</b>-      | 1                | 1               |


- Sensitivity: The probability of testing positive **if** having the disease $P(positive|yes)$

- Especificity: The probability of testing negative **if** not having the disease $P(negative|no)$

Bayes' theorem
========================================================

and we also calculated the other **conditional matrix** 

|  | -Infection: Yes -- | -- Infection: No -- | --sum-- |
| --------- | --------- | -------- | -------- |
| -<b>Test: positive</b>- | P(yes<span>&#124;</span>positive) | P(no<span>&#124;</span>positive) |  1 |
| -<b>Test: negative</b>- | P(yes<span>&#124;</span>negative) | P(no<span>&#124;</span>negative) | 1 |


- Positive predictive value: The probability of having the disease **if** tesing positive $P(yes |positive)$

- Negative predictive value: The probability of not having the disease **if** tesing negative $P(no |negative)$


Bayes' theorem
========================================================

Now let's imagine a current real situation. 

- PCRs for coronavirus have been (performed)[https://www.nejm.org/doi/full/10.1056/NEJMp2015897] in people in the hospital who we are sure to be infected. They have a sensitivity of 70%. They have also been tested on the lab in conditions of no infection with 96% sensitivity. 

- A prevalence study in Spain showed that $P(yes)=0.05$, $P(no)=0.95$ before summer. 

With this data, what is the probability that you are infected if you are positive in a PCR: $P(yes|positive)$? 


Bayes' theorem
========================================================

To study the performance of a new diagnostic test:

- you select specimens that are inadequate (disease: **yes**) and apply the test, trying to find its sensitivity: $P(positive|yes)$ (0.70 for PCRs)


- you select specimens that are adequate (disease: **no**) and apply the test, trying to find its especificity: $P(negative|no)$ (0.96 for PCRs)

But when you apply the test in the real world you don't know if your specimen is inadequate: you want to know what is the probability of being **inadequate** *if* your test is **positive**: $P(yes|positive)$  


Bayes' theorem
========================================================

Let's assume that the frequencies are from large enough $n$ to **estimate** the probabilities

|  | -Infection: Yes -- | -- Infection: No -- |
| --------- | --------- | -------- |
| -<b>Test: positive</b>- | P(positive<span>&#124;</span>yes)=0.7 | P(positive<span>&#124;</span>no)=0.06 | 
| -<b>Test: negative</b>- | P(negative<span>&#124;</span>yes)=0.3 | P(negative<span>&#124;</span>no)=0.94 | 
| -<b>sum</b>-      | 1                | 1               |

From this matrix, can we obtain $P(yes|positive)$?


Bayes' theorem
========================================================

But we don't know this matrix

|  | -Infection: Yes -- | -- Infection: No -- | --sum-- |
| --------- | --------- | -------- | -------- |
| -<b>Test: positive</b>- | P(yes<span>&#124;</span>positive) | P(no<span>&#124;</span>positive) |  1 |
| -<b>Test: negative</b>- | P(yes<span>&#124;</span>negative) | P(no<span>&#124;</span>negative) | 1 |


How can we pass from one matrix to the other?, that is revesing the conditioning: 

$P(positive|yes) \rightarrow P(yes|positive)$

Bayes' theorem
========================================================

We want to find out what is the probability of being infected if the test is positive $P(yes|positive)$, when by experiments we have, 

- the probability of testing positive if infected $P(positive | yes)$ (sensitivity)

- the probability of testing negative if infected $P(negative | no)$ (especificity)

We apply the Bayes' theorem. Let's derive it...


Bayes' theorem
========================================================

From the definition of the conditional probability 

$$P(positive|yes)=\frac{P(positive \cap yes)}{P(yes)}$$


we have the **multiplication rule** 

$$P(positive \cap yes)= P(positive|yes) \times P(yes)$$

where we write the **joint** probability of two events in terms of the conditional probability and the marginal probability. 

Bayes' theorem
========================================================


Note that 

$P(positive \cap yes)=P(yes \cap positive)$

applying the multiplication rule at both sides we have

$P(positive|yes) \times P(yes) = P(yes|positive) \times P(positive)$

and then we have Bayes' theorem:


$P(yes|positive)  = \frac{P(positive|yes) \times P(yes)}{P(positive)}$


Bayes' theorem
========================================================


Bayes' theorem:

$P(yes|positive)  = \frac{P(positive|yes) \times P(yes)}{P(positive)}$

We know 
- the sensitivity $P(positive|yes)$ 
- the prevalence $P(yes)$ 

and need the probability of testing positive $P(positive)$ in the population. 


Bayes' theorem
========================================================

We need the **Total probability rule**, which is the following


|  | -Infection: yes -- | -- Infection: no -- |  -- sum -- |
| --------- | --------- | -------- |  -------- |
| -<b>Test: positive</b>- | $P(pos\cap yes)$ | $P(pos\cap no)$ | $P(pos)$ |
| -<b>Test: negative</b>- | $P(neg\cap yes)$ | $P(neg\cap no)$ | $P(neg)$ |
| -<b>sum</b>-      | $P(yes)$  | $P(no)$| $1$ |


the marginal $P(positive)$ can be written in terms of the conditional probabilities of disjoint infection events.

$P(positive)= P(positive\cap yes) + P(positive\cap no)$ 
</br>$P(possitive|yes)P(yes) + P(positive|no)P(no)$


Bayes' theorem
========================================================


Now Bayes' theorem in terms of the probabilities of the test events is 

$P(yes|positive)  = \frac{P(positive|yes) \times P(yes)}{P(possitive|yes)P(yes)+P(positive|no)P(no)}$

we know:
-  $P(positive|yes)=0.70$ and $P(positive|no)=1- P(negative|no)=0.06$ 

- the probability of infection and not infection in the population:  $P(yes)=0.05$  and $P(no)=1-P(yes)=0.95$. 
</br>Therefore: $P(yes|positive)=0.47$ 

Bayes' theorem
========================================================

**Theorem**

If $E1, E2, ..., Ek$ are $k$ mutually exclusive and exhaustive events and $B$ is any event,

$$P(Ei|B)=\frac{P(B|Ei)P(Ei)}{P(B|E1)P(E1) +...+ P(B|Ek)P(Ek)}$$



Bayes' theorem
========================================================

Let's now apply it to the probability of not being infected if the test is negative

$P(no|negative)  = \frac{P(negative|no)  P(no)}{P(negative|no) P(no)+P(negative|yes)P(yes)}$

Substitution of all the values gives

$P(no|negative)=0.98$

Tests are good to rule out infections and not so good to confirm them. 




Summary
========================================================

- A and B are independent when either

$P(A|B)=P(A)$

$P(B|A)=P(B)$

$P(A\cap B)=P(A)P(B)$


- Multiplication Rule

$P(A \cap B) =  P(A|B) P(B)$




Summary
========================================================


- Total probability Rule

$P(A)= P(A|E1)P(E1) + P(A|E2)P(E2) + ... +P(A|En)P(En)$,
when $\{E1, E2, ...En\}$ are mutually exclusive

- Bayes' theorem
$P(Ei|B)=\frac{P(B \cap Ei)}{P(B \cap E1) + ...+P(B \cap E1)}$

