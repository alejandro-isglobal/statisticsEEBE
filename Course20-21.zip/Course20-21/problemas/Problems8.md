Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 8 (Tema 7 parte 2)</p>




Objectives
========================================================

- Problems on confidence intervals



Summary
========================================================
- $(1-\alpha)$*100% confidence intervals for the means:

when $X \hookrightarrow N(\mu_X, \sigma_X^2)$

1) and we **know** $\sigma_X^2$ then 

$(l,u) = (\bar{x} - z_{\alpha/2}\sigma_{X}/\sqrt{n},\bar{x} + z_{\alpha/2}\sigma_{X}/\sqrt{n})$

2) and we **don't know** $\sigma_X^2$ then 

$(l,u) = (\bar{x} - t_{\alpha/2, n-1}s/\sqrt{n},\bar{x} + t_{\alpha/2, n-1}s/\sqrt{n})$


Summary
========================================================

- $(1-\alpha)$*100% confidence intervals for the variance:

when $X \hookrightarrow N(\mu_X, \sigma_X^2)$

$(l,u) = (\frac{s^2 (n-1)}{\chi^2_{\alpha/2,n-1}},\frac{s^2(n-1)}{\chi^2_{1-\alpha/2,n-1}})$


- $(1-\alpha)$*100% confidence intervals for the mean:

when $X \hookrightarrow Bin(n,p)$ and $\hat{p}=X/n$, $n\hat{p}$ and $n(1-\hat{p})$ $>5$

$(l,u)=(\hat{p}-z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2},  \hat{p}+z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2})$

Summary
========================================================


**Remember**: $\zeta_{\alpha/2}=F^{-1}(1-\alpha/2)=$<code>qXXX(1-alpha/2)</code>


- $z_{\alpha/2}=$<code>qnorm(1-alpha/2)</code>

- $t_{\alpha/2, n-1}=$<code>qt(1-alpha/2, n-1)</code>

- $\chi^2_{\alpha/2, n-1}=$<code>qchisq(1-alpha/2, n-1)</code>


Tema 7:Problem 1
========================================================

Consider:

- $n=5$
- $\alpha=1-0.95=0.05$
- $CI=(229.7,233.5)$

a. $P(\mu \in (229.7,233.5)) = 0.95$?

No. $\mu$ is not a random variable it is a parameter of a probability function. Probabilities are defined only for random variables. 



Tema 7: Problem 1
========================================================

b. compute $\bar{x}$ and $s$


we are given $95\%$ confidence interval

$CI=(l,u)=(229.7,233.5)$


Let's remember the definition: 

The $95\%$ **random** confidence interval 

$(L,U) = (\bar{X} - f_{sup},\bar{X} - f_{inf})$ is such that 


$P(\bar{X} - f_{sup} \leq \mu \leq \bar{X} - f_{inf})=P(f_{inf} \leq \mu-\bar{X} \leq f_{sup})=0.95$


Tema 7: Problem 1
========================================================

if: 

-  $X \hookrightarrow N(\mu_X, \sigma_X^2)$ and 

- and we **do not know** the variance $\sigma_X^2$

Then:
</br>$f_{inf}=t_{0.975,n-1}*S/\sqrt{n}$
</br>$f_{sup}=t_{0.025,n-1}*S/\sqrt{n}$

and the observed CI is:
$(l,u) = (\bar{x} - t_{0.025,n-1}s/\sqrt{n},\bar{x} - t_{0.975, n-1}s/\sqrt{n})$

Tema 7: Problem 1
========================================================

or:

$(l,u) = (\bar{x} - t_{0.025,n-1}s/\sqrt{n},\bar{x} + t_{0.025, n-1}s/\sqrt{n})$


where 

$t_{0.975,n-1}=F_{t,n-1}^{-1}(0.025)=$<code>qt(0.025, 4) </code>$= -2.77$

$t_{0.025,n-1}=F_{t,n-1}^{-1}(0.975)=$<code>qt(0.975, 4) </code>$= 2.77$


Tema 7: Problem 1
========================================================

Therefore we are given 

$(\bar{x} - 2.77s/\sqrt{5},\bar{x} +2.77 s/\sqrt{5})=(229.7,233.5)$

and to equations to solve for $\bar{x}$ and $2$:

i. $\bar{x}  -1.23s=229.7$

ii. $\bar{x} +1.23s=233.5$


With solutions: 

$\bar{x}=(229.7+233.5)/2=231.6$ and $s=(233.5-\bar{x})/1.23=1.53$



Tema 7: Problem 1
========================================================


<img src="./tprob1.PNG" style="width:50%"  align="center">

Tema 7: Problem 1
========================================================

c. compute $99\%$ CI:

Now we have:

$(l,u) = (\bar{x} - t_{0.005,n-1}s/\sqrt{n},\bar{x} - t_{0.995, n-1}s/\sqrt{n})$

We leave out a total of $1\%$.

or

$(l,u) = (\bar{x} - t_{0.005,n-1}s/\sqrt{n},\bar{x} + t_{0.005, n-1}s/\sqrt{n})$


Tema 7: Problem 1
========================================================

where 

$t_{0.995,n-1}=F_{t,n-1}^{-1}(0.005)=$<code>qt(0.005, 4) </code>$= -4.60$

$t_{0.005,n-1}=F_{t,n-1}^{-1}(0.995)=$<code>qt(0.995, 4) </code>$= 4.60$

then: $(\bar{x} - 4.60s/\sqrt{5},\bar{x} +4.60 s/\sqrt{5})=(228.45,234.75)$


Tema 7: Problem 1
========================================================


<img src="./tprob12.PNG" style="width:50%"  align="center">




Tema 7: Problem 2
========================================================



Consider:  
\[
F(x)=
\begin{cases}
    1- e^{-2x} ,& \text{if } x \geq 0\\
    0,& otherwise 
\end{cases}
\] 

a. Compute the quartiles of $X$

$P(X\leq q_c)=F(q_c)=c$

Where $c={0.25,0.5,0.75}$

Then 

$q_c=F^{-1}(c)=-\frac{1}{2}\ln(1-c)$

and $q_{0.25}=-\frac{1}{2} \ln(1-0.25)=0.14$, $q_{0.5}=0.35$, $q_{0.75}=0.69$


Tema 7: Problem 2
========================================================

b. compute $P(X \leq \mu_X | X > q_{0.5})$, 

since $F(X)$ is the exponential distribution with parameter $\lambda=2$ then 

$E(X)=\mu_X=\frac{1}{\lambda}=1/2$ and $V(X)=\sigma^2_X=\frac{1}{\lambda^2}=\frac{1}{4}$

$P(X \leq \mu_X | X > q_{0.5})=\frac{ P(q_{0.5}< X \leq \mu_X) } {P(X > q_{0.5})}=\frac{F(\mu_X)-F(q_{0.5})}{1-F(q_{0.5})}$

$=\frac{[1-e^{2/2}]+0.5}{0.5}=0.242$


Tema 7: Problem 2
========================================================

c. compute:$P(\bar{X}>2/3)$ for $n=36$


Since $n=36>30$ then $\bar{X} \hookrightarrow N(\mu_X, \sigma_X^2/n)$ by the CLT

$\sigma_\bar{X}=\sigma_X/\sqrt{n}=\frac{1/2}{6}=1/12$

Then 

$P(\bar{X}>2/3)= 1 - P(\bar{X} \leq 2/3)$

Standardizing

$1 - P(\frac{\bar{X}-\mu_\bar{X}}{\sigma_{\bar{X}}} \leq \frac{2/3-1/2}{1/12})=1-P(Z \leq 2)=1-\Phi(2)=$<code>1-pnorm(2)</code>$=0.02275$


Tema 7: Problem 2
========================================================

d. compute $95\%$  CI for the mean of a normal variable $Y$ with known variance $\sigma^2_Y=9$ and the following observations of a 4-random sample:  $22.2, 23.8, 21.6, 20.4$

- We have: $\bar{y}=22$ and $\sigma_Y=3$

if: 

-  $Y \hookrightarrow N(\mu_Y, \sigma_Y^2)$ and 

- and we **know** the variance $\sigma_Y^2$

the observed CI is:
$(l,u) = (\bar{y} - z_{0.025}\sigma_Y/\sqrt{n},\bar{y} - z_{0.975}\sigma_Y/\sqrt{n})$

for $f_{inf}=z_{0.975}*\sigma_Y/\sqrt{n}$ and $f_{sup}=z_{0.025}*\sigma_Y/\sqrt{n}$



Tema 7: Problem 2
========================================================

where 

$z_{0.975,n-1}=\Phi^{-1}(0.025)=$<code>qnorm(0.025) </code>$= -1.959$

$z_{0.025,n-1}=\Phi^{-1}(0.975)=$<code>qnormt(0.975) </code>$= 1.959$


then 

$(l,u) = (\bar{y} - z_{0.025}\sigma_Y/\sqrt{n},\bar{y} + z_{0.025}\sigma_Y/\sqrt{n})$


$(l,u) = (22 - 1.959*3/\sqrt{4},22 + 1.959*3/\sqrt{4})=(19.06,24.94)$


Tema 7: Problem 3
========================================================

Consider:

- $n=1000$
- $x=17$

Where $X \hookrightarrow Bin(n,p)$

Remember: If we define the average $\bar{K}$ of a Bernoulli trial ($k=0, 1$): 

- $\bar{K}=\sum_{i=1}^n K_i=X/n$, $E(\bar{K})=E(K)=p$
- $S^2=\bar{K}(1-\bar{K})$ 

The $(1-\alpha)100\%$ CI associated with a set of observations is 

$CI=(l,u)=(\bar{k}-z_{\alpha/2}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2},  \bar{k}+z_{\alpha/2}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2})$

when $np$ and $n(p-1)>5$



Tema 7: Problem 3
========================================================

a. Then we have: $\hat{p}=\bar{k}=0.017$

$n\hat{p}=17$ and $n(1-\hat{p})=983>5$ and we can use the approximation:

$Z=\frac{X-\mu_X}{\sigma_X}=\frac{X-E(X)}{\sqrt{V(X)}}= \frac{X-np}{\big[np(1-p) \big]^{1/2}}= \frac{\bar{K}-p}{\big[p(1-p)/n \big]^{1/2}}\rightarrow N(0,1)$


Tema 7: Problem 3
========================================================


b. compute the $99\%$ confidence interval then $\alpha=0.01$


$CI=(l,u)=(\bar{k}-z_{0.005}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2},  \bar{k}+z_{0.005}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2})$

Since: $z_{0.005}=\Phi^{-1}(0.995)=$<code>qnorm(0.995)</code>$=2.575829$

Then 

$CI=(0.006474,  0.027526)$

or

$\hat{p}=0.017 \pm 0.01$

c. the estimate $\hat{p}\leq 0.02752$ we cannot guarantee the conditions of the client with $99\%$ confidence. 


Tema 7: Problem 5
========================================================

Consider:

- $P(Y=0)=a$ 
- $P(Y=1)=1-a$
- $na(1-a)\geq 8$

a. Compute $n$ such that for the CI $(l,u)$, $D=u-l$ is maximum.

$Y$ is a Bernoulli variable with $p=1-a$ and as $n(1-p)p\geq 8$ then  

$CI=(\bar{y}-z_{\alpha/2}\big[\frac{\bar{y}(1-\bar{y})}{n} \big]^{1/2},  \bar{y}+z_{\alpha/2}\big[\frac{\bar{y}(1-\bar{y})}{n} \big]^{1/2})$


$D=  2 z_{\alpha/2}\big[\frac{\bar{y}(1-\bar{y})}{n} \big]^{1/2}$ is maximum when $D^2$ is maximum.


Tema 7: Problem 5
========================================================

$\frac{d D^2}{d\bar{y}}=\frac{(2z_{\alpha/2})^2}{n} (1-2\bar{y})=0$
then 

$D$ is maximum when the estimated proportion $\bar{y}=1/2$ or $D_{max}=\frac{z_{\alpha/2}}{\sqrt{n}}$


Tema 7: Problem 5
========================================================

b. Consider $D=0.02$ and $\alpha=0.10$ for $90\%$ confidence. Compute minimum $n$.

$z_{\alpha/2}=z_{0.05}=\Phi^{-1}(0.95)=$<code>qnorm(0.95)</code>$=1.644854$

$D_{max}=0.02=\frac{1.644854}{\sqrt{n_{min}}}$ then

$n_{min}=(1.644854/0.02)^2= 6763.862$ 

or 

$n \geq 6764$ (differences with results are because from tables $z_{0.05} \sim 1.65$)

Tema 7: Problem 6
========================================================


Consider:

- $682, 553, 555, 666, 657, 649, 522, 568, 700, 558$
- $X \hookrightarrow N(\mu_X, \sigma^2_X)$

a. Compute $95\%$ CI

- $\bar{x}= 611$
- $s=65.51$
- $n=10$
- As we don't know the variance of $X$ then we use $s$

the observed CI is:

$(l,u) = (\bar{x} - t_{0.025,n-1}s/\sqrt{n},\bar{x} - t_{0.975, n-1}s/\sqrt{n})$

$= (\bar{x} - t_{0.025,n-1}s/\sqrt{n},\bar{x} + t_{0.025, n-1}s/\sqrt{n})$



Tema 7: Problem 6
========================================================


$t_{0.025,n-1}=F_{t,n-1}^{-1}(0.975)=$<code>qt(0.975, 9) </code>$=  2.26$

then: 
$(l,u) = (\bar{x}-2.26s/\sqrt{n},\bar{x}+2.26s/\sqrt{n})=(564.135,657.865)$


Tema 7: Problem 6
========================================================


<img src="./tprob13.PNG" style="width:50%"  align="center">



Tema 7: Problem 9
========================================================

Consider:

- $n=9$
- the $90\%$ CI is $(118.25,123.55)$
- $X \hookrightarrow N(\mu_X, \sigma_X^2)$
- We know $\sigma_X$


the observed CI is:
$(l,u) = (\bar{x} - z_{0.05}\sigma_X/\sqrt{n},\bar{x} + z_{0.05}\sigma_X/\sqrt{n})$


Tema 7: Problem 9
========================================================

where 

$z_{0.05,n-1}=\Phi^{-1}(0.95)=$<code>qnorm(0.95)</code>$= 1.644$

then we have two equations

i. $l= \bar{x} - 1.644*\sigma_X/\sqrt{9}=118.25$

ii. $u= \bar{x} + 1.644*\sigma_X/\sqrt{9}=123.55$

a. y b. Compute $\bar{x}$ and $\sigma^2_X$ 


solving i and ii for $\bar{x}$ and $\sigma^2_X$

$\bar{x}=(118.25+123.55)/2=120.9$ and $\sigma_X=3*(123.55-\bar{x})/1.644=4.83$ or $\sigma_X^2= 23.36$




Tema 7: Problem 9
========================================================

c. Compute $97\%$ confidence interval, then $\alpha=0.03$ 

Remember:

$(l,u) = (\bar{x} - z_{\alpha/2}\sigma_X/\sqrt{n},\bar{x} +z_{\alpha/2}\sigma_X/\sqrt{n})$

as $z_{\alpha/2}=z_{0.015}=\Phi^{-1}(0.985)=$<code>qnorm(0.985)</code>$=2.170$ then 

$(l,u) = (120.9 - 2.170*4.83/\sqrt{9},120.9 + 2.170*4.83/\sqrt{9})$

$=(117.4063,124.3937)$


Tema 7: Problem 9
========================================================

d. for $d=123.55-118.25=5.3=(u-l)$ compute $n$

$d=u-l=2*2.170*4.83/\sqrt{n}=5.3$

then 

$n=(\frac{2*2.170*4.83}{5.3})^2=15.64 \sim 16$



Tema 7: Problem 25
========================================================

consider:

- $\bar{x}=0.5354$

- $s=0.3479$

- $n=51$

- $\alpha=0.05$

a. the $95\%$ CI for the variance


$(l,u) = (\frac{s^2 (n-1)}{\chi^2_{\alpha/2,n-1}},\frac{s^2(n-1)}{\chi^2_{1-\alpha/2,n-1}})$


Tema 7: Problem 25
========================================================
$l = \frac{s^2 (n-1)}{\chi^2_{\alpha/2,n-1}}$

$\chi^2_{\alpha/2,n-1}=\chi^2_{0.025,50}=$<code>qchisq(1-0.025, 50)</code>$=71.42$

then 
$l=0.3479^2*50/71.42=0.0847$


Tema 7: Problem 25
========================================================

$u = \frac{s^2(n-1)}{\chi^2_{1-\alpha/2,n-1}}$

$\chi^2_{1-\alpha/2,n-1}=\chi^2_{0.975,50}=$<code>qchisq(1-0.975, 50)</code>$=32.35$

then 
$u=0.3479^2*50/32.35=0.1870$

$CI=(l,u)=(0.0847, 0.1870)$



Tema 7: Problem 25
========================================================


consider:

- $X=17$, number of fisheries with concentrations greater than $0.700$ ppm

- $\alpha=0.01$

- then $\hat{p}=\bar{k}=1/3$ where $K$ is a Bernoulli trial.


Tema 7: Problem 25
========================================================

since $n\hat{p}=17$ and $n(1-\hat{p})=34$ $>5$ then CI is 


$(l,u)=(\hat{p}-z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2},  \hat{p}+z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2})$

since:

$z_{\alpha/2}=$<code>qnorm(1-0.005)</code>$=2.575$

then 

$(l,u)=(1/3+2.575*\sqrt{\frac{1/3*2/3}{51}}, 1/3+2.575*\sqrt{\frac{1/3*2/3}{51}}$
$=(0.1634, 0.5033)$


