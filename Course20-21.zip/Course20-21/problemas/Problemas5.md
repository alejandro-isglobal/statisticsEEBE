Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 5</p>




Objectives
========================================================


- Revisar problemas tema 4 (2 parcial)
- Problemas tema 6 (3 parcial)
- Problemas tema 7 (3 parcial)


Tema 4: Summary
====================================================

| quantity | model | data |
| -------- | ----- | ---- |
| probability mass function/relative frecuency         |  $P(X=x_i)=f(x_i)$ | $f_i=\frac{n_i}{n}$ |
| cumulative probability function/cumulative relative frequency          |  $F(x_i)=P(X \leq x_i)$ | $F_i=\sum_{j\leq j} f_i$   |
| mean/average (1st-moment about the origin) | $\mu$, $\mu'_1$, $E(X)=\sum_{i(outcome)} x_i f(x_i)$ | $\bar{x}=\sum_{j(observation)} x_j/n$ |   
| variance (2nd-moment about the mean) |$\sigma^2$, $\mu_2$, $V(X)=\sum_i (x_i-\mu)^2 f(x_i)$ | $s^2=\sum_j (x_j-\bar{x})^2/(n-1)$ |   
| standard deviation | $\sigma$, $\sqrt{V(X)}$ | $s$ |
| 2nd-moment about the origin | $\mu'_2$,$E(X^2)=\sum_i (x_i)^2 f(x_i)$ | $M'_2= \sum_j x_j^2/n$|

tema 4: Summary
====================================================

- $V(x)=E(X^2)-\mu^2$
- $E(X^r)=\mu'_r$ r-moment about the **origin**
- $E((X-\mu)^r)=\mu_r$ r-moment about the **mean**



Tema 4: Problem 9
========================================================
Given the cumulative distribution for a random variable X

\[
    F(x)= 
\begin{cases}
0, & x \lt -1 \\
\frac{1}{80}(17+16x-x^2),& x \in [-1,7)\\
1,& x \geq 7\\
\end{cases}
\]


a) compute $P(X>0)$

$P(X>0)= 1- P(X\leq0) = 1-\frac{17}{80}=\frac{63}{80}$


Tema 4: Problem 9
========================================================

b) compute $E(X)=\int_{-\infty}^\infty x f(x)dx$ 

We need to find $f(x)$ by differentiation

\[
    f(x)= 
\begin{cases}
0, & x \notin (1,7) \\
\frac{16}{80}-\frac{2x}{80},& x \in (-1,7)\\
\end{cases}
\]

Then: $E(X)=\int_{-1}^7 \frac{16}{80}x-\frac{2}{80}x^2 dx$
</br>$= \frac{16}{80}\frac{x^2}{2}-\frac{2}{80}\frac{x^3}{3}\Big|_1^7$
</br>$= \frac{48}{10}-\frac{344}{120}=1.933$


Tema 4: Problem 9
========================================================

c) compute $P(X>0|X<2)$

$P(X>0|X<2)=\frac{P(X>0 \cap X<2)}{P(X<2)}$
</br>$=\frac{P(0 \lt X \lt 2)}{P(X<2)}$
</br>$=\frac{F(2)-F(1)}{F(2)}=\frac{45-17}{17}=\frac{28}{45}$



Tema 4: Problem 10
========================================================
Given the probability mass function and distribution

| x | $f(x)=P(X=x)$ | F(x) |
|-----|---------|---------|
|0|0.15||
|1|a||
|2|b|0.7|
|3|c||
|4|0.2 ||

and  $E(X)=2$


Tema 4: Problem 10
========================================================
a) find the values of $a$, $b$ and $c$. 

We solve the system of equations:
</br>i) normalization: $\sum_1^5 f(x_i)=1$
</br>$a+b+c+0.35 = 1$
</br>$a+b+c-0.65 = 0$
</br>ii) expectation: $E(X)=\sum_1^5 x_if(x_i)=2$
</br>$a+2b+3c+0.2*4=2$
</br>$a+2b+3c-1.2=0$

Tema 4: Problem 10
========================================================

and
</br>iii) value of $F(2)=0.7$
</br>$1.5+a+b=0.7$
</br>$a+b-0.55=0$
</br>The solution of the system is: $a=0.2$, $b=0.35$, $c=0.1$

b) compute the $E(X)$ and $V(X)$
</br>$E(X)=\sum_i^m x_i*P(X=x_i)=1*0.2+2*0.35+3*0.1+4*0.2=2$
</br>$V(X)=E(X^2)+E(X)^2$
</br>$=1^2*0.2+2^2*0.35+3^2*0.1+4^2*0.2-2^2=1.7$

Tema 4: Problem 10
========================================================

c) if $Y=-5+10X$ then $E(Y)=5+10*E(X)=25$ and </br>$V(Y)=10^2*V(X)=170$



Tema 4: Problem 11
========================================================
Given 

\[
    f(x)= 
\begin{cases}
\frac{c}{x^3}, & x \geq 1 \\
0,& x < 1\\
\end{cases}
\]

a) compute $c$ so that the function is a probability density function and then $E(X)$.
</br>$\int_1^\infty\frac{c}{x^3}=-\frac{1}{2}c x^{-2}\Big|_1^\infty=\frac{1}{2}c=1$ then $c=2$

then
</br>$E(X)=\int_1^\infty \frac{2}{x^2}dx = -2x^{-1}\Big|_1^\infty=2$


Tema 4: Problem 11
========================================================

b) compute $F(X)$

$F(X)=\int_1^x \frac{2}{t^3}dt=\frac{1}{2}2t^{-2}\Big|_1^x=-\frac{1}{x^2}+1$


b) compute $\frac{P(X \leq 2.5)}{P(X\leq 10)}$

$\frac{P(x\leq 2.5)}{P(x\leq 10)}=\frac{-1/(2.5^2)+1}{-1/(10^2)+1}=0.84$



Tema 6: Summary
========================================================

We learned that when $X_i$ are all independent repetitions of the random experiment $X \hookrightarrow N(\mu_X, \sigma_X^2)$ then 

- $\bar{X} \hookrightarrow N(\mu_X, \sigma_X^2/n)$
</br>(also satisfied when $n$ is large regardless of how $X$ distributes: CLT)

- $S^2 \hookrightarrow \chi^2(n-1)$


And in general, no matter how $X$ distributes:

- $E(\bar{X})=E(X)=\mu_X$ and $V(\bar{X})=\frac{\sigma^2_X}{n}$

- $E(S^2)=V(X)=\sigma^2_X$


Tema 6: Summary
========================================================


<img src="./null0.JPG" style="width:35%"  align="center">


Tema 6: Summary
========================================================


**Definition**

Given a random sample $X_1,...X_n$  a **statistic** is any real value function of the random variables that define the random sample: $f(X_1,...X_n)$

- $\bar{X}=\frac{1}{N} \sum_{j=1..N} X_j$ 
- $S^2=\frac{1}{n-1}\sum_{i=1}^n (X_i-\bar{X})^2$
- $\max{X_1, X_n}$

are statistics


Tema 6: Problem 1
========================================================

- $T_{1/2}=100$
- $\sigma_{X}=30h$
- $n=50$

Therefore 

- $\sigma_{\bar{X}}=\frac{\sigma_{X}}{\sqrt{n}}=30h/\sqrt{50}$

a. compute: $P(|\bar{X} - T_{1/2}| \leq 1)$

$P(|\bar{X} - T_{1/2}| \leq 1)=P(-1\leq \bar{X} - T_{1/2} \leq 1)$


Tema 6: Problem 1
========================================================


Let's devide by $\sigma_{\bar{X}}$
</br>$=P(\frac{-1}{\sigma_{\bar{X}}}\leq \frac{\bar{X} - T_{1/2}}{\sigma_{\bar{X}}} \leq \frac{1}{\sigma_{\bar{X}}})$

since $n>30$ by CLT then $Z=\frac{\bar{X} - T_{1/2}}{\sigma_{\bar{X}}} \hookrightarrow N(\mu=0,\sigma^2=1)$

Tema 6: Problem 1
========================================================

We use $\Phi(z)$

$P(|\bar{X} - T_{1/2}| \leq 1)=\Phi( \frac{1}{\sigma_{\bar{X}}}) - \Phi(-\frac{1}{\sigma_{\bar{X}}})=$
</br>$=\Phi(0.24)-\Phi(-0.24)$
</br>$=$<code> pnorm(0.24)-pnorm(-0.24)</code>$=0.189$



Tema 6: Problem 1
========================================================

b. 
- $Y=\sum X_i$ number of components on stock

therefore 

- $\sigma^2_Y=n \sigma^2_X$ 

Compute $n$ such that $P(Y \geq 2750)= 0.95$

$P(Y \geq 2750)= P(\frac{Y}{n}  \geq \frac{2750}{n})=P(\bar{X} \geq \frac{2750}{n})$

standardize 

$P(Y \geq 2750)=P(\frac{\bar{X} -100}{\sigma_X/\sqrt{n}}\geq \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})= 1-P(Z< \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})$

let's assume $n>30$ then  $Z \hookrightarrow N(\mu=0,\sigma^2=1)$



Tema 6: Problem 1
========================================================

$1-P(Z< \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})=$
$1-\Phi(\frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})=0.95$

applying $\Phi^{-1}$ 

$\Phi^{-1}(0.05)=$<code>qnorm(0.05)</code>$=\frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}}$

Replacing the values and solving for $n$ we have the equation

$100n-49.35\sqrt{n}-2750=0$ of for $t=\sqrt{n}$
</br>$100t^2-49.35t-2750=0$ with roots $t=5.49, -5.00$ 
</br>then $n=t^2=30.20 \sim 31$



Tema 6: Problem 2
========================================================

Consider:

- $X$ weight of one unit
- $E(X)=\mu_X=250gr$
- $\sigma_X=20gr$
- $n=50$
- $Y=\sum_{i=1}^{50} X_i$ the weight of 50 units

a. What is $f(Y)$?

since $Y$ is the sum of normal variable all $N(\mu_X, \sigma_X^2)$ and $n>30$ then $Y \hookrightarrow N(\mu_Y, \sigma_Y^2)$ where $\mu_Y=E(Y)=n\mu_X$ and $\sigma_Y=V(Y)=n \sigma_X^2$ 

$Y \hookrightarrow N(n\mu_X, n \sigma_X^2)=N(12.5kg, 0.02kg^2)$



Tema 6: Problem 2
========================================================


b. Compute $P(Y >12.75)$


$P(Y >12.75)= 1 - P(Y \leq 12.75)$

Let's standardize

$1-P(\frac{Y-\mu_Y}{\sigma_Y} \leq \frac{12.75-\mu_Y}{\sigma_Y} )$
</br>$=1-P(Z \leq \frac{12.75 - 12.5}{0.1414})$
</br>$=1-\Phi(1.768)=$<code>1-pnorm(1.768)</code>$= 0.0383$


Tema 6: Problem 2
========================================================


c. Find $\mu_Y$ such that $P(Y \leq 11.5)=0.95$

Standardize
</br>$P(\frac{Y-\mu_Y}{\sigma_Y} \leq \frac{11.5 - \mu_Y}{0.1414})=0.95$

apply $F^{-1}=\Phi^{-1}$
</br>$\frac{11.5 - \mu_Y}{0.1414}=\Phi^{-1}(0.95)=$<code>qnorm(0.95)</code>$=1.644854$

solve for $\mu_Y$
</br>$\mu=11.5- 1.644854*0.1414=225.35$



Tema 7: Problem 4
========================================================

Consider:

- $P(X=0)=1/2$
- $P(X=1)=a$
- $P(X=-1)=1/2-a$
- $\bar{X}=\frac{1}{n} \sum_{i=1}^n X_i$
for $a \in (0, 1/2)$

a. for $T=\frac{\bar{X}}{2}+\frac{1}{4}$ compute $E(T)$, $V(T)$

$E(T)=\frac{E(\bar{X})}{2}+\frac{1}{4}$


Tema 7: Problem 4
========================================================

and

$E(\bar{X})=E(X)=\sum_{x=-1,0,1} xP(X=x)$
$=-1*P(X=-1)+0*P(X=0)+1*P(X=1)=2a-1/2$

then 

$E(T)=a-1/4+1/4=a$ and thus $E(T)$ is an **unbiased** estimator of $a$


Tema 7: Problem 4
========================================================


$V(T)=V(\frac{\bar{X}}{2}+\frac{1}{4})=\frac{1}{4}V(\bar{X})=\frac{1}{4}\frac{V(X)}{n}$ 

so we need to find $V(X)$


Remember: $V(X)=E(X^2)-E(X)^2$ we miss $E(X^2)$

$E(X^2)=\sum_{x=-1,0,1} x^2P(X=x)=$
</br>$=(-1)^2*P(X=-1)+0^2*P(X=0)+1^2*P(X=1)=a+\frac{1}{2}-a=\frac{1}{2}$


Then 

$V(X)=E(X^2)-E(X)^2$
</br>$=\frac{1}{2}-(2a-\frac{1}{2})^2= \frac{1}{4} + 2a-4a^2$



Tema 7: Problem 4
========================================================

putting everything together

$V(T)=\frac{1}{4}\frac{V(X)}{n}=\frac{1/4 + 2a-4a^2}{4n}$

since $V(T)=\sigma_T \rightarrow 0$, when $n \rightarrow 0$ then $T$ is a **consistent** estimator



Tema 7: Problem 7
========================================================

Consider:

- $E(\bar{X})=E(X)=\mu$ then $\bar{X}$ is an **unbiased** estimator of $E(X)=\mu$

a. is $E(\bar{X})$ an **unbiased** estimator of $E(X)^2=\mu^2$

compute: $E(\bar{X}^2)$ (second moment about the origin)

Remember: $V(\bar{X}) = E(\bar{X}^2)-E(\bar{X})^2$

then 
$E(\bar{X}^2)=E(\bar{X})^2+V(\bar{X})=E(X)^2+\frac{V(X)}{n}=\mu^2+\frac{\sigma^2_X}{n}$

as $E(\bar{X}^2)\neq \mu^2$ then $E(\bar{X}^2)$ is a **biased** estimator of $\mu^2$ 



Tema 7: Summary (Method of moments)
========================================================



| Model |  f(x) | E(X) | Parameter estimates from $E(X)=1/n \sum_i x_i=\bar{x}$ $E(X^2)=1/n \sum_i x_i^2$, ...|
| -----------  | ----- | ---- | ----------- |
| Bernoulli             |  $p^x(1-p)^{1-x}$ | $p$ | $\hat{p}=\bar{x}$ |
| Binomial | $\binom n x p^x(1-p)^{n-x}$ | $np$ | $\hat{p}=\frac{\bar{x}}{n}$ |
| Shifted geometric | $p(1-p)^{x-1}$ | $\frac{1}{p}$ |$\hat{p}=\frac{1}{\bar{x}}$  |
| Negative Binomial |$\binom {x+r-1} x p^r(1-p)^x$ | $r\frac{1-p}{p}$ | $\hat{p}=\frac{r}{\bar{x}-r}$ | 
| Poisson | $\frac{e^{-\lambda}\lambda^x}{x!}$ | $\lambda$ | $\hat{\lambda}=\bar{x}$ |
| Exponential | $\lambda e^{-\lambda x}$ | $\frac{1}{\lambda}$ | $\hat{\lambda}=\frac{1}{\bar{x}}$ |
| Normal | $\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}$ | $\mu$ |$\hat{\mu}=\bar{x}$,$\hat{\sigma}^2=\frac{1}{n}\sum_ix_i^2-\bar{x}^2$ |



Tema 7: Summary (Maximum likelihood)
========================================================


- Imagine we make $n$ observations and obtain the values $(x_1, ....x_n)$ is 

The likelihood function, the probability of having observed $(x_1, ....x_n)$  is 
</br>$L(\theta)=\Pi_{i=1..n} f(x_i;\theta)$

We can take the log of $L$, 
</br>$\ln L(\theta)=\sum_i \ln(f(x_i;\theta))$

this is called the **log-likelihood** function

Computing the maximum of $\ln L(\theta)$ gives us an estimate for $\theta$ which we call $\hat{\theta}$ 



Tema 7: Problem 8
========================================================

Consider:
\[
f(x)=
\begin{cases}
    (1+\theta)x^\theta,& \text{if } x\in (0,1)\\
    0,& otherwise 
\end{cases}
\] 


a. compute $E(X)$

$E(X)=\int_0^1 x (1+\theta)x^\theta dx = \int_0^1 (1+\theta)x^{1+\theta} dx$

$=\frac{(1+\theta) x^{2+\theta}}{2+\theta}\Big|_0^1=\frac{1+\theta}{2+\theta}$


Tema 7: Problem 8
========================================================

b. compute $\hat{\theta}$ using the method of moments

$E(X)=\mu'_1=\frac{1}{n}\sum_i x_i=\bar{x}$

$\frac{1+\hat{\theta}}{2+\hat{\theta}}=\bar{x}$

solving for $\hat{\theta}$

$\hat{\theta}=\frac{1}{1-\bar{x}}-2$



Tema 7: Problem 8
========================================================

c. if the result of a random sample is $x_1 = 0.92$; $x_2 = 0.79$; $x_3 = 0.90$; $x_4 = 0.65$; $x_5 = 0.86$. Compute $\hat{\theta}$
 
$\bar{x} =\frac{0.92 + 0.79 + 0.90 + 0.65 + 0.86}{5}= 0.824$

then 

$\hat{\theta}=\frac{1}{1-\bar{x}}-2=\frac{1}{1-0.824}-2=3.6818$

