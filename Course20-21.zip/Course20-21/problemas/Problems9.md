Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 9 (Tema 8)</p>


Objectives
========================================================

- Problems on Hypothesis testing






Summary
========================================================



Hypothesis testing:

1.From the problem context, identify the parameter of interest: $\mu$, $\sigma$, $p$, $\lambda$, ....

2.State the null hypothesis, for intance for $\mu$

- two tailed: $H_0: \mu=\mu_0$
- or, upper tailed: $H_0: \mu \geq \mu_0$
- or, lower tailed: $H_0:\mu \leq \mu_0$

3.Specify an appropriate alternative hypothesis: 

$H_1 \neq \mu_0$, or $\mu < \mu_0$, or $\mu > \mu_0$.

Summary
========================================================

4.Choose a significance level: $\alpha$ ($\alpha=0.05$, $95\%$ confidence).

5.Define the statistic

when $X \hookrightarrow N(\mu_X, \sigma_X)= N(\mu, \sigma)$

Hypothesis for $\mu$

- if $\sigma$ is known then $Z=\frac{\bar{X}-\mu_0}{\sigma_X/\sqrt{n}}$ is standard (<code>pnorm(z)</code>)

- if $\sigma$ is not known then $T=\frac{\bar{X}-\mu_0}{s/\sqrt{n}}$ is t-distributed with $n-1$ degrees of freedom (<code>pt(t,n-1)</code>)


Summary
========================================================

or, Hypothesis for $\sigma_0$

- $Y=\frac{(n-1)S^2}{\sigma_0^2}$ is $\chi^2$-distributed with $n-1$ degrees of freedom (<code>pchisq(y,n-1)</code>).

Summary
========================================================


6.Test the hypothesis

- define critical **the region** for the statistic under $H_0$ with probability of $\alpha$ at the edges

- or, compute confidence intervals at $\alpha$ confidence limit

- or, compute $P$-value: 
</br>-- two tail: $P$-value$=2(1-F(|z|))$, 
</br>-- upper tail: $P$-value$=(1-F(z))$, 
</br>-- lower tail: $P$-value$=F(z)$


Summary
========================================================

7.Decide

Reject the null hypothesis if:

- the observed statistic falls in the critical region

- or, the $(1-\alpha)100\%$ confidence interval does not contain $\mu_0$ ($\sigma_0$, $p_0$, etc...)

- or, if $P<\alpha$

Otherwise **do not** reject null hypothesis

Problem 1
========================================================

- consider the measurements:

204.999, 206.149, 202.150, 207.048, 203.496, 206.343, 203.496, 206.676, 205.831

- $\mu_0= 206.5$

a. test the hypothesis $\mu < \mu_0$ at $90\%$ confidence ($\alpha=0.1$). Compute the $P$-value

- Test for the mean where we do not know $\sigma$

Lower tail: $H_0: \mu \geq 206.5$, $H_1: \mu <  206.5$


Problem 1
========================================================


- Statistic: $T=\frac{\bar{X}-\mu_0}{S/\sqrt{9}}$, t-distribution with $n-1$ degrees of freedom

- Observed value: $t=\frac{205.132-206.5}{1.707/\sqrt{9}}=-2.404$

Problem 1
========================================================


$P$-value for lower tail: 

$P$-value$=F(T)=P(T<-2.404)=$<code>pt(-2.404, 8)</code>

$=0.021 < \alpha=0.10$

Since: $P<\alpha$ we reject the null hypothesis

Problem 1
========================================================

b. if $\sigma^2_X=4$. Test the hypothesis $\mu_0=206.5$ at $95\%$ confidencefidence


- Test for the mean where know $\sigma_X$

Two tail: $H_0: \mu = 206.5$, $H_1: \mu \neq 206.5$

- Statistic: $Z=\frac{\bar{X}-\mu_0}{\sigma_X/\sqrt{9}}$, standard distribution

- Observed value: $z=\frac{205.132-206.5}{2/\sqrt{9}}=-2.05$




Problem 1
========================================================


$P$-value for two tail:

$P$-value$=2(1-F(|-2.05|))=$<code>2*(1-pnorm(2.05))</code>$=0.0403 < \alpha=0.05$

Since: $P<\alpha$ we reject the null hypothesis




Problem 2
========================================================

- consider the measurements:

53700, 55500, 53000, 52400, 51000, 62000, 75000, 53800, 56600

- $\mu_0= 62000$

a. test the hypothesis $\mu \geq 62000$ at $95\%$ confidence ($\alpha=0.05$). Compute the $P$-value

- Test for the mean where we do not know $\sigma$

Lower tail: $H_0: \mu \geq 62000$, $H_1: \mu <  62000$


Problem 2
========================================================

- Statistic: $T=\frac{\bar{X}-\mu_0}{s/\sqrt{9}}$, t-distribution with $n-1=8$ degrees of freedom

- Observed value: $t=\frac{57000-62000}{7464.08/\sqrt{9}}=-2.01$



Problem 2
========================================================

a. critical region 

$P(T\lt t_{0.95})=0.05$
</br>$P(T \lt t_{0.95,8})=F_{t,8}(t_{0.95,8})=0.05$
</br>$t_{0.95,8}=F_{t,8}^{-1}(0.05)$
</br>$t_{0.95,8}=$<code>qt(0.05,8)</code>$=-1.8595$

The critical region is $T < -1.8595$

since $t=-2.01 < -1.8595$ we then reject the null hypothesis


Problem 2
========================================================

b. 
$P$-value for lower tail: 

$P$-value$=F(T)=P(T<-2.01)=$

<code>pt(-2.01, 8)</code>$=0.021 < \alpha=0.05$

Since: $P<\alpha$ we reject the null hypothesis


Problem 2
========================================================

c. compute the $99\%$ CI for the if $\sigma_X^2=54760000$

When we know the variance then the CI for an $n$ sample of nromal variables is:

$(l,u) = (\bar{x} - z_{\alpha/2}\sigma_{X}/\sqrt{n},\bar{x} + z_{\alpha/2}\sigma_{X}/\sqrt{n})$

$\bar{x}= 57000$, $\sigma_X=7400$, $n=9$ and 

$z_{\alpha/2}=z_{0.005}=$<code>qnorm(0.995)</code>$=2.5758$

Putting everything together

$(l,u)=(50648.33,63351.67)$ (since it contains $62000$, we do not reject $H_0$ with $99\%$ confidence)




Problem 3
========================================================


consider:

- $\bar{x}= 7750$
- $s= 145$
- $n=6$
- $\mu_0= 8000$
- We don't make a claim if $\mu \geq \mu_0$
- We  make a claim if $\mu > \mu_0$

a. if $\alpha=0.1$ should we make a claim?


- Test for the mean where we do not know $\sigma$

Lower tail: $H_0: \mu \geq 8000$, $H_1: \mu <  8000$




Problem 3
========================================================


- Statistic: $T=\frac{\bar{X}-\mu_0}{s/\sqrt{n}}$, t-distribution with $n-1$ degrees of freedom

- Observed value: $t=\frac{7750-8000}{145/\sqrt{6}}=-4.22$

Problem 3
========================================================


$P$-value for lower tail: 

$P$-value$=F(T)=P(T<-4.22)=$<code>pt(-4.22, 5)</code>

$=0.004 < \alpha=0.01$

Since: $P<\alpha$ we reject the null hypothesis, we make a claim.


Problem 3
========================================================

b. consider:

- $\sigma^2_X=136161$
- $\alpha=0.05$

Test the same hypothesis.


- Test for the mean where we do not know $\sigma$

Lower tail: $H_0: \mu \geq 8000$, $H_1: \mu <  8000$

- Statistic: $Z=\frac{\bar{X}-\mu_0}{\sigma_X/\sqrt{n}}$, is a standard variable

- Observed value: $z=\frac{7750-8000}{369/\sqrt{6}}=-1.659$

Problem 3
========================================================


$P$-value for lower tail: 

$P$-value$=F(Z)=P(Z<-1.659)=$<code>pnorm(-1.659)</code>

$=0.004 < \alpha=0.05$

Since: $P<\alpha$ we reject the null hypothesis

Problem 3
========================================================

c. 

- if $\mu=7700$ what is type II error or false negative probability?

$P(accept|H_0:false)$ 

We accept $H_0$ when the observed value $z$ falls in the acceptance region, at $\alpha=0.05$ that is

$z>-z_{0.05}=$<code>-qnorm(1-0.05)</code>$=-1.644$

let's assume it fell exactly at $-1.644$, what was the observed $\bar{x}$

$z=\frac{\bar{x}-8000}{369/\sqrt{6}}=-1.644$ then $\bar{x}= 7752.19$


Problem 3
========================================================

For accepting the null hypothesis then we need to observe an average that is greater than $\bar{x}= 7752.19$

What is the probability that if $\mu=7700$, we accept $H_0$, that is: 

$P(accept|H_0:false)=P(\bar{X}>7752.19|\mu=7700)$

$P(\bar{X}>7752.19|\mu=7700)=P(Z>\frac{7752.19-7700}{369/\sqrt{6}})$

$=1-\phi(0.35)=$<code>1-pnorm(0.35)</code>$=0.36316$




Problem 4
========================================================


- $\bar{x}= 12.5$
- $s= 2.7$
- $n=26$
- $\mu_0= 14$

- Test for the mean where we do not know $\sigma$

a. 

Lower tail: $H_0: \mu \geq 14$, $H_1: \mu <  14$

reject $H_0$ when $H_0$ is true is a **false positive** or type I error.


Problem 4
========================================================

**false positive** probability:

$P(reject|H_0:true)=\alpha$

The probability is what we leave out from the rejection zone when $H_0$ is true.


hat is $P(reject|H_0:true)=\alpha$.


Problem 4
========================================================

consider:

- $\alpha=0.01$ test the hypothesis


- Test for the mean where we do not know $\sigma$

- Statistic: $T=\frac{\bar{X}-\mu_0}{s/\sqrt{n}}$, t-distribution with $n-1$ degrees of freedom

- Observed value: $t=\frac{12.5-14}{2.7/\sqrt{26}}=-2.832$

Problem 4
========================================================


$P$-value for lower tail:

$P$-value$=F(T)=P(T<-2.832)=$<code>pt(-2.832, 25)</code>

$= 0.0045 < \alpha=0.001$

Since: $P<\alpha$ we reject the null hypothesis





Problem 4
========================================================

c. consider:

- $\sigma_X=4.8$
- $\alpha=0.05$

Test the same hypothesis.


- Test for the mean where we do not know $\sigma$

Lower tail: $H_0: \mu \geq 14$, $H_1: \mu <  14$

- Statistic: $Z=\frac{\bar{X}-\mu_0}{\sigma_X/\sqrt{n}}$, is a standard variable

- Observed value: $z=\frac{12.5-14}{4.8/\sqrt{26}}=-1.593$

Problem 4
========================================================


$P$-value for lower tail:

$P$-value$=F(Z)=P(Z<-1.593)=$<code>pnorm(-1.593)</code>

$=0.0555 > \alpha=0.05$

Since: $P>\alpha$ we **do not** reject the null hypothesis


Problem 5
========================================================


consider:

- $\bar{x}= 10$
- $s= 1.5$
- $n=41$

a. What is the CI at $87.886\%$ confidence 
$\alpha=1-0.87886=0.12114$

while we do not **know** $\sigma_X^2$ $n$ is big and then we can use the standard distribution: 

$(l,u) = (\bar{x} - z_{\alpha/2}\sigma_{X}/\sqrt{n},\bar{x} + z_{\alpha/2}\sigma_{X}/\sqrt{n})$

Problem 5
========================================================

$(l,u) = (\bar{x} - z_{\alpha/2}\sigma_{X}/\sqrt{n},\bar{x} + z_{\alpha/2}\sigma_{X}/\sqrt{n})$

where $z_{\alpha/2}=$<code>qnorm(1-0.12114/2)</code>$=1.55$


then 

$(l,u) = (10 - 1.55*1.5/\sqrt{41},10 +1.55*1.5/\sqrt{41})=(9.63, 10.36)$



Problem 5
========================================================

c. consider:

- $\mu_0=10.5$
- $\alpha=0.05$

Test the hypothesis.

Lower tail: $H_0: \mu \geq 10.5$, $H_1: \mu <  10.5$

- Statistic: $Z=\frac{\bar{X}-\mu_0}{\sigma_X/\sqrt{n}}$, is a standard variable

- Observed value: $z=\frac{10-10.5}{1.5/\sqrt{41}}=-2.134$

Problem 5
========================================================


$P$-value for lower tail:

$P$-value$=F(Z)=P(Z<-1.593)=$<code>pnorm(-2.134)</code>

$=0.016 < \alpha=0.05$

Since: $P<\alpha$ we  reject the null hypothesis



Problem 6
========================================================

consider:

- measurements: 515, 464, 558, 491
- $\sigma^2=10000$
- $\alpha=0.1$


Lower tail: $H_0: \sigma \geq 10000$, $H_1: \sigma^2 <  10000$

- the sample variance is 

$s^2=$<code>sd(c(515, 464, 558, 491))^2</code>$=1590$


Problem 5
========================================================


- Statistic: $Y=\frac{(n-1)S^2}{\sigma_0^2}$, is a random variable that follows a $\chi^2$ with $n-1$ degrees of freedom.

- Observed value: $y= \frac{(4-1)1590^2}{10000}= 0.477$


Problem 6
========================================================


$P$-value for lower tail:

$P$-value$=F(Y)=P(Y<0.477)$

$=$<code>pchisq(0.477, 3)</code>$=0.076 > \alpha=0.05$

Since: $P>\alpha$ we **do not**  reject the null hypothesis



Problem 6
========================================================

consider

- $X \hookrightarrow N(\mu, \sigma^2)$
- $\mu=500$
- $\sigma=50$


b. what is $n$ such that $P(|\bar{X}-\mu|<10)=0.95$?

$P(-10<\bar{X}-\mu<10)=0.95$


$P(\frac{-10}{\sigma/\sqrt{n}}<\frac{\bar{X}-\mu}{\sigma/\sqrt{n}}<\frac{10}{\sigma/\sqrt{n}})=0.95$



Problem 6
========================================================

$\Phi(\frac{10}{\sigma/\sqrt{n}})-\Phi(\frac{-10}{\sigma/\sqrt{n}})=0.95$

$\Phi(\frac{10}{\sigma/\sqrt{n}})-(1-\Phi(\frac{10}{\sigma/\sqrt{n}}))=0.95$


$\Phi(\frac{10}{\sigma/\sqrt{n}})=(1+0.95)/2=0.975$

$\frac{10}{\sigma/\sqrt{n}}=$<code>qnorm(0.975)</code>$=1.959$

$\frac{10}{\sigma/\sqrt{n}}=1.959$

solving for $n$ then $n_{min}=96.4$, $n>97$ 



Problem 7
========================================================


consider

- $X \hookrightarrow N(\mu, \sigma^2)$
- $\sigma=5$
- Upper tail: $H_0: \mu \leq 80$, $H_1: \mu > 80$
- $n=100$
- $\alpha=0.0505$

compute type II error, false negative:

$P(accept|H_0:false)$ 

We accept $H_0$ when the observed value $z$ falls in the acceptance region, at $\alpha=0.0505$


Problem 7
========================================================

Acceptance region:

$z \lt z_{0.05}=$<code>qnorm(1-0.0505)</code>$=1.640$

let's assume it fell exactly at $1.640$ what was the observed $\bar{x}$

$z=\frac{\bar{x}-80}{5/\sqrt{100}}=1.640$ then $\bar{x}=(5/10)*1.64+80=80.82$


Problem 7
========================================================

For accepting the null hypothesis then we need to observe an average that is lower than $\bar{x}= 80.82$

What is the probability that if $\mu=81$, we accept $H_0$?

that is: $P(accept|H_0:false)=P(\bar{X}<80.82|\mu=81)$

$P(\bar{X}<80.82|\mu=81)=P(Z<\frac{80.82-80}{5/\sqrt{100}})$

$=\phi(-0.36)=$<code>pnorm(-0.36)</code>$=0.3594236$


Problem 8
========================================================

Consider: 

- $K$ is a Bernoulli variable, $\mu_K=p$, $\sigma_K=p(1-p)$
- $\bar{K} \hookrightarrow N(\mu_{\bar{K}}, \sigma_{\bar{K}})$ by CLT because $n$ is large.
- $E(\bar{K})=\mu_{\bar{K}}= E(K)=p$, then $\bar{K}$ is an estimator of $p$: $\hat{p}=\bar{k}$
- $\sigma_{\bar{K}}= \frac{\sigma_K}{\sqrt{n}}=\sqrt{\frac{p(1-p)}{n}}$

The measurements give

- $\bar{k}=\hat{p}= 926/1225=0.7559$
- $s=\sqrt{\hat{p}(1-\hat{p})}=0.4295$

Problem 8
========================================================

a. 

upper tail: $H_0: p \leq 0.75$, $H_1: p >  0.75$

- Statistic: $Z=\frac{\bar{K}-p}{S/\sqrt{n}}$, is a standard variable because n is large by the CLT

- Observed value: $z=\frac{0.7559-0.75}{0.4295/\sqrt{1225}}=0.480$

Problem 8
========================================================


$P$-value for upper tail:

$P$-value$=1-F(Z)=1-P(Z<0.480)=1-\Phi(0.480)$

$=$<code>1-pnorm(0.480)</code>$=0.31$

Since: only with a level of significance of $0.31$ we can reject the null hypothesis, and conclude that the method produces the results within the tolerance limits. 


