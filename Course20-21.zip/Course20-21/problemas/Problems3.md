Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 3 (Tema 5 part 1)</p>



Formula
========================================================


| Model | outcome    | x  |  f(x) | E(X) | V(X) |
| ----------- | ------------- | ------ | ----- | ---- | ---- |
| Uniform | $n$ discrete values | a,... b| $\frac{1}{n}$ |$\frac{b+a}{2}$ |  $\frac{(b-a+1)^2-1}{12}$ | 
| Bernoulli             | A event | 0,1 | $p^x(1-p)^{1-x}$ | $p$ | $p(1-p)$ |
| Binomial | \# of A events | 0,1,...| $\binom n x p^x(1-p)^{n-x}$ | $np$ | $np(1-p)$ |
| Geometric | \# of B events until event A | 0,1,...|$p(1-p)^{x}$| $\frac{1-p}{p}$ |$\frac{1-p}{p^2}$ |
| Shifted geometric | \# of **trials** until event A | 1,2,...| $p(1-p)^{x-1}$ | $\frac{1}{p}$ | $\frac{1-p}{p^2}$ |
| Negative Binomial | \# of B events until r A events | 0,1,.. |$\binom {x+r-1} x p^r(1-p)^x$ | $r\frac{1-p}{p}$ | $r\frac{1-p}{p^2}$ |
| Hypergeometric | \# of A events in a sample $n$ |$\max(0, n+K-N)$, ... $\min(K, n)$ | $\frac{1}{\binom N n}\binom K x \binom {N-K} {n-x}$ | $np$ | $np(1-p)\frac{N-n}{N-1}$ |
| Poisson | \# of A events in an interval | 0,1, ..| $\frac{e^{-\lambda}\lambda^x}{x!}$ | $\lambda$ | $\lambda$ |
| Exponential | Interval between two events A | $[0,\infty)$ | $\lambda e^{-\lambda x}$ | $\frac{1}{\lambda}$ | $\frac{1}{\lambda^2}$ |
| Normal | measurement with symmetric errors whose most likely value is the average  | $(-\infty, \infty)$|$\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}$ | $\mu$ |$\sigma^2$ |



Problem 2
========================================================

Consider:

- $X$ number of no defective books

- $p=0.98$ no defective, $q=1-p=0.02$ defective books

- $n=50$ books are selected

a) Compute $P(X \geq 3)$
</br>$P(X \geq 3)=1-P(X < 3)$


Problem 2
========================================================

Binomial distribution:

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$ or $X \hookrightarrow Bin(n,p)$

$P(X \geq 3)=1-P(X < 3)=1-F_{bin}(2;n,p)$
</br>$=1-f(0;n,p)-f(1;n,p)-f(2;n,p)$
</br>$=1 - \binom {50} {0} (1-p)^{50}-\binom {50} 1 p(1-p)^{49}-\binom {50} 2 p^2(1-p)^{48} \sim 1$

b) $Y$ number of defective books
</br>$P(Y=3)=f(k;n,q)= \binom {50} 3 q^3(1-q)^{47}$
</br>$=0.0606$



Problem 4
========================================================

consider:

- probability $p=0.51$ of having a boy, probability $q=0.49$ of having a girl
- $n=4$ a family
- $X$ number of boys in a family, $Y$ number of girls in a family

a) compute $P(X=1)+P(Y=1)$

- Binomial distribution for boys $X \hookrightarrow Bin(n,p)$
- Binomial distribution for girls $Y \hookrightarrow Bin(n,q)$

Problem 4
========================================================


- $P(X=1)=f(k;4,0.51)=\binom 4 1 0.51^1(1-0.51)^3=0.24$
- and $P(Y=1)=f(k;4,0.49)=\binom 4 1 0.49^1(1-0.49)^3=0.26$
- then $P(X=1)+P(Y=1)=0.5$

Problem 4
========================================================

b) Compute: $P(X\geq 2)$

$P(X\geq 2)=1-P(X < 2)=1-P(X \leq 1)$ 

$=1-F_{binom}(1;n,p)$

$=1-f(0;n=4,p=0.51)-f(1;n=4,p=0.51)$

$=1- \binom 4 0 (1-0.51)^4-\binom 4 1 0.51^1(1-0.51)^3=0.07023$

Problem 4
========================================================

c) compute $n$ such that $P(Y \geq 1)=0.75$

$P(Y \geq 1)= 1 - P(Y<1)= 1 - P(Y=0)$
</br>$=1-f(0;n,q)=0.75$

Therefore we have to solve 

$1-f(0;n,q)=0.75$ 

where $f$ is the binomial function $f(k;n,q)=\binom n k q^k(1-q)^{n-k}$

$1-\binom n 0 0.49^0*(1-0.49)^n=0.75$

$0.51^n=0.25$

Problem 4
========================================================


- $n=\frac{\log(0.25)}{\log(0.51)}=2.05$ 
- or if $P(Y \geq 1)>0.75$ then $n > 2.05$
- The minimum integer that satisfies the condition is $n = 3$.

Problem 7
========================================================


Consider:

- $P(C|A)=0.8$, 80% of treated patients with $A$ recover 
- $P(C|B)=0.7$, 70% of treated patients with $B$ recover
- $P(A)=0.4$, 40% are treated with $A$
- $P(B)=0.6$, 60% are treated with $B$

a) what is $P(A|C)$?
</br>$P(A|C)=\frac{P(C|A)P(A)}{P(C|A)P(A)+P(C|B)P(B)}=0.43$


Problem 7
========================================================
b) now consider:

- $n=5$
- $p=P(C)$ probability that a patients recovers

$P(C)=P(C|A)P(A)+P(C|B)P(B)=0.74$

Compute: $P(X\geq 3)$

$X \hookrightarrow Bin(n,p)$


Problem 7
========================================================
$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$

</br>$P(X\geq 3)=1-P(X<3)=1-P(X\leq 2)$
</br>$= 1-F_{binom}(2;n,p)$
</br>$=1 - \binom 5 0 p^0(1-p)^5 - \binom 5 1 p(1-p)^4 - \binom 5 2 p^2(1-p)^3=0.885$

for $p=0.74$


Problem 8
========================================================

consider:

- $p=0.1$ probability of error

a) Compute $P(X=15)$ where $X$ is the number of bits received with no error before the first error.

Geometric distribution:

$f(X=k)=(1-p)^{k}p$, that is $X \hookrightarrow Geom(p)$
</br> $P(X=15)=(1-p)^{15}p=0.02$


Problem 8
========================================================

b) now consider
- $n=50$
- $X$ number of errors in transmitting of 50 bits

compute: $P(X \leq 3)$

now, $X \hookrightarrow Bin(n,p)$

Then 

$P(X \leq 3)=F_{binom}(3;n,p)$
</br>$=\binom {50} 0 (1-p)^{50}+\binom {50} 1 p(1-p)^{49}+\binom {50} 2  p^2(1-p)^{48}$
</br>$+\binom {50} 3  p^3(1-p)^{47}$
</br>$=0.25$



Problem 10
========================================================


Consider:

- $p=0.6$ for the probability of a component to function.
- $n=4$
- when $X\geq 2$ the satelite functions.


the number of components that function

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$ or $X \hookrightarrow Bin(n,p)$


Problem 10
========================================================

a) compute $P(X\geq 2)$
</br>$P(X\geq 2) = 1 - P(X < 2)= 1-P(X \leq 1)$
</br>$= 1 - F_{binom}(1; n,p)= 1 - f(0;n,p)-f(1;n,p)$
</br>$=1- \binom 4 0 (1-0.6)^4 -\binom 4 1 0.6(1-0.6)^3=0.82$

Note: in R you can confirm the answer with

<code>1-pbinom(1,size=4,prob=0.6)</code>

or

<code>1-dbinom(0,size=4,prob=0.6)-dbinom(1,size=4,prob=0.6)</code>


Problem 10
========================================================


b) compute $\frac{P(X=k+1)}{P(X=k)}$

</br> remember $\binom n k = \frac{n!}{k!(n-k)!}$
</br> then $\frac{f(k+1;n,p)}{f(k;n,p)}= \frac{\binom n {k+1} }{\binom n k}\frac{p}{1-p}$
</br>$=\frac{\frac{4!}{(k+1)!(4-k-1)!}}{\frac{4!}{k!(4-k)!}}*3/2=\frac{k!(4-k)!}{(k+1)!(4-k-1)!}*3/2=\frac{k!(4-k-1)!(4-k)}{k!(k+1)(4-k-1)!}*3/2$
</br>$=\frac{4-k}{k+1}*3/2$



Problem 12
========================================================

consider:

- $q=0.4$ probability of a call being answered, $p=1-q=0.6$ probability of a call **not** being answered
- $n=10$ calls.

number unanswered calls $X \hookrightarrow Bin(n,p)$, then 

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$

Problem 12
========================================================

a) compute $P(X \geq 2)$

$P(X \geq 2)= 1-P(X <2)= 1-P(X \leq 1)= 1- F_{binom}(1,n,p)$

$=1-f(0;n,p)-f(1;n,p)$

$=1- \binom {10} 0 (1-p)^{10} - \binom {10} 1 p(1-p)^9=0.998$

in R: 

<code>1-pbinom(1,size=10,prob=0.6)</code>


Problem 13
========================================================

Consider

- $n=5$
- Number of components $X\geq 4$ needed for the system to run
- $p=0.95$

number components that work $X \hookrightarrow Bin(n,p)$, then

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$



Problem 13
========================================================

a) what is the probability for the system to run $P(X \geq 4)$

$P(X \geq 4)=1-P(X < 4)=1-P(X \leq 3)=1-F_{binom}(3; n,p)$

$=1-f(0;n,p)-f(1;n,p)-f(2;n,p)$

$=1- \binom 5 0 (1-p)^5 - \binom 5 1 p(1-p)^4- \binom 5 2 p^2(1-p)^3$
</br>$- \binom 5 3 p^3(1-p)^2=0.9774075$

in R: <code>1-pbinom(3,size=5,prob=0.95)</code>


Problem 13
========================================================

b) consider now:

- $q=P(X \geq 4)=0.9774075$ the probability that a system works.
- $p=1-q=0.0225925$ the probability that a system does not work.
- $Y$ is the number of systems tested before finding 2 out of order. 

Define $Z$ as the number of systems **that worked** (event B) before two systems that did not work (event A). Then $Z=Y-2$
and 

$Z \hookrightarrow NB(r=2, p=0.022)$


Problem 13
========================================================

$P(Z=k)=f(k;r,p)=\binom {k+r-1} k (1-p)^kp^r=\binom {k+1} k (1-p)^kp^2$ 

a) compute $P(Y\geq 4)$

$P(Y\geq 4)=P(Z\geq 2)= 1-P(Z < 2)=1-P(Z \leq 1)$

$= 1-F_{NB}(1;r,p)=1-f(0;r,p)-f(1;r,p)$

$=1- \binom {1} 0 p^2 - \binom {2} 1 (1-p)p^2$

$=0.9984$


Problem 13
========================================================

c) compute the expected value of a and b

- $E(X)=np=4.75$ about 5 components will typically run in a system
- $E(Y)=E(Z+2)= r\frac{1-p}{p} + 2 = \frac{2}{p} = 88.52$ about 88 systems need to be tested before finding 2 which do not work.


Problem 15
========================================================

Consider

- $p=0.3$ probability of a patient having allergy
- $n=20$ are observed

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$ or $X \hookrightarrow Bin(n,p)$

a) compute $P(X\geq 3)$

$P(X\geq 3)= 1 - P(X<3)=1-P(X\leq 2)= 1 - F_{binom}(2; n,p)$
</br>$= 1 - f(0; n,p)-f(1;n,p)-f(2;n,p)$
</br>$=1 -\binom {20} 0 (1-p)^{20} - \binom {20} 1 p(1-p)^{19}- \binom {20} 2 p^2(1-p)^{18}=0.964$

in R: <code>1-pbinom(2,size=20,p=0.3)</code>

Problem 15
========================================================

b) now consider
- $K=5= 20*0.25$ have allergy
- $N=20$ total number of patients
- $n=7$ are selected from the 20
- number of patients with allergy $X \hookrightarrow Hyper(N,n,K)$




Problem 15
========================================================

$f(X; N, n, K)=\frac{\binom K k}{\binom N n} \binom {N-K} {n-k}$


Compute $P(x \geq 4)$

$P(x \geq 4)=1 - P(x < 4)=1 - P(x \leq 3)$

$= 1 -F_{hyper}(3; N, n, k)$

$= 1 - f(0; N, n, K)-f(1; N, n, K)-f(2; N, n, K)- f(3; N, n, K)$

$= 1- \frac{\binom 5 0}{\binom {20} 7} \binom {20-5}{7-0}-\frac{\binom 5 1}{\binom {20} 7} \binom {20-5}{7-1}
-\frac{\binom 5 2}{\binom {20} 7} \binom {20-5}{7-2}-\frac{\binom 5 3}{\binom {20} 7} \binom {20-5}{7-3}$

$=0.03069$

<code>1-phyper(3,5,15,7)</code>

Problem 1
========================================================

Consider: 

- random variables: $X$ particles/minute, $Y$ particles/0.5minutes

- $P(X>0)$=0.996


a) What is $P(Y<2)$?

Poisson distribution:
$P(X=k)=f(k;\lambda)=\frac{e^{-\lambda}\lambda^k}{k!}$

Problem 1
========================================================
- We find $\lambda$ for one minute
</br>$f(0,\lambda)=e^{-\lambda}=1-P(X>0)=1-0.996$
</br>$\lambda=\log(0.004)=5.52$

- We find $\lambda$ for half minute
</br>$\lambda_{0.5}=0.5\lambda=2.76$

- We compute
</br>$P(Y<2)=F_{pois}(1;\lambda_{0.5})= f(0;\lambda_{0.5})+f(1;\lambda_{0.5})$
</br>$=e^{-\lambda_{0.5}} +e^{-\lambda_{0.5}}\lambda_{0.5}=0.23$


Problem 1
========================================================

b) find $y=q_{0.25}$
</br>$P(Y \leq q_{0.25})=F_{pois}(q_{0.25})=0.25$

- From the previous result we know $F_{pois}(1;\lambda_{0.5})=0.23$. We are almost there.

- We compute 
</br>$F_{pois}(2;\lambda_{0.5})=\sum_{i=0,1,2}f(i;\lambda_{0.5})=F_{pois}(1;\lambda_{0.5})+f(2;\lambda_{0.5})$
</br>$=0.23+\frac{e^{-\lambda_{0.5}}\lambda_{0.5}^2}{2}=0.47$
</br>then $q_{0.25} \in (1,2)$



What is the Poisson probability distribution in R? 

Problem 1
========================================================

c) consider:

- $p=0.2$ probability of being radioactive particles
- $n=5$ number of particles detected
- $X$ number of radiactive particles detected

compute $P(X \leq 2)$: the minority of particles are radioactive (or the majority of particles are not radioactive)


Problem 1
========================================================

Binomial distribution:

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$ or $X \hookrightarrow Bin(n,p)$

$P(X \leq 2)=F_{bin}(2)=f(0;n,p)+f(1;n,p)+f(2;n,p)$
</br>$= \binom 5 0 (1-p)^5 + \binom 5 1 p(1-p)^4+ \binom 5 2 p^2(1-p)^3=0.94$


d) The expected value of radioactive particles is the mean $E(X)=n*0.2=1$. That is, we expect to find 1 radioactive particle when we select 5 particles. 


