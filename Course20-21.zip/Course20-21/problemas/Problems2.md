Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 2 (Tema 4)</p>


Objective
========================================================

Problems on:

- Random variables
- Mass and density probability functions
- Probability distributions


Problem 1
========================================================


- \[
    f(x)= 
\begin{cases}
k(a + bx),& \text{if } x \in (0,1)\\
    0,& x \notin (0,1)\\
\end{cases}
\]

- $E[X]=4/7$

a) Find a, b, k and $V(X)$.

Problem 1
========================================================

We solve for a and b using two equations:
</br>i) $E(X)=\int_0^1 k(a + bx)xdx= \frac{1}{2}kax^2+\frac{1}{3}kbx^3\big|_0^1$
</br>$\frac{1}{2}ka+\frac{1}{3}kb=\frac{4}{7}$
</br>ii) $\int_0^1 k(a + bx)dx = kax + \frac{1}{2}kbx^2\big|_0^1$
</br>$ka+\frac{1}{2}kb=1$


Whose solution of b and k as a function of a is
1) $b=\frac{3}{2}a$
2) $k=\frac{4}{7a}$


Problem 1
========================================================

The variance can be computed from the relation

$V(X)=E(X^2)-E(X)^2=\int_0^1 k(a + bx)x^2dx-(\frac{4}{7})^2$
</br>$=\int_0^1 (\frac{4}{7} + \frac{12}{14}x)x^2dx-(\frac{4}{7})^2$
</br>$=\frac{1}{3}x^3\frac{4}{7}+\frac{1}{4}x^4\frac{12}{14}\big|_0^1-\frac{16}{49}$
</br>$=\frac{25}{294}$



Problem 1
========================================================

b) Find F(X)
</br>$F(x)=\int_0^x k(a+bt)dt$
\[
    F(x)= 
\begin{cases}
0, & x \leq 0 \\
\int_0^x(\frac{4}{7} + \frac{12}{14}t)dt=\frac{4}{7}t+\frac{1}{2}\frac{12}{14}t^2\big|_0^x=\frac{4}{7}x+\frac{3}{7}x^2,& x \in (0,1)\\
    0,& x \geq 1\\
\end{cases}
\]

</br>\[
    F(x)= 
\begin{cases}
0, & x \leq 0 \\
\frac{4}{7}x+\frac{3}{7}x^2,& x \in (0,1)\\
    0,& x \geq 1\\
\end{cases}
\]
</br>c) median of X
</br>$F(q_{0.5})=\frac{1}{2}=\frac{4}{7}q_{0.5}+\frac{3}{7}q_{0.5}^2$, solving the quadratic $-7+8q_{0.5}+6q_{0.5}^2=0$ gives solutions $q_{0.5}={-1.9,0.6}$, $0.6$ is in the correct range.


Problem 2
========================================================

- $x\in \{0,1,2,3\}$
- $P(X=0)=2P(X=1)$
- $E(X)=2$
- $E(X^2)=5$

a) what is $f(x)=P(X=x)$?

Problem 2
========================================================

We solve a system of 4 equations
</br>i) nromalization: $P(X=0)+P(X=1)+P(X=2)+P(X=3)=1$
</br>ii) expectation: $P(X=0)*0+P(X=1)*1+P(X=2)*2+P(X=3)*3=2$
</br>iii) variance: $P(X=0)*0^2+P(X=1)*1^2+P(X=2)*2^2+P(X=3)3^2=5$
</br>iv) $P(X=0)-2P(X=1)=0$
</br>whose solution is
</br>$f(0)=P(X=0)=\frac{1}{7}$
</br>$f(1)=P(X=1)=\frac{1}{14}$
</br>$f(2)=P(X=2)=\frac{3}{7}$
</br>$f(3)=P(X=3)=\frac{5}{14}$


Problem 2
========================================================
b) The variance can ebe obtained from 
$V(X)=E(X^2)-E(X)^2=5-2^2=1$

c)
- What is the range of the variable $Y=2X-1$?
</br>$Y \in {-1,1,3,5}$
- $P(3 < Y \leq  5) = P(2 < X \leq  3) = P(X=3) = \frac{5}{14}$
- $E(Y)=2E(X)-1=3$
- $V(Y)=2^2V(X)=4$

Problem 3
========================================================

Given
\[
    F(x)= 
\begin{cases}
0, & x \leq 2 \\
\frac{x^2-a}{b},& x \in (2,4)\\
    0,& x > 4\\
\end{cases}
\]

a) find $a$ and $b$

1) from normalization, that is, the sum of probabilities across the range of x add to 1
</br>$F(4)-F(2)=1$
</br>$\frac{4^2-a}{b}-\frac{2^2-a}{b}=1$ solving for b
</br>$b=12$


Problem 3
========================================================

2) from continuity at x=2

$F(2)=0$  then $\frac{2^2-a}{b}=0$ and $a=4$.


b) what is $\sigma=\sqrt{V(X)}$?

We first find the density function by differentiation.

$f(x)=\frac{dF(x)}{dx}=\frac{d}{dx}\frac{x^2-4}{12}=\frac{x}{6}$


Problem 3
========================================================

then we compute the variance
</br>$V(X)=E(X^2)-E(X)^2=\int_2^4 x^2\frac{x}{6}dx-[\int_2^4 x\frac{x}{6}dx]^2$
</br>$= \frac{1}{4}\frac{x^4}{6}\big|_2^4 - [\frac{1}{3}\frac{x^3}{6}]^2$
</br>$= 0.32$

then $\sigma=\sqrt{0.32}=0.56$

c) $P(X<3.5|X>3)=\frac{P(X<3.5\cap X>3)}{P(X>3)}=\frac{F(3.5)-F(3)}{1-F(3)}=0.46$


Problem 4
========================================================


Given
\[
    f(x)= 
\begin{cases}
\frac{a}{\pi(1+x^2)},& x \in (0,1)\\
0, & x \notin (0,1) \\
\end{cases}
\]

a) compute $a$.

By normalization we have 
$\int_0^1 f(x)dx=\frac{a}{\pi}\tan^{-1}(x)\Big|_0^1=\frac{a}{\pi}\frac{\pi}{4}=1$ then $a=4$
</br>b) compute $E(X)=\int_0^1 \frac{ax}{\pi(1+x^2)}dx$
</br>$=\frac{4}{\pi}\tan^{-1}(x)x\Big|_0^1 - \frac{4}{\pi}\int_0^1 \tan^{-1}(x)dx$
</br>$=\frac{4}{\pi}\frac{1}{2}\log(x^2+1)\Big|_0^1=0.441$



Problem 4
========================================================

c) compute $F(X)$

We had already computed the indefinite integral: $F(x)=\int f(t)dt$, we now set the limits of intergration from 0 to $x$
$F(x)=\int_0^x f(t)dt$ within (0,1).

\[
F(x)= 
\begin{cases}
0, & x \leq 0 \\
\frac{4}{\pi}\tan^{-1}(x),& x \in (0,1)\\
0, & x \geq 1 \\
\end{cases}
\]



Problem 5
========================================================


Given
\[
    f(x)= 
\begin{cases}
\frac{x}{\theta^2}e^{-x^2/(2\theta^2)},& x >0\\
0, & x \leq 0 \\
\end{cases}
\]

a) prove that it is a probability density function.

We probe that $f(x)$ satisfies the the normalization condition $\int_0^\infty f(x)dx=1$

Change variable $z=\frac{x^2}{2\theta^2}$ then the differential changes to $dz=\frac{x}{\theta^2}dx$
</br>$\int_0^\infty f(x)dx=\int_0^\infty e^{-z} dz= -e^{-z}\Big|_0^\infty=1$

Problem 5
========================================================

b) compute $F(x)$

- for $x > 0$
$F(x)=\int_0^x \frac{t}{\theta^2}e^{-t^2/(2\theta^2)}dt$
changing to variable $z=\frac{t^2}{2\theta^2}$
</br>$=-e^{-z}\Big|_0^{x^2/(2\theta^2)}= 1 - e^{-x^2/(2\theta^2)}$


- for $x \leq 0$, $F(x)=0$



Problem 6
========================================================

Given
\[
    f(x)= 
\begin{cases}
0, & x < 0 \\
ax, & x \in [0,3] \\
b, & x \in (3,5) \\
\frac{b}{3}(8-x),& x \in [5,8]\\
0, & x > 8 \\
\end{cases}
\]


a) compute $a$ and $b$ such that $f(x)$ is a probability density function.


Problem 6
========================================================

i) by continuity
$\lim_{x\rightarrow 3} f(x)=f(3)$ from both sides then:
</br>$3*a=b$

ii) by normalization $\int_{-\infty}^\infty f(x)dx=1$ and i)
</br>$\int_0^3 ax dx + \int_3^5 3a dx +\int_5^8 a(8-x)dx$
</br>$\frac{a}{2}x^2\Big|_0^3 + 3ax\Big|_3^5 + a8x\Big|_5^8-\frac{a}{2}x^2|_5^8=1$

replacing and solving for $a$ then $a=\frac{1}{15}$ and by i) $b=\frac{1}{5}$



Problem 6
========================================================

b) compute $P(3\lt X\lt 5 |  3\lt X)$
</br>$P(3\lt X\lt 5 |  3\lt X) =\frac{P(3\lt X\lt 5 \cap 3 \lt X)}{P(3 \lt X)}$
</br>$=\frac{P(3\lt X\lt 5)}{P(3 \lt X)}=\frac{P(3 \lt X \lt 5)}{1-P(X \lt 3)}$

on one hand:
$P(3 \lt X \lt 5)=\int_3^5 \frac{1}{5}dx=\frac{1}{5}x\Big|_3^5=\frac{2}{5}$

on the other  hand:
$P(X<3)=\int_0^3\frac{1}{15}xdx=\frac{1}{30}x^2\Big|_0^3=\frac{3}{10}$

then $P(3 \lt X \lt 5|3 \lt X)=\frac{2/5}{1-3/10}=4/7$

Problem 7
========================================================

| x | $P(X=x)$ |
|-----|---------|
|10|0.1|
|12|0.3|
|14|0.25|
|15|0.15|
|17| |
|20|0.15|

a) what is $E(X)$ and $\sigma=\sqrt{V(X)}$?
</br>fist we compute $P(X=17)= 1 - P(X\neq 17)= 0.05$


Problem 7
========================================================

Then we explicitly calculate $E(X)=\sum_i^m x_i*P(X=x_i)$

$E(X)=0.1*10+0.3*12+0.25*14+0.15*15+0.05*17+0.15*20=14.2$

and $V(X)$ from the expression: $V(X)= E(X^2)-E(X)^2$

$E(X^2)=0.1*10^2+0.3*12^2+0.25*14^2+0.15*15^2+0.05*17^2+0.15*20^2=22.96$

then 
$V(X)= E(X^2)-E(X)^2=22.96-14.2= 8.76$ and $\sigma=\sqrt{8.76}=2.96$

Problem 8
========================================================
Given the cumulative distribution for a discrete variable X

\[
    F(x)= 
\begin{cases}
0, & x \leq -1 \\
0.2,& x \in [-1,0)\\
0.35,& x \in [0,1)\\
0.45,& x \in [1,2)\\
1,& x \geq 2\\
\end{cases}
\]

a) find $E(X)$ and $V(X)$

$E(X)=\sum_i^4 x_i*f(x_i)$ therefore we need to find the probability mass distribution $f(x_i)$

Problem 8
========================================================

\[
    f(x)= 
\begin{cases}
0, & x< -1 \\
F(0)-F(-1)=0.2,& x=-1\\
F(1)-F(0)= 0.15,& x=0\\
F(2)-F(1)= 0.10,& x=1\\
1-F(2)=0.55 ,&x=2\\
\end{cases}
\]

therefore:

- $E(X)=0.2*1+0.5*0+0.1*1+0.55*2=1$

- $V(X)=E(X^2)-E(X)^2=0.2*1^2+0.5*0^2+0.1*1^2+0.55*2^2 - 1=1.5$
then $\sigma=\sqrt{1.5}$

Problem 8
========================================================

If $Y=2X-3$ then 

- $E(Y)= E(2X-3)=2E(X)-3=-1$

- $V(X)= V(2X-3)= 2^2X(X)= 1.5*4=6$


Problem 9
========================================================
Given the cumulative distribution for a random variable X

\[
    F(x)= 
\begin{cases}
0, & x \lt -1 \\
\frac{1}{80}(17+16x-x^2),& x \in [-1,7)\\
1,& x \geq 7\\
\end{cases}
\]


a) compute $P(X>0)$

$P(X>0)= 1- P(X\leq0) = 1-\frac{17}{80}=\frac{63}{80}$


Problem 9
========================================================

b) compute $E(X)=\int_{-\infty}^\infty x f(x)dx$ 

We need to find $f(x)$ by differentiation

\[
    f(x)= 
\begin{cases}
0, & x \notin (1,7) \\
\frac{16}{80}-\frac{2x}{80},& x \in (-1,7)\\
\end{cases}
\]

Then: $E(X)=\int_{-1}^7 \frac{16}{80}x-\frac{2}{80}x^2 dx$
</br>$= \frac{16}{80}\frac{x^2}{2}-\frac{2}{80}\frac{x^3}{3}\Big|_1^7$
</br>$= \frac{48}{10}-\frac{344}{120}=1.933$


Problem 9
========================================================

c) compute $P(X>0|X<2)$

$P(X>0|X<2)=\frac{P(X>0 \cap X<2)}{P(X<2)}$
</br>$=\frac{P(0<X<2)}{P(X<2)}$
</br>$=\frac{F(2)-F(1)}{F(2)}=\frac{45-17}{17}=\frac{28}{45}$



Problem 10
========================================================
Given the probability mass function and distribution

| x | $f(x)=P(X=x)$ | F(x) |
|-----|---------|---------|
|0|0.15||
|1|a||
|2|b|0.7|
|3|c||
|4|0.2 ||

and  $E(X)=2$


Problem 10
========================================================
a) find the values of $a$, $b$ and $c$. 

We solve the system of equations:
</br>i) normalization: $\sum_1^5 f(x_i)=1$
</br>$a+b+c+0.35 = 1$
</br>$a+b+c-0.65 = 0$
</br>ii) expectation: $E(X)=\sum_1^5 x_if(x_i)=2$
</br>$a+2b+3c+0.2*4=2$
</br>$a+2b+3c-1.2=0$

Problem 10
========================================================

and
</br>iii) value of $F(2)=0.7$
</br>$1.5+a+b=0.7$
</br>$a+b-0.55=0$
</br>The solution of the system is: $a=0.2$, $b=0.35$, $c=0.1$

b) compute the $E(X)$ and $V(X)$
</br>$E(X)=\sum_i^m x_i*P(X=x_i)=1*0.2+2*0.35+3*0.1+4*0.2=2$
</br>$V(X)=E(X^2)+E(X)^2$
</br>$=1^2*0.2+2^2*0.35+3^2*0.1+4^2*0.2-2^2=1.7$

Problem 10
========================================================

c) if $Y=-5+10X$ then $E(Y)=5+10*E(X)=25$ and </br>$V(Y)=10^2*V(X)=170$



Problem 11
========================================================
Given 

\[
    f(x)= 
\begin{cases}
\frac{c}{x^3}, & x \geq 1 \\
0,& x < 1\\
\end{cases}
\]

a) compute $c$ so that the function is a probability density function and then $E(X)$.
</br>$\int_1^\infty\frac{c}{x^3}=-\frac{1}{2}c x^{-2}\Big|_1^\infty=\frac{1}{2}c=1$ then $c=2$

then
</br>$E(X)=\int_1^\infty \frac{2}{x^2}dx = -2x^{-1}\Big|_1^\infty=2$


Problem 11
========================================================

b) compute $F(X)$

$F(X)=\int_1^x \frac{2}{t^3}dt=\frac{1}{2}2t^{-2}\Big|_1^x=-\frac{1}{x^2}+1$


b) compute $\frac{P(X \leq 2.5)}{P(X\leq 10)}$

$\frac{P(x\leq 2.5)}{P(x\leq 10)}=\frac{-1/(2.5^2)+1}{-1/(10^2)+1}=0.84$
