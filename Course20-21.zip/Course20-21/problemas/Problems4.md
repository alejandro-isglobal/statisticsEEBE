Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 4 (Tema 5 part 2)</p>



Formula
========================================================


| Model | outcome    | x  |  f(x) | E(X) | V(X) |
| ----------- | ------------- | ------ | ----- | ---- | ---- |
| Uniform | $n$ discrete values | a,... b| $\frac{1}{n}$ |$\frac{b+a}{2}$ |  $\frac{(b-a+1)^2-1}{12}$ | 
| Bernoulli             | A event | 0,1 | $p^x(1-p)^{1-x}$ | $p$ | $p(1-p)$ |
| Binomial | \# of A events | 0,1,...| $\binom n x p^x(1-p)^{n-x}$ | $np$ | $np(1-p)$ |
| Geometric | \# of B events until event A | 0,1,...|$p(1-p)^{x}$| $\frac{1-p}{p}$ |$\frac{1-p}{p^2}$ |
| Shifted geometric | \# of **trials** until event A | 1,2,...| $p(1-p)^{x-1}$ | $\frac{1}{p}$ | $\frac{1-p}{p^2}$ |
| Negative Binomial | \# of B events until r A events | 0,1,.. |$\binom {x+r-1} x p^r(1-p)^x$ | $r\frac{1-p}{p}$ | $r\frac{1-p}{p^2}$ |
| Hypergeometric | \# of A events in a sample $n$ |$\max(0, n+K-N)$, ... $\min(K, n)$ | $\frac{1}{\binom N n}\binom K x \binom {N-K} {n-x}$ | $np$ | $np(1-p)\frac{N-n}{N-1}$ |
| Poisson | \# of A events in an interval | 0,1, ..| $\frac{e^{-\lambda}\lambda^x}{x!}$ | $\lambda$ | $\lambda$ |
| Exponential | Interval between two events A | $[0,\infty)$ | $\lambda e^{-\lambda x}$ | $\frac{1}{\lambda}$ | $\frac{1}{\lambda^2}$ |
| Normal | measurement with symmetric errors whose most likely value is the average  | $(-\infty, \infty)$|$\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma^2}}$ | $\mu$ |$\sigma^2$ |





Problem 1
========================================================

Consider: 

- random variables: $X$ particles/minute, $Y$ particles/0.5minutes

- $P(X>0)$=0.996


a) What is $P(Y<2)$?

Poisson distribution:
$P(X=k)=f(k;\lambda)=\frac{e^{-\lambda}\lambda^k}{k!}$

Problem 1
========================================================
- We find $\lambda$ for one minute
</br>$f(0,\lambda)=e^{-\lambda}=1-P(X>0)=1-0.996$
</br>$\lambda=\log(0.004)m^{-1}=5.52m^{-1}$

- We find $\lambda$ in units of $(0.5m)^{-1}$
</br>$\lambda=5.52*0.5*(0.5m)^{-1}=2.76 (0.5m)^{-1}=\lambda_{0.5}$

- We compute
</br>$P(Y<2)=F_{pois}(1;\lambda_{0.5})= f(0;\lambda_{0.5})+f(1;\lambda_{0.5})$
</br>$=e^{-\lambda_{0.5}} +e^{-\lambda_{0.5}}\lambda_{0.5}=0.23$


Problem 1
========================================================

b) find $q_{0.25}$
</br>$q_{0.25}=P(Y \leq y)=F_{pois}(y)=0.25$

- From the previous result we know $F_{pois}(1;\lambda_{0.5})=0.23$. We are almost there.

- We compute 
</br>$F_{pois}(2;\lambda_{0.5})=\sum_{i=0,1,2}f(i;\lambda_{0.5})=F_{pois}(1;\lambda_{0.5})+f(2;\lambda_{0.5})$
</br>$=0.23+\frac{e^{-\lambda_{0.5}}\lambda_{0.5}^2}{2}=0.47$
</br>then $q_{0.25} \in (1,2)$



Problem 1
========================================================

c) consider:

- $p=0.2$ probability of being radioactive particles
- $n=5$ number of particles detected
- $X$ number of radiactive particles detected

compute $P(X \leq 2)$: the minority of particles are radioactive (or the majority of particles are not radioactive)


Problem 1
========================================================

Binomial distribution:

$P(X=k)=f(k;n,p)=\binom n k p^k(1-p)^{n-k}$ or $X \hookrightarrow Bin(n,p)$

$P(X \leq 2)=F_{bin}(2)=f(0;n,p)+f(1;n,p)+f(2;n,p)$
</br>$= \binom 5 0 (1-p)^5 + \binom 5 1 p(1-p)^4+ \binom 5 2 p^2(1-p)^3=0.94$


d) The expected value of radioactive particles is the mean $E(X)=n*0.2=1$. That is, we expect to find 1 radioactive particle when we select 5 particles. 



Problem 3
========================================================

- 6 buses arrive every hour. Then $\lambda=6buses/hour$
- number of buses $X \hookrightarrow Pois(\lambda)$

a) compute $P(T>1/3hour)$

Exponential density distribution for the time

$f(t;\lambda)=\lambda e^{-\lambda t}$

Problem 3
========================================================

$P(T>1/3)= 1 - P(T \leq 1/3)= \int_0^{1/3} \lambda e^{-\lambda t} dt$
</br>$= 1- (1-e^{-\lambda t}) \Big |_0^{1/3}=e^{-2}=0.135$


b) compute: $P(T<1/3|T>1/6)$

$P(T<1/3|T>1/6)=\frac{P(T<1/3\cap T>1/6)}{P(T\gt1/6)}=\frac{P(1/6\lt T \lt 1/3)}{P(T \gt 1/6)}$
</br>$= \frac{F_{exp}(1/3)- F_{exp}(1/6)}{1-F_{exp}(1/6)}$

now; $F_{exp}(x)= 1-e^{-\lambda t}|_0^x=1-e^{-\lambda x}=1-e^{-6 x}$
</br>$P(T<1/3|T>1/6)=\frac{1-e^{-2}-1+e^{-1}}{1-(1-e^{-1})}=0.63$



Problem 5
========================================================

- Number of people taking sick days $X \hookrightarrow Pois(\lambda)$

$P(X=k)=f(k;\lambda)=\frac{e^{-\lambda}\lambda^k}{k!}$


- $P(X=1)=\frac{1}{2}P(X=0)$

a) compute: $E(X)$


Problem 5
========================================================

- first we find $\lambda$
</br>$P(X=1)=\frac{1}{2}P(X=0)$
</br>$f(1;\lambda)=\frac{1}{2}f(0;\lambda)$
</br>$e^{-\lambda} \lambda = \frac{1}{2} e^{-\lambda}$
</br> then $\lambda=\frac{1}{2}$ 

For a Poisson distribution $E(X)=\lambda=0.5$

Problem 5
========================================================

b) Probability that in two consecutive days two people are taking sick days and the following day another two take a sick day.

They are independent events then:

$P(X=2)*P(X=2)= f(2; \lambda)^2=[\frac{e^{-0.5}0.5^2}{2!}]^2=0.0057$


Problem 5
========================================================

c) compute $P(Y \leq 2)$ where $Y$ is the number of people taking sick days in a period of 3 days, and mean value in units of 1/3days is
</br>$\lambda_{3d}=3\lambda(1/3d)=3/2$

</br>$P(Y \leq 2)= F_{pois}(2)=f(0; \lambda_{3d})+ f(1; \lambda_{3d})+ f(2; \lambda_{3d})$
</br>$=e^{-3/2}+e^{-3/2}3/2+\frac{e^{-3/2}(3/2)^2}{2}=0.808$



Problem 6
========================================================


- $f(x)=\lambda^{-\lambda x}$, where $\lambda=0.01386$ 

a) Compute the median of $f(x)$
</br>$F_{exp}(x_m)=1-e^{-\lambda x_m}=0.5$
</br>$x_m=-\frac{\log(0.5)}{\lambda}=50.01$



Problem 9
========================================================

- The numnber of constumers that arrive to a cashier every 15min is $X  \hookrightarrow Pois(\lambda)$ with $E(X)=5$, then $\lambda_{15mim}=E(X)=5$

a) compute: $P(T> 3m)$; 

first we compute $\lambda$ in units of $m^{-1}$: 

$\lambda_{15m}=5 \frac{1}{15m}= \frac{1}{3}m^{-1}=\lambda_{1m}$

$T$ distributes exponentially: $f(t;\lambda_{1min})=\lambda_{1min} e^{-\lambda_{1min} t}$
</br>$P(T> 3m)= 1-P(T \leq 3m)= 1-F_{exp}(3; \lambda_{1m})$

Remember that: $F_{exp}(x)= 1-e^{-\lambda t}|_0^x=1-e^{-\lambda x}$
</br>$P(T> 3m)= 1 - (1-e^{-1})=0.36$


Problem 9
========================================================

</br>$P(T<6|T>3)=\frac{P(3\lt T \lt 6)}{P(T \geq 3)}$
</br>$= \frac{F_{exp}(6)- F_{exp}(3)}{1-F_{exp}(3)}$
</br>$= \frac{-e^{-6/3}+e^{-3/3}}{e^{-3/3}}=1-e^{-1}=0.63$


Problem 11
========================================================

- The number of earthquakes in 100 years $X \hookrightarrow Pois(\lambda=2.1)$

a) What is the probability of an earthquake in a region occurs within the next 25 years if the region has not experienced an earthquake for 10 years. 

- compute $P(T \leq 0.25 | T >0.1)$

where $T$ is an exponential variable $f(t; \lambda)=\lambda e^{-\lambda t}$, and $F_{exp}(x)= 1-e^{-\lambda t}|_0^x=1-e^{-\lambda x}$

 $P(T \leq 0.25 | T >0.1)=\frac{P(0.1 < T \leq 0.25)}{P(T > 0.1)}$
</br>$= \frac{F_{exp}(0.25)- F_{exp}(0.1)}{1-F_{exp}(0.1)}$
</br>$= \frac{-e^{-0.25*2.1}+e^{-0.1*2.1}}{e^{-0.1*2.1}}=1-e^{-2.1(0.25-0.1)}=0.2702$


Problem 14
========================================================

Consider

- The mean time between two light bolts $\mu_T=52.8$  
- $f(t; \lambda)=e^{-\lambda t} \lambda$, where $E(X)=\frac{1}{\lambda}=\mu_T=52.8$, $\lambda=1/52.8$

a) Compute $P(T>120)$
</br>Remember: $F_{exp}(x)= 1-e^{-\lambda t}|_0^x=1-e^{-\lambda x}$
</br>$P(T>120)=1-P(T\leq 120)=1-F_{exp}(x)=-e^{120/52.8}=0.103$


Problem 14
========================================================

b) compute $P(T\leq 72 | T> 42)$

</br>$P(T\leq 72|T>42)=\frac{P(42\lt T \leq 72)}{P(T \geq 42)}$
</br>$= \frac{F_{exp}(72)- F_{exp}(42)}{1-F_{exp}(42)}$
</br>$= \frac{e^{-42/52.8}-e^{-72/52.8}}{e^{-42/52.8}}=0.433$


Problem 14
========================================================

c) compute $P(T \leq M_T ) = 0.5$.
</br>$P(T \leq M_T )=F_{exp}(M_T)=0.5$
</br>$1-e^{\lambda t}=0.5$

solving form $M_T$ then
</br>$M_t=-\frac{\log(0.5)}{\lambda}=\log(0.5)*52.8=36.59$

$M_t>\mu_T$



Problem 16
========================================================

Consider

- $X$ is the lifetime of NNN particle $X \hookrightarrow N(\mu, \sigma^2)$

- $P(X>42)=0.9452$
- $P(X>52)=0.34458$


Problem 16
========================================================

a) compute $P(X\leq 48)$
</br>$P(X\leq 48)=F_{norm}(48; \mu, \sigma^2)=\Phi(\frac{48-\mu}{\sigma})$

Remember: $\Phi(x)$ is the cumulative probability function for the standard distribution that is found in tables.

- we need $\mu$ and $\sigma$
</br> i) $P(X>42)=0.9452$
</br>$P(X>42)=1-F_{norm}(42; \mu, \sigma^2)=1-\Phi(\frac{42-\mu}{\sigma})=0.9452$

then
</br>$\Phi(\frac{42-\mu}{\sigma})=1-0.9452=0.0548$
</br>$\frac{42-\mu}{\sigma}=\Phi^{-1}(0.0548)$


Problem 16
========================================================

in R

- $\Phi(z)$ is <code>pnorm(z)</code>
- $\Phi^{-1}(prob)$ is <code>qnorm(prob)</code>
</br><code>qnorm(0.0548)</code>$=-1.6$

i) $\frac{42-\mu}{\sigma}=-1.6$
</br> The other equation follows from $P(X>52)=0.34458$
</br>$\frac{52-\mu}{\sigma}=\Phi^{-1}(1-0.34458)=\Phi^{-1}(0.65542)=$<code>qnorm(0.65542)</code>

ii) $\frac{52-\mu}{\sigma}=0.4$


Problem 16
========================================================

Solving i. and ii. for $\mu$ and $\sigma$ we find
$\mu=50$, $\sigma=5$

then

$P(X\leq 48)=\Phi(\frac{48-\mu}{\sigma})$
</br>$=\Phi(\frac{48-50}{5})=$<code>pnorm(-0.4)</code>$=0.3445783$


Problem 16
========================================================
Note on the use of tables:

- Tables do have $\Phi(z)$ only for $z>0$, or $\Phi^{-1}(p)$, for $p>0.5$ 

- We know that $\Phi(z)$ is symetric then $\Phi(-z)=1-\Phi(z)$, or $\Phi^{-1}(p)=-\Phi^{-1}(1-p)$

- To compute $\Phi^{-1}(0.0548)$ as $p<0.5$ we look for $\Phi^{-1}(1-0.0548)=0.9452$ and the $z$ we find we will multiply it by $-1$.

Problem 16
========================================================
for $\Phi^{-1}(0.9452)$ we look the cell with the probability $0.9452$. We find the closest in $0.9450$ that corresponds to $1.64$  (row: 1.6, column:0.04), We multiply $1.64$ by $-1$ because $p<0.5$, then $\Phi^{-1}(0.0548)=-1.6$
.</br><img src="./tab1.JPG" style="width:45%"  align="center">



Problem 16
========================================================
for $\Phi^{-1}(0.65542)$ we look the cell with the probability $0.65542$. We find the cell that correspons to 0.400 (row: 0.4, column:0.00), since $p>0.5$ that is the result! $\Phi^{-1}(0.0548)=0.04$ 

.</br><img src="./tab2.JPG" style="width:45%"  align="center">



Problem 17
========================================================

Consider

- the number of railway disruptions $X\hookrightarrow Pois(\lambda_{1month})$, then $P(X=k)=f(k;\lambda)=\frac{\lambda_{1month}^k}{k!}$

- $P(X\geq 0)=P(X=0)$

Compute $P(Y>1)$, where $Y$ is the number of disruptions in 3 months


Problem 17
========================================================

- We first compute $\lambda_{1month}$

$P(X\geq 0)=P(X=0)$ then
</br>$1-P(X=0)=P(X=0)$, and $P(X=0)=0.5$
</br> then $e^{-\lambda_{1month}}=0.5$ and 

$\lambda_{1month}=-\log(0.5)=0.693$
</br> then change the units to $3months^{-1}$

$\lambda_{3months}=3*\lambda_{1month}=2.079$

</br>$P(Y>1)=1-P(Y\leq1)=1-f(0,\lambda_{3months})-f(1,\lambda_{3months})$
</br>$=1-e^{-\lambda_{3months}}-e^{-\lambda_{3months}}\lambda_{3months}=0.615$

Problem 17
========================================================

b) Consider now

- The probability of a trimester without disruptions $P(Y=0)=e^{-2.079}=0.125$

- $p=0.15$ is the probability of an event $A$ (for no disruptions in three months) in a Bernoulli trial 

- $X$ is the number of trimesters with disruptions ($B$)
observed before an event without disruptions appears.

Then $X \hookrightarrow Geom(p)$; $P(X=k)=f(k)=(1-p)^kp$

Compute $P(X = 2)$

$P(X = 2)=f(2)=(1-0.125)^2*0.125=0.0957$

Problem 18
========================================================

Consider:

- $\lambda=3/mes$
- the amount of accidents in a month $X \hookrightarrow Pois(\lambda)$ then $P(X=k)=f_{pois}(k; \lambda)=e^{-\lambda k} \frac{\lambda^k}{k!}$ 

Here we compute the probability of event A: **a month with at most one accident**. 

$P(X\leq 1)=F_{pois}(1)=f_{pois}(0;\lambda)+f_{pois}(1;\lambda)$
</br>$=e^{-\lambda}+e^{-\lambda}\lambda=0.199$

Remember that:$F_{pois}(1; \lambda=3)=$ <code>ppois(1, 3)</code>

- $p=0.199$ probability of a month with at most one accident.

Problem 18
========================================================

a) compute $P(Y=3)$ where $Y$ is the number of months with more than one accident (B) before a month with at most one accident (A).

then $Y \hookrightarrow Geom(p)$ and $P(X=k)=f(k; p)=(1-p)^kp$

$P(Y=3)=(1-p)^3p=0.102$

Problem 18
========================================================

b) now consider
- The number of days a year with no accidents $W \hookrightarrow Bin(n=360,p)$, where $p$ is the probability of no accidents per day.

We compute the probability of no accidents per day. First we compute $\lambda_{day}=\lambda/30=1/10$

- $Z \hookrightarrow Pois(\lambda_{day})$ and $P(Z=k)=f_{pois}(k; \lambda_{day})= \frac{e^{-\lambda_{day} k}\lambda_{day}^k}{k!}$  

- $P(Z=0)=e^{-\lambda_{day}}=e^{-1/10}=0.904$


Problem 18
========================================================
Finally 

- $P(Z=0)=p$ for $W\hookrightarrow Bin(n=360,p)$ then

$E(W)=np=360*0.904=325.74$
