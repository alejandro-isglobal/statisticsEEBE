Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 1 (Tema 3)</p>

Objective
========================================================

Problems on:

- Probability algebra
- Conditional probability
- Baye's theorem 


Problem 1
========================================================

A brick test is defined by the following events on a brick:

- Defective: $D$, non-defective: $\bar{D}$
- Pass quality test: $E$, do no pass quality test: $\bar{E}$


The brick test has: 

- sensitivity: $P(E|\bar{D})=0.99$ 
- especificity: $P(\bar{E}|D)=0.98$
- positive test marginal probability: $P(E)=0.893$

a) what is the probability that a brick chosen at random is defective, P(D)?

Problem 1
========================================================

We might want to start with: $P(D) = P(D\cap E) + P(D\cap \bar{E})$ but we will have to condition on $E$ and have no information on $P(D|E)$ or $P(D|\bar{E})$.

We then start by 
</br> $P(E) = P(E\cap D) + P(E\cap \bar{D})$
</br> $= P(E|D)P(D) + P(E|\bar{D})P(\bar{D})$
</br> $= (1-P(\bar{E}|D))P(D) + P(E|\bar{D})(1-P(D))$

We solve for $P(D)$
</br>$P(D)=\frac{P(E)-P(E|\bar{D})}{1-P(E|D)-P(E|\bar{D})}=\frac{0.893-0.99}{1-0.98-0.99}=0.1$


Problem 1
========================================================
b) What is the probability that a brick that has passed the test is really defective?

$P(D|E) = \frac{P(E|D)P(D)}{P(E)}=\frac{[1-P(\bar{E}|D)]P(D)}{P(E)}$
</br>$P(D|E) = \frac{(1-0.98)0.01}{0.893}=0.0022$

c) The probability that a brick is not defective **and** that it does not pass the test

$P(\bar{E} \cap \bar{D})=P(\bar{E}|\bar{D})P(\bar{D})= 0.01*(1- 0.1)=0.009$


Problem 1
========================================================
d) Are $D$ and $\bar{E}$ statistical independent?

- if so then, 
$P(D \cap \bar{E})= P(D)P(\bar{E})$
</br>$=P(D|\bar{E})P(\bar{E})=P(D)P(\bar{E})$
or</br>$=P(D|\bar{E})=P(D)$

- as we have 
$P(D|E)=0.0022$ and $P(D)=0.01$ then $P(D|E) \neq P(D)$ and $D$ and $\bar{E}$ are stistical dependent.



Problem 2
========================================================

Comunication chanel with 

- imput {a,b} and output {1,0}

- probabilities: $Pr(a) = 0.6$, $Pr(b) = 0.4$, $Pr(0|a) = 0.2$ and $Pr(0|b) = 0.6$ 


Problem 2
========================================================

- rule: $P(imput=x|output=z)\geq P(imput=y|output=z)$ then imput $x$ is assigned to output $z$ (i.e. $P(b|0)\geq P(a|0)$ then $b$ is assiged to $0$).


||**a**|**b**| **sum** |
|--------|--------|--------|--------|
|**0**|P(0,a)|P(0,b)| P(0) |
|**1**|P(1,a)|P(1,b)| P(1) |
|**sum**|P(a)|P(b)| 1 |


Problem 2
========================================================

a) If the output was 0 what was the input?

||**a**|**b**|**sum** |
|--------|--------|--------|--------|
|**0**|P(a<span>&#124;</span>0)|P(b<span>&#124;</span>0)| 1 |
|**1**|P(a<span>&#124;</span>1)|P(b<span>&#124;</span>1)| 1 |

- $P(a|0)=\frac{P(0|a)P(a)}{P(0)}=\frac{0.2*0.6}{P(0)}$
- $P(b|0)=\frac{P(0|b)P(b)}{P(0)}=\frac{0.6*0.4}{P(0)}$

then $P(b|0) > P(a|0)$ and we asign $b$ to $0$


Problem 2
========================================================

b) If the output was 1 what was the imput?

- $P(a|1)=\frac{P(1|a)P(a)}{P(1)}=\frac{[1-P(0|a)]P(a)}{P(1)}=\frac{0.8*0.6}{P(1)}$
- $P(b|1)=\frac{P(1|b)P(b)}{P(1)}=\frac{[1-P(0|b)]P(a)}{P(1)}=\frac{0.4*0.4}{P(1)}$
then $P(a|1) > P(b|1)$ and we asign $a$ to $1$

Problem 2
========================================================
c) What is the error rate?


||**a**|**b**| **sum** |
|--------|--------|--------|--------|
|**0**|P(0,a)|**P(0,b)**| P(0) |
|**1**|**P(1,a)**|P(1,b)| P(1) |
|**sum**|P(a)|P(b)| 1 |

probabiity of error: $P(0,a)+P(1,b)$
</br>$P(0,a)+P(1,b)= P(0 \cap a)+P(1 \cap b)$
</br>$=P(0|a)P(a)+P(1|b)P(b)= 0.2*0.6+0.4*0.4=0.28$

Problem 3
========================================================

Restaurant with :
- three menus {M1, M2, M3} each with two courses: starter and main course.

Costumers rate the courses:

- ${B1, \bar{B1}}$={I liked the stater, I did not like the starter}
- ${B2, \bar{B2}}$={I liked the main dish, I did not like the main dish}

- each customer is given a two-course meal, each course randomly selected from one of the menus. 


Problem 3
========================================================

Probabilitites:

- $P(M1)=P(M2)=P(M3)$,then $P(M1)=P(M2)=P(M3)=1/3$ because
$P(M1)+P(M2)+P(M3)=1$

The preference for each course given the menu is
- $P(B1|M1)=P(B2|M1)=9/10$
- $P(B1|M2)=P(B2|M2)=1/2$
- $P(B1|M3)=P(B2|M3)=3/10$


Problem 3
========================================================

a) What is the probability that a customer likes the starter: $P(B1)$?

$P(B1)=P(B1\cap M1)+P(B1\cap M2)+P(B1\cap M3)$
</br>$=P(B1 | M1)P(M1)+P(B1 | M2)P(M2)+P(B1 | M3)P(M3)$
</br>$= 9/10*1/3 + 1/2*1/3+3/10*1/3=17/30$


b) If the customer liked the starter, what is the probability that it belonged to M3?

$P(M3|B1)= \frac{P(B1|M3)P(M3)}{P(B1)}=\frac{3/10*1/3}{17/30}=3/17$


Problem 3
========================================================

c) What is the probability that the customer liked the starter but not the main dish?


$P(B1)P(\bar{B2})=P(B1)(1-P(B2))=17/30(1-17/30)=0.246$

- Note: $P(B1)=P(B2)$ because the conditional probabilities for each given the menus are the same.


d) What is the probability that the customer liked only one of the courses?

- the probability that the customer liked only the starter  **OR**  that the customer liked only the main course:   

$P(B1)*P(\bar{B2})+P(B2)*P(\bar{B1})= 0.246+ 0.246= 0.492$


Problem 4
========================================================

There are three traffic lights on the road. The probability of finding the first one in red is 0.6. For the other two we have the probabilities $P(R_{j+1}|R_j)=0.15$ and $P(R_{j+1}|\bar{R}_j)=0.25$ for $j=1,2$, where $R_j$ is the event of finding the j-th traffic light in red. If the probability of the one traffic light depends only on the previous one then what is the probability that when passing by the road you

- find all traffic lights in red
- find at least one traffic light in red
- find only one traffic light in red

Problem 4
========================================================

a) find all traffic lights in red $P (R_1 \cap R_2 \cap R_3 )$

- let's expand

$P(R_1 \cap R_2 \cap R_3 )= P( R_2 \cap R_3|R_1) P(R_1)$
because $P(A\cap B)=P(A|B)P(B)$ 

where $A=R_2 \cap R_3$ and $B= R_1$


Problem 4
========================================================

- let's expand further

$P(R_1 \cap R_2 \cap R_3 )= P( R_2 \cap R_3|R_1) P(R_1)$
</br>$=P(R_3|R_2,R_1)P(R2|R_1)P(R_1)$

because $P(A\cap B)=P(A|B)P(B)$, where $P= P(|R_1)$, $A=R_3$ and $B= R_2$


Problem 4
========================================================


we want 
</br>$P (R_1 \cap R_2 \cap R_3 ) =P(R_3|R_2,R1)P(R2|R_1)P(R_1)$

from the problem we know
- $P(R_1)= 0.6$;  $P(R_{2}|R_1)=0.15$; $P(R_{3}|R_2)=0.15$ 
- that $R_3$ is independent of $R_1$ so $P(R_3|R_2,R_1)=P(R_3|R_2)$

then 
</br>$P(R_1 \cap R_2 \cap R_3 )=P(R_3|R_2)P(R2|R_1)P(R_1)$
</br>$=0.6*0.15*0.15=0.0135$



Problem 4
========================================================
b) find at least one traffic light in red
$P(R_1 \cup R_2 \cup R_3)$

let's expand
</br>$P(R_1\cup R_2 \cup R_3)= P(R_1) + P(R_2) + P(R_3)$ 
</br>$- P(R_2| R_1)P(R_1) - P(R_3|R_2)P(R_2) - P(R_3)P(R_1)$ 
</br>$+ P(R_1\cap R_2 \cap R_3)$

we miss $P(R_2)$ and $P(R_3)$

in terms of conditioning to $R_1$
</br>$P(R_2)=P(R_2|R_1)P(R_1)+P(R_2|\bar{R}_1)P(\bar{R}_1)$


Problem 4
========================================================

from the problem we know
- $P(R_1)= 0.6$;  $P(\bar{R}_1)= 0.4$ $P(R_{2}|R_1)=0.15$; $P(R_{2}|\bar{R}_1)=0.25$ 

Therefore

$P(R_2)=0.15*0.6+0.25*0.4=0.19$

What is then $P(R_3)$?


Problem 4
========================================================

in terms of conditioning to $R_2$

$P(R_3)=P(R3|R_2)P(R_2)+P(R3|\bar{R}_2)P(\bar{R}_2)$

now we know
- $P(R_2)= 0.19$;  $P(\bar{R}_2)= 0.81$; $P(R_{3}|R_2)=0.15$; $P(R_{3}|\bar{R}_2)=0.25$ 

$P(R_3)=0.15*0.19+0.25*0.81=0.231$

and $P(R_1\cap R_2 \cap R_3)=0.0135$

Problem 4
========================================================

Collecting everything:

- $P(R_1)= 0.6$; $P(R_2)= 0.19$; $P(R_3)= 0.231$; $P(R_{2}|R_1)=0.15$; $P(R_{3}|R_2)=0.15$;$P(R_1\cap R_2 \cap R_3)=0.0135$ 

then 

</br> $P(R_1\cup R_2 \cup R_3)= P(R_1) + P(R_2) + P(R_3)$
</br> $- P(R_2| R_1)P(R_1) - P(R_3|R_2)P(R_2) - P(R_3)P(R_1)$
</br> $+  P(R_1\cap R_2 \cap R_3)$
</br> $=0.6+0.19+0.231-0.15*0.6-0.15*0.19-0.6*0.231+0.0135$
</br> $=0.77$

Problem 4
========================================================

c) find only one traffic light in red

$P([R_1 \cap \bar{R}_2 \cap \bar{R}_3]\cup[\bar{R}_1 \cap R_2 \cap \bar{R}_3]\cup[\bar{R}_1 \cap \bar{R}_2 \cap R_3])$
</br>$=P(R_1 \cap \bar{R}_2 \cap \bar{R}_3)+P(\bar{R}_1 \cap R_2 \cap \bar{R}_3)+P(\bar{R}_1 \cap \bar{R}_2 \cap R_3)$

Because they are mutually exclusive 

Problem 4
========================================================



$P(R_1 \cap \bar{R}_2 \cap \bar{R}_3)+P(\bar{R}_1 \cap R_2 \cap \bar{R}_3)+(\bar{R}_1 \cap \bar{R}_2 \cap R_3)$
</br>$=P(\bar{R}_3|\bar{R}_2)P(\bar{R}_2|R_1)P(R_1)+P(\bar{R}_3|R_2)P(R_2|\bar{R}_1)P(\bar{R}_1)$ 
</br>$+P(R_3|\bar{R}_2)P(\bar{R}_2|\bar{R}_1)P(\bar{R}_1)$


because $P(R_1 \cap R_2 \cap R_3 ) =P(R_3|R_2)P(R_2|R_1)P(R_1)$



Problem 4
========================================================

now we know
</br>$P(R_{3}|R_2)=0.15$;$P(\bar{R}_{3}|R_2)=0.85$; </br>$P(R_{3}|\bar{R}_2)=0.25$;$P(\bar{R}_{3}|\bar{R}_2)=0.75$;$P(R_1)=0.6$;$P(\bar{R}_1)=0.4$


</br>$P(\bar{R}_3|\bar{R}_2)P(\bar{R}_2|R_1)P(R_1)+P(\bar{R}_3|R_2)P(R_2|\bar{R}_1)P(\bar{R}_1)$ 
</br>$+P(R_3|\bar{R}_2)P(\bar{R}_2|\bar{R}_1)P(\bar{R}_1)$
</br>$=0.75*0.85*0.6+0.85*0.25*0.4+0.25*0.75*0.4=0.5425$


Problem 5
========================================================

20 item-pack of electronic devices is distributed to costumers with the following features

if $D_i$ is the event that a pack contains $i$ defective items

- $D_i \in {0,1,2}$
- $P(D_0)=0.6$
- $P(D_2)=0.1$

Problem 5
========================================================

a) What is the probability of any number of items being defective? 

</br>$P(\bar{D_0})=1-P(D_0)=1-0.6=0-4$


Problem 5
========================================================

b) if we choose two items randomly in a pack, what is the probability that both items are defective?

$d_i$ is the event of selecting a defective item in a pack.

Probability of first selecting a pack with two defective items **AND**  then selecting the two defective items in two random draws: $P( D_2 \cap d_2)$

</br>$P( D_2 \cap d_2)=P(d2|D2)P(D2)$
</br>$=(\frac{2}{20}*\frac{1}{19})*0.1=0.0005263$

Problem 5
========================================================

c) After a pack is randomly chosen and then two items are also randomly chosen, no defective item is observed. What is the proability that the pack does not have any defective item?
</br>$P(D_0|d_0)=\frac{P(d_0|D_0)P(D_0)}{P(d_0)}$
</br>What is $P(d_0)$?
</br>$P(d_0)=P(d_0|D_0)P(D_0)+P(d_0|D_1)P(D_1)+P(d_0|D_2)P(D_2)$
</br>$=1*0.6+(\frac{19}{20}\frac{18}{19})*0.3+(\frac{18}{20}\frac{17}{19})*0.1$

then 
$P(D_0|d_0)=\frac{0.6}{1*0.6+(\frac{19}{20}\frac{18}{19})*0.3+(\frac{18}{20}\frac{17}{19})*0.1}=0.6312$



Problem 6
========================================================

We have a test for detecting bacteria in a water sample. P is the event of a positive test and C is the event that the water is contaminated. The diagnosis has the following features 

- $P(P|C)=0.7$ then $P(\bar{P}|C)=0.3$ 
- $P(\bar{P}|\bar{C})=0.6$ then $P(P|\bar{C})=0.4$
- $P(C)= 0.2$ then $P(\bar{C})= 0.8$


Problem 6
========================================================

a) What is the probability that if the test is positive the sample has a bacteria, $P(C|P)$?


Bayes theorem
$P(C|P)=\frac{P(P|C)*P(C)}{P(P|C)*P(C)+P(P|\bar{C})*P(\bar{C})}$

$P(C|P)=\frac{0.7*0.2}{0.7*0.2+0.4*0.8}=0.3043$

Problem 7
========================================================

Epidemiological facts on people with hypertension (H) and knowing they are hypertense (S):

- $P(H)=0.2$
- $P(S|H)=0.7$
- $P(\bar{S}|\bar{H})=0.6$

If a person does not know she is hypertense what is the probability that she is hypertense?
</br>$P(H|\bar{S})=\frac{P(\bar{S}|H)P(H)}{P(\bar{S})}$
</bar>$=\frac{P(\bar{S}|H)P(H)}{P(\bar{S}|H)P(H) +P(\bar{S}|\bar{H})P(\bar{H})}=\frac{[1-P(S|H)]P(H)}{[1-P(S|H)]P(H) +P(\bar{S}|\bar{H})[1-P(H)]}=0.111$




Problem 8
========================================================

Game of tossing 2 coins and a dice

wining events:

- Two heads and a pair.
- one head one tail and a number greater than 5.

If we know that someone has won, what is the probability that he did it with the first event?

Problem 8
========================================================

Probability for the following events

- getting a pair number on the dice: $P(A)=1/2$

- getting a number greater than 5 in the dice: $P(B)=2/6$

- getting two heads from the coins: $P(C)=1/2*1/2=1/4$

- getting one head and one tail: $P(D)=P(H,T)+P(T,H)=1/4+1/4=1/2$


Problem 8
========================================================

The probability of winning is: 

$P(G)=P(C \cap A \cup D \cap B)$
</br>$=P(C \cap A) + P(D \cap B)=P(C)P(A)+P(D)P(B)=7/24$

and the probability of having two heads when wining (or wining by two heads)

$P(C|G)=\frac{P(C\cap A)}{P(G)}=\frac{1/8}{7/24}=3/7$



Problem 9
========================================================

Capacitors are stored as following

|$\mu$ F| box 1| box 2| box 3| Total
|-------|-------|-------|-------|-------|
|0.01 |20 | 95 | 25 | 140 |
|0.1 | 55 | 35 | 75 | 165 |
|1.0 | 70 | 80 | 145| 295 |
|Total | 145 | 210 | 245 | 600 |


Problem 9
========================================================

Conditional matrix from the experiment

|$\mu$ F| box 1| box 2| box 3| 
|-------|-------|-------|-------|
|0.01 |20/145 | 95/210 | 25/245 |
|0.1 | 55/145 | 35/210 | 75/245 |
|1.0 | 70/145 | 80/210 | 145/245|
|sum | 1 | 1 | 1 | 600 |

$P(c1)=P(c2)=P(c3)=1/3$

Problem 9
========================================================

if we choose a box and a capacitor at random 

a) what is the probability that we select box 2 (c2) and a capacitor of $0.1 \mu F$?
</br>$P(0.1\mu F \cap c2)=P(0.1\mu F |c2)P(c2)=35/210*1/3=210/600$


b) what is the probability to select a capacitor of $0.1 \mu F$?
</br>$P(0.1\mu F)=P(0.1\mu F|c1)P(c1)+P(0.1\mu F|c2)P(c2)+P(0.1\mu F|c3)P(c3)$
</br>$=\frac{20}{145}*1/3+\frac{95}{210}*1/3+\frac{25}{245}*1/3=0.23078$


Problem 9
========================================================

c) if av$1.0\mu F$ has been selected, what is the probability that it belonged to box 1?


</br>$P(c1 |1.0\mu F)=\frac{P(1.0\mu F|c1) P(c1)}{P(1.0\mu F)}=\frac{70/145*1/3}{P(1.0\mu F)}$

We then compute
</br>$P(1.0\mu F)= \frac{70}{145}*1/3+\frac{80}{210}*1/3+\frac{145}{245}*1/3=0.4851$

therefore
</br>$P(c1 |1.0\mu F)=0.33167$



Problem 10
========================================================

A pack of 50 washer rings, 30 of which exceed the required thickness.  

a) if three rings are picked randomly, what is the probability that the three rings exceed the required thickness?


if $A_i$ is the event that the i-th ring exceeds the required thickness then 

$P(A_1 \cap A_2 \cap A_3)=P(A_3 \cap A2|A1) P(A_1)= P(A_3|A_2,A_1)P(A_2|A_1)P(A_1)=28/48*29/49*30/50=0.20714$ is the probability that the three rings exceed the required thickness.

Problem 10
========================================================

b) what is the probability that the third ring exceeds the required thickness?


$P(A_3)=P(A_1 \cap A_2 \cap A_3)+P(A_1 \cap \bar{A_2} \cap A_3)+P(\bar{A_1} \cap A_2 \cap A_3)+P(\bar{A_1} \cap \bar{A_2} \cap A_3)$
</br>$P(A_3 \cap A_2 \cap A_1)=P(A_3|A_2,A_1)P(A_2| A_1)P(A_1)=28/48*29/49*30/50$
</br>$P(A_3 \cap \bar{A_2} \cap A_1)=P(A_3|\bar{A_2}, A_1)P(\bar{A_2}| A_1)P(A_1)=29/48*20/49*30/50$
</br>$P(A_3 \cap A_2 \cap \bar{A_1})=P(A_3|A_2, \bar{A_1})P(A_2| \bar{A_1})P(\bar{A_1})=29/48*30/49*20/50$
</br>$P(A_3 \cap \bar{A_2} \cap \bar{A_1})=P(A_3|\bar{A_2}, \bar{A_1} )P(\bar{A_2}| \bar{A_1})P(\bar{A_1})=30/48*19/49*20/50$

</br>Summing up $P(A3)=0.6$

Problem 11
========================================================


What is the probability of a successful satellite launch from Florida P(A)?

- The probability of a successful satellite launch from Florida P(A) is greater than a launch from Japan P(B)
- The probability that one satellite from Florida **OR** one from Japan is successful is  $P(A \cup B)=0.626$
- The probability that one satellite from Florida **AND** one from Japan are successful is  $P(A \cap B)=0.144$


Problem 11
========================================================


1. $P(A) +  P(B) -P(A \cap B)=0.626$
2. $P(A)P(B)=0.144$

1 and 2. $-P(A)^2+(0.626+0.144)P(A)-0.144=0$ whose solutions are {0.45, 0.32}, since $P(A)\lt P(B)$ then $P(A)=0.45$ and $P(B)=0.32$.

Problem 11
========================================================

b) what is the probability that the system was not tested if it was found to fail, $P(O|F)$?

- not tested: $O$, tested $\bar{O}$

- failed: $F$, not failed $\bar{F}$

Problem 11
========================================================

Probabilities:
</br> $P(O)=2/3$, probability of not testing.
</br> $P(F|O)=1/4$, probability of failing if not tested. 
</br> $P(F|\bar{O}) = P(\bar{F}|\bar{O})$ probabilities of failure and not failure are equall when tested. Then $P(F|\bar{O})=1/2$ because  $P(F|\bar{O}) + P(\bar{F}|\bar{O})=1$.


Problem 11
========================================================

From Baye's theorem we can then compute

$P(O|\bar{F})=\frac{P(\bar{F}|O)P(O)}{P(\bar{F})}=\frac{[1-P(F|O)]P(O)}{1-P(F)}$

We miss $P(F)$
 
$P(F)=P(F|O)P(O)+P(F|\bar{O})P(\bar{O})$
</br>$=P(F|O)P(O)+P(F|\bar{O})[1-P(O)]=1/3$, 

then $P(O|\bar{F})=3/4$ 
 
 


Problem 12
========================================================

Three boxes such that
- First box ($c_1$): 1 white ball , 2 back balls
- Second box ($c_2$): 2 white balls , 1 back ball
- Third box ($c_3$): 3 white balls


Problem 12
========================================================

a) what is the probability of obtaining two white balls from randomly selecting a box and then drawing two balls?

Probability that the first and second balls are white: 

$P(B_1 \cap B_2)$
</br>$=P(B_1 \cap B_2|c_1)P(c_1)+P(B_1 \cap B_2|c_2)P(c_2)+P(B_1 \cap B_2|c_3)P(c_3)$
</br>$= P(B_2|B_1,c_1)P(B1|c_1)P(c_1)+ P(B_2|B_1,c_2)P(B1|c_2)P(c_2)$
</br>$+P(B_2|B_1,c_3)P(B1|c_3)P(c_3)$
</br>$=0 + 1/2*2/3*1/3+ 1*1/3= 4/9$

Problem 12
========================================================

b) If two white balls have been obtained then what is the probability that they come from box1, 2 and 3? which is the most probable box?

- First box:  $P(c_1|B_2 \cap B_1)= \frac{P(B_2 \cap B_1|c_1)P(c_1)}{P(B_2 \cap B_1)}=\frac{P(B_2|B_1,c_1)P(B_1,c_1) P(c_1)}{P(B_2 \cap B_1)}= \frac{0*1/3*1/3}{4/9}$

- Second box:$P(c_2|B_2 \cap B_1)= =\frac{P(B_2|B_1,c_2)P(B_1,c_2) P(c_2)}{P(B_2 \cap B_1)}= \frac{1/2*2/3*1/3}{4/9}=1/4$

- Third box: $P(c_3|B_2 \cap B_1)=1-P(c_2|B_2 \cap B_1)-P(c_1|B_2 \cap B_1)=3/4$. It can also be obtained by  explicitly calculating $P(c_3|B_2 \cap B_1)$ as the other cases. 
