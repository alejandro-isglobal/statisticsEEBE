Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Problems session 5 (Tema 6)</p>




Tema 6: Problem 1
========================================================

- $T_{1/2}=100$
- $\sigma_{X}=30h$
- $n=50$

Therefore 

- $\sigma_{\bar{X}}=\frac{\sigma_{X}}{\sqrt{n}}=30h/\sqrt{50}=$

a. compute: $P(|\bar{X} - T_{1/2}| \leq 1)$

$P(|\bar{X} - T_{1/2}| \leq 1)=P(-1\leq \bar{X} - T_{1/2} \leq 1)$


Let's devide by $\sigma_{\bar{X}}$
</br>$=P(\frac{-1}{\sigma_{\bar{X}}}\leq \frac{\bar{X} - T_{1/2}}{\sigma_{\bar{X}}} \leq \frac{1}{\sigma_{\bar{X}}})$

since $n>30$ by CLT then $Z=\frac{\bar{X} - T_{1/2}}{\sigma_{\bar{X}}} \hookrightarrow N(\mu=0,\sigma^2=1)$

Tema 6: Problem 1
========================================================

We use $\Phi(z)$

$P(|\bar{X} - T_{1/2}| \leq 1)=\Phi( \frac{1}{\sigma_{\bar{X}}}) - \Phi(-\frac{1}{\sigma_{\bar{X}}})=$
</br>$=\Phi(0.24)-\Phi(-0.24)$
</br>$=$<code> pnorm(0.24)-pnorm(-0.24)</code>$=0.189$



Tema 6: Problem 1
========================================================

b. 
- $Y=\sum X_i$ number of components on stock

therefore 

- $\sigma^2_Y=n \sigma^2_X$ 

Compute $n$ such that $P(Y \geq 2750)= 0.95$

$P(Y \geq 2750)= P(\frac{Y}{n}  \geq \frac{2750}{n})=P(\bar{X} \geq \frac{2750}{n})$

standardize 

$P(Y \geq 2750)=P(\frac{\bar{X} -100}{\sigma_X/\sqrt{n}}\geq \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})= 1-P(Z< \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})$

let's assume $n>30$ then  $Z \hookrightarrow N(\mu=0,\sigma^2=1)$



Tema 6: Problem 1
========================================================

$1-P(Z< \frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})=$
$1-\Phi(\frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}})=0.95$

applying $\Phi^{-1}$ 

$\Phi^{-1}(0.05)=$<code>qnorm(0.05)</code>$=\frac{\frac{2750}{n} -100}{\sigma_X/\sqrt{n}}$

Replacing the values and solving for $n$ we have the equation

$100n-49.35\sqrt{n}-2750=0$ of for $t=\sqrt{n}$
</br>$100t^2-49.35t-2750=0$ with roots $t=5.49, -5.00$ 
</br>then $n=t^2=30.20 \sim 31$



Tema 6: Problem 2
========================================================

Consider:

- $X$ weight of one unit
- $E(X)=\mu_X=250gr$
- $\sigma_X=20gr$
- $n=50$
- $Y=\sum_{i=1}^{50} X_i$ the weight of 50 units

a. What is $f(Y)$?

since $Y$ is the sum of normal variable all $N(\mu_X, \sigma_X^2)$ and $n>30$ then

$Y \hookrightarrow N(\mu_Y, \sigma_Y^2)$ where $\mu_Y=E(Y)=n\mu_X$ and $\sigma_Y=V(Y)=n \sigma_X^2$ then 

$Y \hookrightarrow N(n\mu_X, n \sigma_X^2)=N(12.5kg, 0.02kg^2)$



Tema 6: Problem 2
========================================================


b. Compute $P(Y >12.75)$


$P(Y >12.75)= 1 - P(Y \leq 12.75)$

Let's standardize

$1-P(\frac{Y-\mu_Y}{\sigma_Y} \leq \frac{12.75-\mu_Y}{\sigma_Y} )$
</br>$=1-P(Z \leq \frac{12.75 - 12.5}{0.1414})$
</br>$=1-\Phi(1.768)=$<code>1-pnorm(1.768)</code>$= 0.0383$


Tema 6: Problem 2
========================================================


c. Find $\mu_Y$ such that $P(Y \leq 11.5)=0.95$

Standardize
</br>$P(\frac{Y-\mu_Y}{\sigma_Y} \leq \frac{11.5 - \mu_Y}{0.1414})=0.95$

apply $F^{-1}=\Phi^{-1}$
</br>$\frac{11.5 - \mu_Y}{0.1414}=\Phi^{-1}(0.95)=$<code>qnorm(0.95)</code>$=1.644854$

solve for $\mu_Y$
</br>$\mu=11.5- 1.644854*0.1414=225.35$


Tema 6: Problem 3
========================================================

Consider:

- $X$ height of a student $X \hookrightarrow N(\mu_X, \sigma_X^2)$
- $\mu_X= 174.5$
- $\sigma_X= 6.9$

if 

- sample of $n=25$
- $\bar{X}=\frac{1}{25}\sum_{i=1}^{25} X_i$ the sample mean of the height of 25 students 

then 

- $\bar{X} \hookrightarrow N(\mu_X, \sigma_X^2)$
- $\mu_\bar{X}=E(\bar{X})=E(X)=\mu_X=174.5$
- $\sigma_\bar{X}= \frac{\sigma_X}{\sqrt{n}}= 6.9/\sqrt{25}=1.38$


Tema 6: Problem 3
========================================================

b. compute $P(\bar{X} <173)$

standardize

$P(\bar{X} <173)=P(Z < \frac{173 -174.5}{1.38})=P(Z < -1.09)$
</br>$Z \hookrightarrow N(0,1)$ then

$P(Z < -1.09)=$<code>pnorm(-1.09)</code>$=0.1378566$

c. consider a set of $m=200$ from the variable $\bar{X}$

- $Y$ the number of samples with $\bar{X}<1.73$ (event A,$p=0.1378$)
 
then $Y \hookrightarrow Bin(p,m)$, then $E(Y)=mp=200*0.1378= 27.6$
 
Tema 6: Problem 3
========================================================

d. find $n$ for which $E(Y)=mp=9$, then $p=9/200=0.045$

standardize

$P(\bar{X}<173)=P(Z <\frac{173-174.5}{6.9/\sqrt{n}})=\Phi(\frac{173-174.5}{6.9/\sqrt{n}})=0.045$

apply $\Phi^{-1}$

$\frac{173-174.5}{6.9/\sqrt{n}}=$<code>qnorm(0.045)</code>$=-1.695398$ and 

solve for $n$

$n=\big(-1.695398\frac{6.9}{173-174.5}\big)^2=60.82\sim 60$


Tema 6: Problem 4
========================================================

Consider:

- $E(X)=\mu_X=7$
- $\sigma_X=1$
- $n=9$
- $X \hookrightarrow N(\mu_X, \sigma^2_X)$

a. compute $P(6.4 \lt \bar{X} \lt 7.2)$ 

Standardize

$P(\frac{6.4-\mu_\bar{X}}{\sigma_\bar{X}} \lt \frac{\bar{X}-\mu_\bar{X}}{\sigma_\bar{X}} \lt \frac{7.2-\mu_\bar{X}}{\sigma_\bar{X}})$

- $\mu_{\bar{X}}=\mu_{X}=7$
- $\sigma_{\bar{X}}=\frac{\sigma_{X}}{\sqrt{n}}=\frac{1}{3}$
- $\bar{X} \hookrightarrow N(\mu_\bar{X}, \sigma^2_\bar{X})$

$P(\frac{6.4-\mu_\bar{X}}{\sigma_\bar{X}} \lt Z \lt \frac{7.2-\mu_\bar{X}}{\sigma_\bar{X}}) = \Phi(0.6)-\Phi(-1.8)=$
</br><code>pnorm(0.6)-pnorm(-1.8)</code>$=0.6898166$


Tema 6: Problem 4
========================================================

b. Compute $P(\bar{X}> \theta)=0.15$

Standardize

$P(\frac{\bar{X}-\mu_\bar{X}}{\sigma_\bar{X}}  > \frac{\theta-\mu_\bar{X}}{\sigma_\bar{X}} )=0.15$


$P(Z  > \frac{\theta-\mu_\bar{X}}{\sigma_\bar{X}} )=0.15$

$P(Z \leq \frac{\theta-\mu_\bar{X}}{\sigma_\bar{X}})=1-0.15$

$\Phi(\frac{\theta-\mu_\bar{X}}{\sigma_\bar{X}})=0.85$ then 

$\frac{\theta-\mu_\bar{X}}{\sigma_\bar{X}}=\Phi^{-1}(0.85)=$<code>qnorm(0.85)</code>$=1.036433$ then after substitution of the mean and standard deviation of $\bar{x}$ 

$\frac{\theta-7}{1/3}=1.036433$ solving for $\theta$ then $\theta = 7.35$


Tema 6: Problem 5
========================================================


Consider:

- $E(Xi)=\mu_{X_i}=10$
- $\sigma_{X_i}=1$
- $n=100$

We don't know the probability density function fo $X_i$ but because $n>30$ than by the CLT: 

$X=\sum_{i}^{100} X_i \hookrightarrow N(\mu_X, \sigma^2_X)$

where 

- $E(X)=n\mu_{Xi}=100*10=1000$
- $\sigma^2_X= n \sigma^2_{X_i}=10*1=100$



Tema 6: Problem 5
========================================================


a. compute $P(X>1025)$

$P(X>1025)=1-P(X \leq 1025)=1-P(\frac{X-\mu_X}{\sigma_X} \leq \frac{1025-\mu_X}{\sigma_X})$

substitution of $\mu_X$ and the **standard deviation** $\sigma_X$

$P(X>1025)=1-\Phi(2.5)=$<code>1-pnorm(2.5)</code>$=0.00620$


Tema 6: Problem 5
========================================================

b. find $n$ for which $P(X<655.68)=0.975$

Standardize

$P(\frac{X-\mu_X}{\sigma_X} \leq \frac{655.68-\mu_X}{\sigma_X})=0.975$

consider:

- $E(X)=n\mu_{Xi}=n*10$
- $\sigma^2_X=n\sigma^2_{X_i}$ then $\sigma_X=\sqrt{n}\sigma_{X_i}=\sqrt{n}$

then 

$P(Z \leq \frac{655.68-n*10}{\sqrt{n}})=\Phi(\frac{655.68-n*10}{\sqrt{n}})=0.975$

$\frac{655.68-n*10}{\sqrt{n}}=\Phi^{-1}(0.975)=$<code>qnorm(0.975)</code>$=1.959964$

solving for $n$we have the quadratic equation for $\sqrt{n}$
$10n + 1.96\sqrt{n} - 655.68 = 0$ with solutions $\sqrt{n}=-8.19, 8.0$ then 

$n=64$



Tema 6: Problem 6
========================================================

Consider

- $p=0.4$
- $n=2000$
- $X \hookrightarrow Bin(n=2000,p=0.4)$

then

- $E(X)=np=800$
- $V(X)=np(1-p)=480$

Since $n = 2000 > 30$, $np = 800 > 5$ and $nq = 1200 > 5$ then we can approximate the binomial probability function to the normal density function

$X\hookrightarrow N(\mu_X=800,\sigma_X^2=480)$



Tema 6: Problem 6
========================================================

a. compute $P(791 \leq X \leq 809)$

standardize

$P(791 \leq X \leq 809)=P(\frac{791-\mu_X}{\sigma_X} \leq \frac{X-\mu_X}{\sigma_X} \leq \frac{809-\mu_X}{\sigma_X})$
</br>$=\Phi(\frac{809-800}{\sqrt{480}})-\Phi(\frac{791-800}{\sqrt{480}})$
</br>$=$<code>pnorm(0.43361)-pnorm(-0.43361)</code>$=0.3354283$



Tema 6: Problem 7
========================================================


Consider:

- $E(R)=\mu_{R}=40$
- $\sigma_{R}=2$
- $n=36$


a. for $\bar{R}=\frac{1}{36}\sum{i=1}^{36} R_i$ Compute $\mu_bar{R}$ and $\sigma_\bar{R}$

- $E(\bar{R})=\mu_{R}=40$
- $\sigma^2_\bar{R}=\frac{\sigma^2_{R}}{n}=\frac{4}{36}$ or $\sigma_\bar{R}=2/6=1/3$


Tema 6: Problem 7
========================================================

b. compute $P(\bar{R}<39.5)$

standardizing 

$P(\bar{R}<39.5) = P( \frac{\bar{R} - 40}{1/3} < \frac{39.5 - 40}{1/3})$

$P(Z < \frac{39.5 - 40}{1/3})=P(Z < -1.5) = 1 - \Phi(1.5)$
</br>$=$<code>1-pnorm(1.5)</code>$= 0.06681$



Tema 6: Problem 7
========================================================

c. compute: $P(R_T>  1458)$

$P(R_T>  1458)=P(\frac{\sum_{i=1}^{36} R_i}{36} > \frac{1458}{36})$

$P(\bar{R} >  \frac{1458}{36})= P(\bar{R} > 40.5)$

Standardizing
</br>$P(\frac{\bar{R} - 40}{1/3}>\frac{40.5 - 40}{1/3})=P(Z>1.5)$
</br>$=1-P(Z\leq1.5)=$<code>1-pnorm(1.5)</code>$=0.0668072$


Tema 6: Problem 8
========================================================

Consider:

- $\sigma_{X}=16$

a. if $n=10$ compute $P(-2 \leq \bar{X}-\mu_\bar{X} \leq 2)=0.9$

Since we don't know $f(X)$, we don't know $f(\bar{X})$. We could approximate  $f(\bar{X})$ by a normal distribution $N(\mu_{X}, \frac{\sigma^2_{X}}{n})$ if $n>30$ but this is not the case. 

We **cannot** compute the probability. 

Tema 6: Problem 8
========================================================

b. compute $n$ such that $P(-2 \leq \bar{X}-\mu_\bar{X} \leq 2)=0.9$

- We will assume $n>30$ and then $\bar{X} \hookrightarrow N(\mu_{X}, \frac{\sigma^2_{X}}{n})$


Divide by $\sigma_{\bar{X}}$ to form a standardized variable $Z$

$P(\frac{-2}{\sigma_{\bar{X}}} \leq \frac{\bar{X}-\mu_\bar{X}}{\sigma_{\bar{X}}} \leq \frac{2}{\sigma_{\bar{X}}})=0.9$

substitute $\sigma_{\bar{X}}=\sigma_{X}/\sqrt{n}$

$P(\frac{-2}{\sigma_{X}/\sqrt{n}} \leq Z \leq \frac{2}{\sigma_{X}/\sqrt{n}})=0.9$


$\Phi(\frac{2}{\sigma_{X}/\sqrt{n}})- \Phi(\frac{-2}{\sigma_{X}/\sqrt{n}})=0.9$



Tema 6: Problem 8
========================================================

$\Phi(\frac{2}{\sigma_{X}/\sqrt{n}})- \Phi(\frac{-2}{\sigma_{X}/\sqrt{n}})=0.9$

remember $\Phi(z)=1-\Phi(-z)$

$\Phi(\frac{2}{\sigma_{X}/\sqrt{n}})-1+ \Phi(\frac{2}{\sigma_{X}/\sqrt{n}})=0.9$

$2\Phi(\frac{2}{\sigma_{X}/\sqrt{n}})-1=0.9$

$\Phi(\frac{2}{\sigma_{X}/\sqrt{n}})=0.95$

$\frac{2}{\sigma_{X}/\sqrt{n}}=\Phi^{-1}(0.95)=$<code>qnorm(0.95)</code>$=1.644854$ and solve for $n$

$n=(1.644854*16/2)^2$ or $n=174$



Tema 6: Problem 9
========================================================


Consider:

- $E(X)=\mu_{X}=3000$
- $\sigma_{X}=696$
- $n=36$

a. Compute $\mu_\bar{X}$ and $\sigma_\bar{X}$

- $E(\bar{X})=\mu_{X}=3000$
- $\sigma^2_\bar{X}=\frac{\sigma^2_{X}}{n}=\frac{696^2}{36}$ or $\sigma_\bar{X}=\sqrt{\frac{696^2}{36}}=696/6=116$

since $n>30$ then $\bar{X} \hookrightarrow N(\mu_{\bar{X}}, \sigma^2_{\bar{X}})=N(\mu_{X}, \frac{\sigma^2_{X}}{n})$



Tema 6: Problem 9
========================================================

b. compute:  $P(2670.56 \leq \bar{X} \leq 2809.76)$

standardize 

$P(2670.56 \leq \bar{X} \leq 2809.76) = P(\frac{2670.56 - \mu_{\bar{x}}}{\sigma_{\bar{X}}} \leq \frac{\bar{X} - \mu_{\bar{x}}}{\sigma_{\bar{X}}} \leq \frac{2809.76 - \mu_{\bar{x}}}{\sigma_{\bar{X}}})$
</br>$= P(-2.84 \leq Z \leq-1.64)=$<code>pnorm(-1.64)- pnorm(-2.84)</code>$=0.04824691$




Tema 6: Problem 9
========================================================

c. Find $n$ such that  $P(3219.2 \leq \bar{X})=0.01$

We 

1. standardize 
2. substitute the values of $\mu_\bar{X}=\mu_{X}$ and $\sigma_\bar{X}=\sigma_X/\sqrt{n}$
3. use the standard distribution $\Phi$

Tema 6: Problem 9
========================================================

1. standardize 

$P(\frac{3219.24-\mu_\bar{X}}{\sigma_\bar{X}} \leq \frac{\bar{X}-\mu_\bar{X}}{\sigma_\bar{X}})=0.01$


2. substitute the values of $\mu_\bar{X}=\mu_{X}$ and $\sigma_\bar{X}=\sigma_X/\sqrt{n}$

$P(\frac{3219.24-\mu_\bar{X}}{\sigma_\bar{X}} \leq \frac{\bar{X}-\mu_\bar{X}}{\sigma_\bar{X}})=0.01$


$P(\frac{219.24}{696/\sqrt{n}} \leq Z)=0.01$

3. use the standard distribution $\Phi$ since $Z \hookrightarrow N(0,1)$

$P(\frac{219.24}{696/\sqrt{n}} \leq Z)=1-\Phi(\frac{219.24}{696/\sqrt{n}})= 0.01$

solve for $n$

$\frac{219.24}{696/\sqrt{n}}=\Phi^{-1}(0.99)=$<code>qnorm(0.99)</code>$=2.32$
</br> then $n=(2.32*696/219.24)^2=54.24439$ then $n\sim 55$


Tema 6: Problem 10
========================================================



Consider:

- $E(X)=\mu_{X}=78$
- $\sigma^2_{X}=169$
- $n=36$
- $X \hookrightarrow N(\mu_{X}, \sigma_{X}^2)$

a. Compute $P(\bar{X}\leq 75.7)$


- $E(\bar{X})=\mu_{X}=78$
- $\sigma^2_\bar{X}=\frac{\sigma^2_{X}}{n}=\frac{169}{36}$ or $\sigma_\bar{X}=\sqrt{\frac{169}{36}}=13/6=2.166667$


since $X \hookrightarrow N(\mu_{X}, \sigma_{X}^2)$ then $\bar{X} \hookrightarrow N(\mu_{\bar{X}}, \sigma^2_{\bar{X}})=N(\mu_{X}, \frac{\sigma^2_{X}}{n})$




Tema 6: Problem 10
========================================================


a. Compute $P(\bar{X}\leq 75.7)$

Standardizing and using $\Phi$

$P(\frac{\bar{X}-\mu_{\bar{X}}}{\sigma_\bar{X}}\leq \frac{\bar{X}-75.7}{\sigma_\bar{X}})$


$P(Z\leq -1.06)=\Phi(-1.06)$<code>pnorm(-1.06)</code>$=0.1445723$




Tema 6: Problem 10
========================================================

b.  If $R=\sum_{i=1}^{n}X_i$, find $n$ such that  $P(R > 3200)<0.015$

divide by $n$

$P(R/n > 3200/n)=P(\bar{X} > 3200/n)<0.015$

Remember: standardize, substitute the values of $\mu_\bar{X}=\mu_{X}$ and $\sigma_\bar{X}=\sigma_X/\sqrt{n}$ and use $\Phi$

$P(\frac{\bar{X}-\mu_{\bar{X}}}{\sigma_\bar{X}} > \frac{ 3200/n-\mu_{\bar{X}}}{\sigma_\bar{X}})<0.015$


$P(Z > \frac{ 3200/n-78}{13/\sqrt{n}})<0.015$


$1-\Phi(\frac{ 3200/n-78}{13/\sqrt{n}})<0.015$

$\Phi(\frac{ 3200/n-78}{13/\sqrt{n}})>0.985$

$\frac{ 3200/n-78}{13/\sqrt{n}}=\frac{ 3200-78n}{13\sqrt{n}}>\Phi^{-1}(0.985)=$<code>qnorm(0.985)</code>$=2.17$

then

$78n + 28.21\sqrt{n}- 3200 > 0$

if $t=\sqrt{n}$ then the quadratic equation for $t$ gives the minimun $t$ at $-6.58$, $6.22$ selectinng the positive root then $t>6.22$ or $n>38.68$ or $n_{min}=39$



Tema 6: Problem 11
========================================================

Cables are built with mean traction of $80 kg$ and variance of $36 kg^2$ 


- If a sample of 9 cables are selected what is the probability that the mean traction is lower than 79?
- what should be the minimum sample size $n$ for obtaining a probability of 5\% that the average traction of the sample is lower than 79kg?

Tema 6: Problem 11
========================================================

Consider:

- $E(X)=\mu=80kg$  
- $V(X)=\sigma^2=36kg^2$  

Compute: $n$ such that $P(\bar{X}\leq 79kg)=0.05$   

For

- $P(\bar{X}\leq 79kg)$ We need $\bar{X} \rightarrow f(\bar{x})$

We know $f(\bar{x})$ when

- it is explicitly mentioned
- when the distribution $X\rightarrow N(\mu,\sigma^2)$ then $f(\bar{X})=N(\mu,\frac{\sigma^2}{n})$
- when $n>30$ then 
$f(\frac{\bar{X}-\mu}{\sigma/\sqrt{n}})\sim N(0,1)$


Tema 6: Problem 11
========================================================


We know

- $\mu_\bar{X}=80kg$  
- $\sigma_{\bar{X}}^2=36kg^2$  

what is $n$ such that $P(\bar{X}\leq 79kg)=0.05$   

- We assume that $n>30$ and the CTL approximation would be applicable


Tema 6: Problem 11
========================================================

Let's standardize

$Z=\frac{\bar{X}-\mu}{\sigma/\sqrt{n}}= \frac{\bar{X}-80}{6/\sqrt{n}} \rightarrow N(0,1)$

$P(\bar{X}\leq 79kg)= P(\frac{\bar{X}-80}{6/\sqrt{n}}\leq \frac{79-80}{6/\sqrt{n}})$

$=P(Z\leq -0.16667\sqrt{n})$

$=\Phi(-0.16667\sqrt{n}) =0.05=$<code>qnorm(0.05)</code>$=-0.16667$

and then $\sqrt{n}=1.645/0.16667$ or $n\sim 97$, which$>>30$



Tema 6: Problem 11
========================================================

consider: 

- $\bar{X}\rightarrow N(\mu_{\bar{X}},\sigma_{\bar{X}}^2)=N(\mu_{X},\sigma_{X}^2/n)$
- $n=9$
- $\sigma_{X}^2=36$

b. find $\mu$ such that $P(\bar{X}\leq 79)=0.05$ it would the minimum value it can take.

let's standardize

$P(\bar{X}\leq 79)= P(\frac{\bar{X}-\mu_{\bar{X}}}{\sigma_{\bar{X}}} \leq \frac{\bar{79}-\mu_{\bar{X}}}{\sigma_{\bar{X}}}$
</br>$=P(Z\leq \frac{79-\mu}{6/\sqrt{9}})$
</br>$=\Phi(\frac{79-\mu}{6/\sqrt{9}}) =0.05=$<code>qnorm(0.05)</code>$=-1.644854$


$\frac{79-\mu}{6/\sqrt{9}}=-1.645$

the minimum $\mu$ is $82.29$ so or $\mu>82.29$



Tema 6: Problem 12
========================================================


Consider:

- $E(X)=\mu_{X}=75$
- $\sigma_{X}=15$
- $n=25$
- $X \hookrightarrow N(\mu_{X}, \sigma_{X}^2)$

a. Compute $P(|\bar{X}-\mu_X|\leq 5)$

- $E(\bar{X})=\mu_{X}=75$
- $\sigma^2_\bar{X}=\frac{\sigma^2_{X}}{n}=\frac{15^2}{25}$ or $\sigma_\bar{X}=\sqrt{\frac{15^2}{25}}=15/5=3$


since $X \hookrightarrow N(\mu_{X}, \sigma_{X}^2)$ then $\bar{X} \hookrightarrow N(\mu_{\bar{X}}, \sigma^2_{\bar{X}})=N(\mu_{X}, \frac{\sigma^2_{X}}{n})$



Tema 6: Problem 12
========================================================

devide by $\sigma_{\bar{X}}$ to form standardized variable

$P(\frac{-5}{3} \leq \frac{\bar{X}-75}{3}\leq \frac{5}{3})=P(\frac{-5}{3} \leq Z \leq \frac{5}{3})$
 
 Use $\Phi$
 
- $\Phi(\frac{5}{3}) -\Phi(\frac{5}{3})=$<code>pnorm(5/3)-pnorm(-5/3)</code>$=0.9044193$

compute $P(|\bar{X}-\mu_X|\leq 5)$ if $n=100$ then $\sigma_\bar{X}=\sqrt{\frac{15^2}{100}}=15/10=3/2$

then

$P(\frac{-5}{3/2} \leq \frac{\bar{X}-75}{3/2}\leq \frac{5}{3})=P(\frac{-5}{3/2} \leq Z \leq \frac{5}{3/2})$

- $\Phi(\frac{10}{3}) -\Phi(\frac{10}{3})=$<code>pnorm(10/3)-pnorm(-10/3)</code>$=0.9991419$

as $n$ increases the probability increases.



Tema 6: Problem 12
========================================================

b. 

consider
- $n=9$

compute: $C$ such that $P(\bar{X}>C)= 0.015$

or 

$P(\bar{X} \leq C)= 1-0.01=0.985$

Remember: standardize, substitute the values of $\mu_\bar{X}=\mu_{X}$ and $\sigma_\bar{X}=\sigma_X/\sqrt{n}=15/3=5$ and use $\Phi$

$P(\frac{\bar{X}-75)}{5} < \frac{C-75)}{5})=0.985$

$P(Z < \frac{C-75)}{5})=0.985$

$\Phi(\frac{C-75)}{5})=0.985$

$\frac{C-75)}{5})=\Phi^{-1}(0.985)=$<code>qnorm(0.985)</code>$=2.17009$

solving for $C$ then $C=2.17009*5+75=85.85045$

