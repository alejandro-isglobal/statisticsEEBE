Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 4</p>


Objective
========================================================

- Random variables
- Probability mass function
- Mean, variance, and moments of random variables
- Cumulative probability distribution

Probability
========================================================

<img src="./figures/eqprob.JPG" style="width:75%"  align="center">



Probability
====================================================

How do we assign values to the probability function?


**Classical Interpretation:**

Whenever a sample space consists of N possible events that are equally likely, the probability of each outcome is $\frac{1}{N}$.


Note that this is purely on the model space. The intention is to make the probability a purely abstract (mathematical) quantity. It is to us to interpret what it means **equally likely**.



Probability
====================================================

Consider the toss of a coin.

- sample space: {H,T}, or {0,1} if we assign 0:H and 1:T.
- From design, before we throw a particular coin, there is no **reason** to think that one outcome is more likely than the other. 

then:
- $P(0)=\frac{1}{2}$
- $P(1)=\frac{1}{2}$

The same is true for a dice $P(i)=1/6$ and for the Christmas lottery $P(i)=\frac{1}{N tickets}$.

Probability
====================================================
If we define the function $X$ on the sample space according to the assignment

X:{H,T} $\rightarrow$ {0,1}

then 
- $P(X=0)=\frac{1}{2}$
- $P(X=1)=\frac{1}{2}$

We call $X$ a **random variable**

Probability
====================================================

How can you have unequal probabilities?

- let's look at the dice again and imagine you need to throw a 6 to win aparchís game. 

- your probability of winning in the next throw is $P(6)=1/6$
- your probability of not winning in the next throw is $P(E=1\cap 2\cap 3\cap 4\cap 5)=5/6$

Note that we do not need (or cannot) to run the experiment many times. 


Probability
====================================================

Let´s define the random variable 

X:{1 $\cap$ 2 $\cap$ 3 $\cap$ 4 $\cap$ 5, **6**} $\rightarrow$ {0,1}

Then 
- $P(X=0)=\frac{5}{6}$
- $P(X=1)=\frac{1}{6}$

These are also the probabilities for the toss of an unbalanced coin.



Random variable
====================================================

**Definition:**

A random variable is a function that assigns a real number to each outcome in the sample space of a random experiment.


- Most commonly a random variable is the numerical **measurement** of interest that is made in a random experiment. 



Measurement
====================================================

**Definition:**

The process of measurement is the assignment of a number to a characteristic of an object or event so that it can be compared with other objects or events.

Properties:

- type: nominal (male/female), ordinal (1st, 2nd, .. 3rd), interval (distance), and ratios (length)
- magnitude: a numerical value produced by an instrument 
- unit: a universal reference to which comparison (measurements) are made
-  **uncertainty**: errors in the measurement process

Measurement
====================================================

The outcome of a measuring process is not always the same -random variable


A random variable can be:
- Discrete (nominal, ordinal)
- Continuous (interval, ratio) 


Discrete random variable
====================================================

We showed how a value of random variables represents an event of the experiment that is composed of sets of primary (perhaps unobserved) outcomes each with equal probability for the experiment to be at.   

Extreme example:

- in physics, we call these primary events, micro-states. A Micro-state is one in which we know all positions and velocities of all the atoms in a gas.

- the temperature of a gas in equillibrium with the environment is a **random variable** and a value of 20 degrees is an event of the gas that corresponds to many micro-states. The temperature is the average kinetic energy.


Discrete random variable
====================================================

How do work from measurements to the probability function of the random variable it represents?

- In the example above this is done in a whole theoretical framework called statistical mechanics.


Let's consider a much simpler example:

Imagine we want to measure how noisy the transmission of bits between two computers is. If were to transmit 100 bits in a noisy channel, what should be the probability of transmitting 1, 2, 3, ... 100 errors?

Discrete random variable
====================================================

One bit sample space: {correct, error} each equally probable

100 bit joint sample space:

$\{correct|correct|...|correct|correct,$ $\,correct|correct|...|correct|error,$ $\,correct|correct|...|error|error,$ .... $\,error|error|error|...|error\}$

For each bit, there are two possible outcomes, for 100 bits there are
$n=2\times 2 \times ... \times 2= 2^{100}$
primary events.



Discrete random variable
====================================================

Number of bits with errors in  **any** outcome

Sample space for 100 bits:

$\{correct|correct|...|correct|correct:$**0**, 
$\,correct|correct|...|correct|error:$**1**,
$\,correct|correct|...|error|correct:$**1**, 
....
$\,correct|correct|...|error|error:$**2**, 
.... 
$\,error|error|error|...|error:$**100**}


Discrete random variable
====================================================

Number of bits with errors in **any** outcome is a random variable X


X is a random variable such that $X \in {0,1,2,..100}$

Note the values of X are mapped to a different number of outcomes (some values of X are more have more micro-events than others and therefore will be more probable)


Probability mass function
====================================================


Let's look in detail at a 5-bit transmission.

- What is the probability of transmitting $X$ number of errors in a 5-bit transmission of a totally noisy channel?



Probability mass function
====================================================

Sample space for 5 bits:
</br>$\{0|0|0|0|0$:**0**,
</br>$\{0|0|0|0|1$:**1**,
</br>$\{0|0|0|1|0$:**1**,
</br>...
</br>$\{0|0|0|1|1$:**2**,
</br>...
</br>$1|1|1|1|1$:**5**,

how many primary events for X=0,1,2,3,4,5? 


Probability mass function
====================================================

It is like selecting groups of size $x$ sets from a set of $n$ 

- X=0 appears as the number of subsets of size 0 ($n_0 = 1$) from a set of 5 elements 
- X=1 appears as number of subsets of size 1 ($n_1 = 5$)
- X=x appears as number of subsets of size x ($n_x = \binom 5 x$)

$X$ capital is the variable, $x$ script size is an observed/realized value of $X$

Note that  $\sum_{x=0}^5 \binom 5 x = 2^5$ is the size of the sample space



Binomial coeficient
====================================================


The binomial coeficient between two numbers $n$ and $k$ is defined as

$\binom n k =\frac{n!}{k!(n-k)!}$

where the factorial $!$ on a number $r$ is defined as $r!=1*2*3*...(r-1)*r$

- the binomial coeficient give the coeficients of the expansion

$(x+y)^n=\sum_{i=0}^n\binom n k x^{n-k}y^k$

- they give the number of subsets of size $k$ that can be made with a set of size $n$ ($k$ number in row $n$ of Pascal's triangle)

Probability mass function
====================================================

Number of micro-events for each value of the random variable

| 0 | 1 | 2 | 3  | 4 | 5 | total |
| --------- | ---------  | ---------  | ---------   | ---------  |---------  | --------- |
| $n_0$ | $n_1$ | $n_2$ | $n_3$  | $n_4$ | $n_5$ | $n_{\cdot}$ |

Since each micro event is equally likely then the 
probability table is each number divided by $n_{\cdot}=2^5$

| 0 | 1 | 2 | 3  | 4 | 5 | total |
| --------- | ---------  | ---------  | ---------   | ---------  |---------  | --------- |
|  1/32 | 5/32 |  10/32 | 10/32  | 5/32 |  1/32 | 1 |

(*Pascal triangle*)

Note: this is not the result of an experiment! it's the result of our assumptions


Probability mass function
====================================================

Therefore the probability for each value of the random variable $X$ is
</br>$P(X=0)=1/32$ 
</br>$P(X=1)=5/32$
</br>$P(X=2)=10/32$
</br>$P(X=3)=10/32$
</br>$P(X=4)=5/32$
</br>$P(X=5)=1/32$

The function defined by $f(x_i)=P(X=x_i)$ is called the **probability mass function of X**


Probability mass function
====================================================


**Definition:**

For a discrete random variable X with possible values $x_1 , x_2 , .. , x_m$ , a probability
mass function is a function such that

- $f(x_i)\geq 0$
- $\sum_{i=1}^m f(x_i)=1$  
- $f(x_i)=P(X=x_i)$


Probability mass function
========================================================

![plot of chunk unnamed-chunk-1](Lecture4-figure/unnamed-chunk-1-1.png)


Probability mass function
========================================================

- We have shown how to assign a probability mass function to a variable $X$ that is the result of a given experiment. 

- Note that the definition of $X$ and its probability mass function is general without reference to any experiment. The functions live in the model space. 

- $X$ and $f(x)$ are abstract objects that may or may not map to an experiment

- We have the freedom to construct them as we want as long as we respect their definition.

- They have some properties that are derived exclusively from their definition. 


Probability mass function
========================================================

Example:

Consider the following random variable $X$ over the outcomes 

| outcome | a | b | c | d  | e | f | 
| --------- | --------- | ---------  | ---------  | ---------   | ---------  |---------  | 
| X | 0 | 0 | 1.5 | 1.5  | 2 | 3 | 


If each outcome is equally likely (primary events) then what is the probability mass function of $x$?


Probability mass function
========================================================

$f(0)=P(X=0)=2/6$
</br>$f(1.5)=P(X=1.5)=2/6$
</br>$f(2)=P(X=2)=1/3$
</br>$f(3)=P(X=3)=1/3$

We can compute, for instance, the following probabilities for the values of X

- $P(X>3)$
- $P(X=0\, \cup \, X=2 )$ 
- $P(X \leq 2)$

Probability mass function
========================================================

Or consider we do not care what the primary events are but have a direct definition of the probability mass function

|X | -2 | -1 | 0 | 1  | 2 | 
| --------- | --------- | ---------  | ---------  | ---------   | ---------  | 
| f(x) | 1/8 | 2/8 | 2/8  | 2/8 | 1/8 | 

We can still compute the probabilities on the values of $X$
</br>$P(X\leq 2)$
</br>$P(-1\leq X \cap X\leq 1)$
</br>$P(X>2)$
</br>$P(X\leq -1 \, \cup  \,X=2)$



Mean and variance
========================================================

The probability mass functions have two main properties

- its center 
- its spread 

We can ask,

- around which values of $X$ the probability concentrated?

- How dispersed are the values of $X$ in relation to their probabilities.


Mean and variance
========================================================

<img src="./figures/mean.JPG" style="width:75%"  align="center">

Mean and variance
========================================================

Let's take the frequentist perspective and remember that when we talked about data

- Let's remember that the average in terms of the frequencies of the values of $x_i$ (outcomes) 


$$\bar{x}= \sum_{i=1..m} x_i \frac{n_i}{n}$$

was the center of gravity of the observations, and $m$ is the possible number of outcomes for $x_i$ and $n$ the total amount of observations. 

What would be the center of gravity for $P(X=x_i)$ ($n \rightarrow \infty$)?


Mean and variance
========================================================

**Definition**

The mean ($\mu$) or expected value of a discrete random variable X ($E(X)$) with mass function $f(x)$ is given by 

$$ \mu = E(X)= \sum_{i=1}^m x_i f(x_i) $$


Mean and variance
========================================================

<img src="./figures/mu.png" style="width:75%"  align="center">

It is the center of gravity of the probabilities: The point where probability loadings on a road are balanced


Mean and variance
========================================================


What is the mean of X if its probability mass function f(x) is given by

$P(X=0)=1/32$ 
</br>$P(X=1)=5/32$
</br>$P(X=2)=10/32$
</br>$P(X=3)=10/32$
</br>$P(X=4)=5/32$
</br>$P(X=5)=1/32$

E(X)=**0** 1/32 + **1** 5/32 + **2** 10/32 + **3** 10/32 + **4** 5/32 + **5** 1/32 = 2.5


Mean and variance
========================================================


![plot of chunk unnamed-chunk-2](Lecture4-figure/unnamed-chunk-2-1.png)

Mean and variance
========================================================

In similar terms we define the mean squared distance from the mean:

**Definition**

The variance, written as $\sigma^2$ or $V(X)$, of a discrete random variable X with mass function $f(x)$ is given by 

$$ \sigma^2 = V(X)= \sum_{i=1}^m (x_i-\mu)^2 f(x_i) $$

- $\sigma$ is called the standard deviation of the distribution

- Think of it as the moment of inertia about the mean.


Mean and variance
========================================================


What is the variance X of if its probability mass function f(x) is given by?

$P(X=0)=1/32$ 
</br>$P(X=1)=5/32$
</br>$P(X=2)=10/32$
</br>$P(X=3)=10/32$
</br>$P(X=4)=5/32$
</br>$P(X=5)=1/32$


Mean and variance
========================================================

Var(X)=**(0-2.5)**$^2$ 1/32 + **(1-2.5)**$^2$ 5/32 + **(2-2.5)**$^2$ 10/32 + **(3-2.5)**$^2$ 10/32 + **(4-2.5)**$^2$ 5/32 + **(5-2.5)**$^2$ 1/32 = 1.25


$$Var(X)=\sigma^2=1.25$$
$$\sigma=1.11$$


Functions of X
========================================================

**Definition**

For any function $h$ of a random variable X, with mass function $f(x)$, its expected value is given by

$$ E[h(X)]= \sum_{i=1}^m h(x_i) f(x_i) $$


Think of it as the inner product between the functions $h$ and $f$ on the sample space.



The mean is linear
========================================================

**Property**

The **expected value** (mean) of a discrete random variable $Y=a\times X +b$ satisfies

$E(Y)=\mu_Y$
</br>$=E(a\times X +b)=\sum_{i=1}^m [a\times x_i +b] f(x_i)= a\times E(X) +b$

for $a$ and $b$ scalars (numbers).




The variance is not linear
========================================================

The **variance** of a discrete random variable $Y=a\times X +b$ satisfies

$V(Y)=V(a\times X +b)$
</br>$= \sum_{i=1}^m ( y_i-\mu_Y)^2 f(x_i)$
</br>$=  \sum_{i=1}^m ( a\times x_i +b -a\times E(X) -b)^2 f(x_i)$
</br>$=  \sum_{i=1}^m a^2\times(x_i  - E(X) )^2 f(x_i)$
</br>$=  a^2 \times \sum_{i=1}^m (  x_i  - E(X) )^2 f(x_i)$
</br>$=  a^2 V(X)$

for $a$ and $b$ scalars -second step is because $E$ is linear




Moments of a random variable
========================================================

**Property**

The variance of a discrete random variable $X$ satisfies

$V(X)=\sum_{i=1}^m (x_i-\mu)^2 f(x_i)$
</br>$=\sum_{i=1}^m (x_i^2-2x_i\mu+\mu^2) f(x_i)$
</br>$=\sum_{i=1}^m x_i^2 f(x_i) -2\mu \sum_{i=1}^m x_i f(x_i)  + \mu^2$
</br>$=\sum_{i=1}^m x_i^2 f(x_i) -2\mu^2 + \mu^2$
</br>$=\sum_{i=1}^m x_i^2 f(x_i) -\mu^2$ 

Moments of a random variable
========================================================
**Property**

The variance can also be written as

$V(X)=\sum_{i=1}^m (x_i-\mu)^2 f(x_i) =\sum_{i=1}^m x_i^2 f(x_i) -\mu^2$

The variance is the moment of inertia about the center of mass (mean)




Moments of a random variable
========================================================

Let's generalize the mean and variance

What is the expected value of the function $X^r$?

$$E(X^r)=\mu'_r=\sum_{i=1}^m x_i^r f(x_i) $$

$\mu'_r$ is called the $r$-moment of X about the origin.


Moments of a random variable
========================================================

$E(X^r)=\mu'_r=\sum_{i=1}^m x_i^r f(x_i)$

- when $r=1$ we have the mean
$E(X)=\mu=\mu'_1=\sum_{i=1}^m x_i f(x_i)$

- when $r=2$ we have something similar to the variance
$E(X^2)=\mu'_2=\sum_{i=1}^m x_i^2 f(x_i)$

- the mean square distance from  $x=0$ (not from $\mu$!)

$\mu'_r$ are the $r$-moment of X with respect to the **origin**.


Moments of a random variable
========================================================

The expected value of $(X-\mu)^r$

$E[(X-\mu)^r]=\mu_r=\sum_{i=1}^m (x_i-\mu)^r f(x_i)$

is called the $\mu_r$ are the $r$-moment of X about **the mean**.

so the second moment about the mean is the variance 

$\mu_2=V(X)=\sigma^2$

Moments of a random variable
========================================================

How $\mu'_r$ and $\mu_r$ relate?

$E[(X)^r]=\mu'_r=\sum_{i=1}^m (x_i-\mu+\mu)^r f(x_i)$ 
</br>$=\sum_{i=1}^m \sum_{j=0}^r \binom r j \mu^{r-j}(x_i-\mu)^j f(x_i)$
</br>$=\sum_{j=0}^r \binom r j \mu^{r-j} \sum_{i=1}^m (x_i-\mu)^j f(x_i)$
</br>$=\sum_{j=0}^r \binom r j \mu^{r-j} \mu_{j}$

for $r=2$
</br>$\mu'_2= \binom 2 0 \mu^2 \mu_0 + \binom 2 1 \mu \mu_1 + \binom 2 2 \mu_2$
</br>$=1*\mu^2*1+2*\mu*0+ 1*\mu_2=\mu^2 + \mu_2$

Moments of a random variable
========================================================

when $r=2$ we have  $\mu'_2 = \mu^2+\mu_2  =\mu^2 +\sigma^2$ 

$$ V(X)= \mu'_2 - \mu^2$$

or

$$ V(X)= E(X^2) - \mu^2$$

This is a very useful formula to compute the variance since it is often easier to compute $E(X^2)$ then $E[(X-\mu)^2]$

Cumulative probability distribution
====================================================

Let's remember that for observations (DATA) we defined the cumulative relative frequency. 

$$F_i=\sum_{k=1..i} \frac{n_k}{n}$$

Therefore, according to the frequentist interpretation, we also have the equivalent cumulative function


Cumulative probability distribution
====================================================

**Definition:**

The cumulative distribution function is defined as 

$$F(x)=P(X\leq x) $$

That is the accumulated probability up to a given value $x$


Cumulative probability distribution
====================================================


Let's look at our noisy channel transmission. The probability mass function is given by $f(x)=P(X=x)$

$f(0)=P(X=0)=1/32$ 
</br>$f(1)=P(X=1)=5/32$
</br>$f(2)=P(X=2)=10/32$
</br>$f(3)=P(X=3)=10/32$
</br>$f(4)=P(X=4)=5/32$
</br>$f(5)=P(X=5)=1/32$

Cumulative probability distribution
====================================================

What is the probability of obtaining at most three errors (X=3)

$F(3)=P(X\leq 3)$ 
</br>$= P(X=0)+P(X=1)+P(X=2)+P(X=3)=26/32$

Cumulative probability distribution
====================================================

The cumulative distribution function is then given by 

$F(3) =P(X\leq 3) = f(0)+f(1)+f(2)+f(3)$
</br>$=\sum_{x_i\leq 3} f(x_i)$

in terms of the probability mass function

Cumulative probability distribution
====================================================

For discrete random variables then the cumulative function distribution is defined as

$$F(x)=\sum_{x_i\leq x} f(x_i)$$

The accumulation of mass probability up to $x$


Cumulative probability distribution
====================================================

Compute the **cumulative function distribution** of the following probability mass function: 
</br>$f(0)=1/32$, $f(1)=5/32$, $f(2)=10/32$, $f(3)=10/32$, $f(4)=5/32$, $f(5)=1/32$

Let's compute specific points
</br>$F(0)=1/32$ 
</br>$F(1)=6/32$
</br>$F(2)=16/32$
</br>$F(3)=26/32$
</br>$F(4)=31/32$
</br>$F(5)=32/32$

Cumulative probability distribution
====================================================

$F(0)=1/32$, $F(1)=6/32$, $F(2)=16/32$, $F(3)=26/32$, $F(4)=31/32$, $F(5)=32/32$

For $X \in \mathbb{Z}$
\[
    F(x)= 
\begin{cases}
    1/32,& \text{if } x < 1\\
    6/32,& 1\leq x < 2\\
    16/32,& 2\leq x < 3\\
    26/32,& 3\leq x < 4\\
    31/32,& 4\leq x < 5\\
    32/32,& 5\leq x \\
\end{cases}
\]


Cumulative probability distribution
====================================================

![plot of chunk unnamed-chunk-3](Lecture4-figure/unnamed-chunk-3-1.png)


Cumulative probability distribution
====================================================


$F(x)$ satisfies:

- $0\leq F(x) \leq 1$
- If $x \leq y$, then $F(x) \leq F(y)$



Cumulative probability distribution
====================================================

Compute the mass probability function of the following cumulative probability distribution: 
</br>$F(0)=1/32$, $F(1)=6/32$, $F(2)=16/32$, $F(3)=26/32$, $F(4)=31/32$, $F(5)=32/32$

Let's work backwards.
</br>$f(0)=F(0)=1/32$ 
</br>$f(1)=F(1)-f(0)=6/32-1/32=5/32$ 
</br>$f(2)=F(2)-f(1)-f(0)=F(2)-F(1)=10/32$ 
</br>$f(3)=F(3)-f(2)-f(1)-f(0)=F(3)-F(2)=10/32$ 
</br>$f(4)=F(4)-F(3)=5/32$ 
</br>$f(5)=F(5)-F(4)=1/32$ 




Cumulative probability distribution
====================================================


The Cumulative probability distribution is another way to specify the probability of a random variable

$$f(x_i)=F(x_i)-F(x_{i-1})$$

with

$$f(x_1)=F(x_1)$$


for X taking values in $x_1 \leq x_2 \leq ... \leq x_n$


Summary
====================================================

| quantity | model | data |
| -------- | ----- | ---- |
| probability mass function/relative frecuency         |  $P(X=x_i)=f(x_i)$ | $f_i=\frac{n_i}{n}$ |
| cumulative probability function/cumulative relative frequency          |  $F(x_i)=P(X \leq x_i)$ | $F_i=\sum_{j\leq j} f_i$   |
| mean/average (1st-moment about the origin) | $\mu$, $\mu'_1$, $E(X)=\sum_{i(outcome)} x_i f(x_i)$ | $\bar{x}=\sum_{j(observation)} x_j/n$ |   
| variance (2nd-moment about the mean) |$\sigma^2$, $\mu_2$, $V(X)=\sum_i (x_i-\mu)^2 f(x_i)$ | $s^2=\sum_j (x_j-\bar{x})^2/(n-1)$ |   
| standard deviation | $\sigma$, $\sqrt{V(X)}$ | $s$ |
| 2nd-moment about the origin | $\mu'_2$,$E(X^2)=\sum_i (x_i)^2 f(x_i)$ | $M'_2= \sum_j x_j^2/n$|

Summary
====================================================

- $V(x)=E(X^2)-\mu^2$
- $E(X^r)=\mu'_r$ r-moment about the **origin**
- $E((X-\mu)^r)=\mu_r$ r-moment about the **mean**
