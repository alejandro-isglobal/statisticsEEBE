Introduction to statistics 
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 10</p>


Objective
========================================================

- Interval estimation definition  
- Confidence intervals for a normal random sample with known variance 

Interval estimation
========================================================

We usually start by performing a random experiment $n$ times

![plot of chunk unnamed-chunk-1](Lecture10-figure/unnamed-chunk-1-1.png)

Interval estimation
========================================================

We assume that the random experiment follows a distribution $X \hookrightarrow f(X; \theta)$. But which one is it? which parameter $\theta$ ($\mu$ in the case of $N(\mu, \sigma)$) should we choose?

![plot of chunk unnamed-chunk-2](Lecture10-figure/unnamed-chunk-2-1.png)




Interval estimation
========================================================


When we propose a probability model for the random variable $X \hookrightarrow f(X; \theta)$ 

- We can use **maximum likelihood** or the **method of moments** to  propose estimators $\Theta$ for the parameter $\theta$.

- Estimators are random variables that represent the random experiment of repeating the experiment of $X$ $n$ times and combine the results to compute the estimate $\hat{\theta}$.

- The estimate $\hat{\theta}$ is obtained from the data and is one observed value from the random experiment that measures the estimator $\Theta$. 

Interval estimation
========================================================

Maximum likelihood and the method of moments tell us that to estimate $\mu$ we **can** choose $\bar{x}$, which is the observation of the random variable $\bar{X}$

![plot of chunk unnamed-chunk-3](Lecture10-figure/unnamed-chunk-3-1.png)



Interval estimation
========================================================

How **confident** are we that $\bar{x}$ is close to the **real** $\mu$? 

If we repeat the $n$-experiments many times we will get a different answer for $\bar{x}$ each time because $\bar{X}$ is a random variable. 

![plot of chunk unnamed-chunk-4](Lecture10-figure/unnamed-chunk-4-1.png)



Interval estimation
========================================================

Each value of $\bar{x}$ infers a different distribution of $X$

![plot of chunk unnamed-chunk-5](Lecture10-figure/unnamed-chunk-5-1.png)



Interval estimation
========================================================

We usually have only one value of $\bar{x}$ or repeat the experiment $n$ times only. 

![plot of chunk unnamed-chunk-6](Lecture10-figure/unnamed-chunk-6-1.png)



Interval estimation
========================================================


Let's consider the case of the mean $\mu$: When we estimate $\mu \sim \bar{x}$ ($\hat{\mu} = \bar{x}$)

- We don't know how close we are from the true but unknown value of $\mu$.

- To know how far $\bar{x}$ can fall from $\mu$, we define the limits $(f_{inf}, f_{sup})$ such that we have a $95\%$ probability that the difference between $\bar{x}$ and $\mu$ is between these numbers.  


We want to identify the inter-95% range of $\bar{X}$ about the the mean $\mu$.

Interval estimation
========================================================

Let's write it as:

$P(f_{inf} \leq \bar{X} - \mu \leq  f_{sup} )=0.95$

$P(\bar{X} - f_{sup} \leq \mu \leq \bar{X} - f_{inf} )=0.95$

and define the **random interval** 

$(L,U)$ such that $P(L \leq  \mu \leq  U )=0.95$. 

When the interval captures the **distance** $(\bar{X}-\mu)$ to the parameter then   

$(L,U)=(\bar{X} - f_{sup},\bar{X} - f_{inf})$

This interval is a **random variable** and it has by definition a probability of $0.95$ to contain $\mu$. 



Interval estimation
========================================================

When we perform $n$-random experiments ($n$-sample) we can calculate  $f_{inf}$ y $f_{sup}$. 


- the interval that we obtain from the experiment is

$(l,u)=(\bar{x} - f_{sup},\bar{x} - f_{inf})$ (script size)

- this interval either contains or not the parameter $\mu$: we will **never know**! 

- We say that we have a confidence of $95\%$ that the interval $(l,u)$ will capture the true unknown parameter $\mu$. Think of buying a lottery ticked for which you do not know the result. 

Interval estimation
========================================================
Let's consider the probability

$P(f_{inf} \leq \bar{X} - \mu \leq  f_{sup} )=0.95$

and divide by  $\sigma_{\bar{X}}$

$P( \frac{f_{inf}}{\sigma_{\bar{X}}} \leq \frac{\bar{X}-\mu}{\sigma_{\bar{X}}} \leq  \frac{f_{sup}}{\sigma_{\bar{X}}} )=0.95$

Let's substitute by $\sigma_{\bar{X}}=\sigma_{X}/\sqrt{n}$. 


We then need to solve: $P( \frac{f_{inf}}{\sigma_{X}/\sqrt{n}} \leq \frac{\bar{X}-\mu}{\sigma_{X}/\sqrt{n}} \leq  \frac{f_{sup}}{\sigma_{X}/\sqrt{n}} )=0.95$
for $f_{inf}$ and $f_{sup}$. 


Interval estimation
========================================================
We are going to assume two conditions:

1. that $X \hookrightarrow N(\mu, \sigma^2_X)$. 

2. that we **know** $\sigma_{X}$ as additional information.

If 1 y 2 are true **then** we can show that $Z=\frac{\bar{X}-\mu}{\sigma_{X}/\sqrt{n}}$ distributes normally $Z \hookrightarrow N(\mu=0, \sigma^2=1)$ 

- We can use $\Phi^{-1}$ (inverse of the cumulative standard distribution standard ) to find  $f_{inf}$ and $f_{sup}$.


Interval estimation
========================================================

If we define $z_{0.025}$ and $z_{0.975}$ as the numbers of the standard distribution that capture the 95% of the distribution about the median:

$\Phi^{-1}(0.025)=z_{0.975}$ and $\Phi^{-1}(0.975)=z_{0.025}$


<img src="./figures/norm.JPG" style="width:50%"  align="center">


Interval estimation
========================================================


then comparing $P( z_{0.975} \leq Z \leq  z_{0.025} )=0.95$
with  $P( \frac{f_{inf}}{\sigma_{X}/\sqrt{n}} \leq \frac{\bar{X}-\mu}{\sigma_{X}/\sqrt{n}} \leq  \frac{f_{sup}}{\sigma_{X}/\sqrt{n}} )=0.95$




we have:
</br>$f_{inf}=z_{0.925}*\sigma_{X}/\sqrt{n}$
</br>$f_{sup}=z_{0.025}*\sigma_{X}/\sqrt{n}$

Interval estimation
========================================================


In R we can compute this numbers with the function  *qnorm*=$\Phi^{-1}$

```r
z0.975 <- qnorm(0.025)
z0.975
```

```
[1] -1.959964
```

```r
z0.025 <- qnorm(0.975)
z0.025 
```

```
[1] 1.959964
```


Interval estimation
========================================================

For a randon variable $X$ that distributes normally $X \hookrightarrow N(\mu, \sigma^2_X)$ with know variance $\sigma^2_X$, the $95%$ random interval is

$(L,U) = (\bar{X} - f_{sup},\bar{X} - f_{inf})= (\bar{X} - 1.96\sigma_{X}/\sqrt{n},\bar{X} + 1.96 \sigma_{X}/\sqrt{n})$

and the **observed** $95\%$ confidence interval is  

$(l,u) = (\bar{x} - 1.96\sigma_{X}/\sqrt{n},\bar{x} + 1.96\sigma_{X}/\sqrt{n})$

We also write that the estimate of the mean $\mu_X$

$\hat{\mu}_X=\bar{x} \pm 1.96\sigma_{X}/\sqrt{n}$

And so we separate signal from error! 

note: probability is in $X$, signal in $E(\bar{X})$ and error in $V(\bar{X})$.


Interval estimation
========================================================
For a sample of 8 observations, we have one estimate of the mean and one confidence interval

![plot of chunk unnamed-chunk-8](Lecture10-figure/unnamed-chunk-8-1.png)



Interval estimation
========================================================
Every time that we obtain a new sample then the estimates change. If we perform 100 samples then $95%$ of the confidence intervals will contain $\mu$ (we do not know which!)

![plot of chunk unnamed-chunk-9](Lecture10-figure/unnamed-chunk-9-1.png)


Interval estimation
========================================================

From the estimator distribution of $\Theta$ we define a **confidence limit** $\alpha$ such that the probability that the **random interval** $(L,U)$ contains the parameter $\theta$ is $(1-\alpha)$.  

$P(L \leq \theta \leq U)=P(\Theta -f_{\alpha/2} \leq \theta \leq \Theta - f_{1-\alpha/2})=1-\alpha$

<img src="./figures/alpha2.JPG" style="width:50%"  align="center">


Interval estimation
========================================================

If the $95\%$ confidence interval at confidence limit of $0.05%$ (the amount of probability that is left out) for $X \hookrightarrow N(\mu, \sigma_X)$ and known $\sigma_X$ is

$(l,u) = (\bar{x} - z_{0.025}\sigma_{X}/\sqrt{n},\bar{x} - z_{0.975}\sigma_{X}/\sqrt{n})$

then the $99\%$ confidence interval at confidence limit $0.01$ is 

$(l,u) = (\bar{x} - z_{0.005}\sigma_{X}/\sqrt{n},\bar{x} - z_{0.995}\sigma_{X}/\sqrt{n})$

$= (\bar{x} - 2.57\sigma_{X}/\sqrt{n},\bar{x} + 2.57\sigma_{X}/\sqrt{n})$

or

$\hat{\mu}_X=\bar{x} \pm 2.57\sigma_{X}/\sqrt{n}$

If we want to be more confident then we need larger confidence intervals!



Interval estimation
========================================================
You can remember $z_{0.025}=\Phi^{-1}(0.975)=1.96$ or $z_{0.005}=\Phi^{-1}(0.995)=2.57$ if not, use R or look it up on a table.

<img src="./figures/tab.PNG" style="width:50%"  align="center">

Interval estimation
========================================================

Confidence intervals are highly misunderstood!

- A confidence interval is one outcome of a random process
- when we obtain a CI we do not know whether it contains the parameter!
- $1-\alpha$ percent of the times CI intervals contain the parameter
- CI are not probabilities of observing the parameter.

For one set of measurements, we just get a box with a confidence level that contains the parameter ... but we can never look inside!


Interval estimation for the mean
========================================================

A metallic material is tested for impact to measure the energy required to cut it at a given temperature.

- Ten specimens of A238 steel were cut at 60ºC at the following impact energies (J)

- 64.1, 64.7, 64.5, 64.6, 64.5, 64.3, 64.6, 64.8, 64.2, 64.3

- If we know that the impact energy is randomly distributed with $\sigma=1J$ what is the $95\%$ CI for the mean of these data? 

Interval estimation for the mean
========================================================

We know

- $x_i=\{64.1, 64.7, 64.5, 64.6, 64.5, 64.3, 64.6, 64.8, 64.2, 64.3\}$
- $X \rightarrow N(\mu, \sigma^2)$
- $\sigma=1J$
- $\alpha=0.05$

The confidence interval is then 

$CI=(\bar{x}-1.96 \frac{\sigma}{\sqrt{n}}, \bar{x}+1.96  \frac{\sigma}{\sqrt{n}})$
</br>$=(64.46-1.96 \frac{1}{\sqrt{10}}, 64.46+1.96  \frac{1}{\sqrt{10}})=(63.84,65.08)$

or

$\hat{\mu}=64.46 \pm 0.61$ it tells us that we can be sure on the first digit (6), somewhat confident on the second (4) and unsure on the decimals (46).

Interval estimation for the mean
========================================================


What is the confidence interval at $1\%$ confidence limit?

We know

- $x_i=\{64.1, 64.7, 64.5, 64.6, 64.5, 64.3, 64.6, 64.8, 64.2, 64.3\}$
- $X \rightarrow N(\mu, \sigma^2)$
- $\sigma=1J$
- $\alpha=0.01$


Interval estimation for the mean
========================================================

The $99\%$ confidence interval( or $1\%$ level) is then 

$CI_{99\%}=(\bar{x}-2.57 \frac{\sigma}{\sqrt{n}}, \bar{x}+2.57  \frac{\sigma}{\sqrt{n}})$
</br>$=(64.46-2.57 \frac{1}{\sqrt{10}}, 64.46+2.57  \frac{1}{\sqrt{10}})=(63.64,65.27)$

note that 
$CI_{95\%}=(63.84,65.08) \subset CI_{99\%}=(63.64,65.27)$


Interval estimation for the mean (unknown variance)
========================================================

What if we **don't know** $\sigma_X$: The most likely situation!

We are going to assume only the condition:

1. that $X \hookrightarrow N(\mu, \sigma^2_X)$. 

If we do not know the **variance** we can estimate it by $S^2$ and form the standardized statistic

$T=\frac{\bar{X}-E(\bar{X})}{\sqrt{V(\bar{X})}}= \frac{\bar{X}-\mu}{S/\sqrt{n}}$


Interval estimation for the mean (unknown variance)
========================================================

If:

- $n>30$ then the central limit theorem gives us a good approximation to a normal distribution for 

$T= \frac{\bar{X}-\mu}{S/\sqrt{n}}\hookrightarrow N(\mu, S^2)$

- $n<30$ then $T$ follows a **t** distribution with $n-1$ degrees of freedom.

$T=\frac{\bar{X}-\mu}{S/\sqrt{n}}\hookrightarrow t(n-1)$


Interval estimation for the mean (unknown variance)
========================================================

From the definition of random confidence interval at confidence $95\%$

$(L,U) = (\bar{X} - f_{sup},\bar{X} - f_{inf})$, such that $P(\bar{X} - f_{sup} \leq \mu \leq \bar{X} - f_{inf})=0.95$

we have:
</br>$f_{inf}=t_{0.975,n-1}*S/\sqrt{n}$
</br>$f_{sup}=t_{0.025,n-1}*S/\sqrt{n}$

$(l,u) = (\bar{x} - t_{0.025,n-1}s/\sqrt{n},\bar{x} - t_{0.975, n-1}s/\sqrt{n})$


or at $99\%$

$(l,u) = (\bar{x} - t_{0.005,n-1}s/\sqrt{n},\bar{x} - t_{0.995, n-1}s/\sqrt{n})$





Interval estimation for the mean (unknown variance)
========================================================


A metallic material is tested for impact to measure the energy required to cut it at a given temperature.

- Ten specimens of A238 steel were cut at 60ºC at the following impact energies (J)

- 64.1, 64.7, 64.5, 64.6, 64.5, 64.3, 64.6, 64.8, 64.2, 64.3

- If we know that the impact energy is randomly distributed but we **do not know** the variance what is the $95\%$ CI for the mean of these data? 


Interval estimation for the mean (unknown variance)
========================================================

- $\bar{x}$=64.46
- $s=0.227$
- $\alpha=0.05$
- $t_{0.975,9}=-2.26$ obtained from $P(T \leq t_{0.975,9})=0.025$
- $t_{0.025,9}=2.26$ obtained from $P(T \leq t_{0.025,9})=0.975$

The CI interval is then

$CI=(\bar{x}- t_{0.975,9}\frac{s}{\sqrt{n}},\bar{x}-t_{0.025,9}  \frac{s}{\sqrt{n}})$
</br>$=(64.46-2.26 \frac{0.227}{\sqrt{10}},64.46+2.26 \frac{0.227}{\sqrt{10}})=(64.29,64.62)$


but $CI=(63.84,65.08)$ when $\sigma_X=1$. Data suggests $\sigma_X<1$. 


Interval estimation for the variance
========================================================
$t_{0.025,n-1}=F^{-1}(0.975)$ 
</br>for $n=10$ or $df=n-1=9$


```r
t0.975 <- qt(0.025, df=9)
t0.975
```

```
[1] -2.262157
```

```r
t0.025 <- qt(0.975, df=9)
t0.025
```

```
[1] 2.262157
```



Interval estimation
========================================================

- $t_{\alpha/2, n-1}$ is the number of the $t$ distribution that **leaves out** $\alpha/2$ of the probability. 

- $t_{\alpha/2, n-1}=F_{t,n-1}^{-1}(1-\alpha/2)$


- Remember that $t_{1-\alpha/2, n-1}$=-$t_{\alpha/2, n-1}$



Interval estimation
========================================================

<img src="./figures/ttable.JPG" style="width:50%"  align="center">



Interval estimation for the variance
========================================================

We know that the estimate for $s^2=\sigma^2_X=0.227^2=0.05$, but what is its confidence interval?

We are going to still assume the condition:

1. that $X \hookrightarrow N(\mu, \sigma^2_X)$. 

and estimate the variance with $S^2$ and form the standardized statistic

$Y=S^2(n-1)/\sigma_X^2$

Which does not capture a distance from $\sigma_X^2$ but rather a **proportion**.

Interval estimation for the variance
========================================================

When  $X \hookrightarrow N(\mu, \sigma^2_X)$.

- then $Y$ follows a $\chi^2$ distribution with $n-1$ degrees of freedom

$\frac{S^2}{\sigma_X^2}(n-1)\rightarrow \chi^2_{n-1}$

- We look for confidence interval at confidence $95\%$ $(L,U)$ such that $P(L \leq \sigma_x^2 \leq U)=0.95$

We can use the $\chi^2$ to determine the $95\%$ of the distribution about $Y$

$P(\chi^2_{0.975,n-1} \leq Y \leq \chi^2_{0.025,n-1})=0.95$


Interval estimation for the variance
========================================================

replacing the value of $Y$

$P(\chi^2_{0.975,n-1} \leq \frac{S^2}{\sigma_X^2}(n-1) \leq \chi^2_{0.025,n-1})=0.95$

and solving for $\sigma_X^2$

$P(\frac{S^2 (n-1)}{\chi^2_{0.025,n-1}}\leq \sigma_X^2 \leq \frac{S^2(n-1)}{\chi^2_{0.975,n-1}})=0.95$

The random interval at $95\%$  confidence 

$(L,U) = (\frac{S^2 (n-1)}{\chi^2_{0.025,n-1}},\frac{S^2(n-1)}{\chi^2_{0.975,n-1}})$

and the $95\%$ confidence interval (script size)
$(l,u) = (\frac{s^2 (n-1)}{\chi^2_{0.025,n-1}},\frac{s^2(n-1)}{\chi^2_{0.975,n-1}})$


Interval estimation for the variance
========================================================
$\chi^2_{0.975,n-1}=F^{-1}(0.025)$ 
</br>for $n=10$ or $df=n-1=9$


```r
chi0.975 <- qchisq(0.025, df=9)
chi0.975
```

```
[1] 2.700389
```

```r
chi0.025 <- qchisq(0.975, df=9)
chi0.025
```

```
[1] 19.02277
```


Interval estimation
========================================================

<img src="./figures/chitable.JPG" style="width:50%"  align="center">


Interval estimation for the variance
========================================================

In our example

- $s=0.227$
- $n=10$

$(l,u) = (\frac{s^2 (n-1)}{\chi^2_{0.025,n-1}},\frac{s^2(n-1)}{\chi^2_{0.975,n-1}})$
</br>$= (\frac{0.227^2 (10-1)}{19.02277},\frac{0.227^2(10-1)}{2.700389})=c(0.02,0.17)$

According to the data $\sigma_X^2 \neq 1$



Interval estimation for proportions
========================================================

A random sample of 400 patients was selected for testing a new vaccine for the influenza virus, after 6 months of vaccination 136 were ill. What is the expected efficacy of the vaccine?

We have $x=136$ failures in 400 trials and we expect them to follow a binomial distribution   

$X\rightarrow Bin(n,p)$ with $E(X)=np$, $V(X)=np(1-p)$

with the probability $p$ of failure for one person ($k=1$).

We want to have a $95\%$ CI for $p$.

Interval estimation for proportions
========================================================

If the population distribution is

$X \rightarrow Bin(n,p)$

Then the standardized statistic of $X$ (the number of successful Bernoulli trials) can be approximated by a standard distribution when $pn>5$ and $(p-1)n>5$

$Z=\frac{X-E(X)}{\sqrt{V(X)}}= \frac{X-np}{\big[np(1-p) \big]^{1/2}}\rightarrow N(0,1)$

Interval estimation for proportions
========================================================

From obtaining $95\%$ of the distribution for $Z$  

$P(z_{0.975} \leq Z \leq z_{0.025})$

$=P(z_{0.975} \leq \frac{X-np}{\big[np(1-p) \big]^{1/2}} \leq z_{0.025})=0.95$

We obtain the $95\%$ confidence interval for $p$ (remember: $z_{0.025}=-z_{0.975}=1.96$)

$P(\frac{X}{n}-1.96\big[\frac{p(1-p)}{n} \big]^{1/2} \leq p \leq \frac{X}{n}+1.96\big[\frac{p(1-p)}{n} \big]^{1/2})$

We haven't managed to completely solve for $p$

Interval estimation for proportions
========================================================

we define the statistics of a Bernoulli trial ($k=0, 1$): 

- $\bar{K}=\sum_{i=1}^n K_i=X/n$ (remember $E(\bar{K})=E(K)=p$)
- $S^2=\bar{K}(1-\bar{K})$ 

$P(\bar{K}-1.96 \frac{S}{\sqrt{n}} \leq p \leq \bar{K}+1.96 \frac{S}{\sqrt{n}})$

Then the random interval at $95%$ confidence is 
$(L,U)=(\bar{K}-1.96 \frac{S}{\sqrt{n}},\bar{K}+1.96 \frac{S}{\sqrt{n}})$

Interval estimation for proportions
========================================================

The $95\%$ CI associated with a set of observations is 

$CI=(l,u)=(\bar{k}-z_{\alpha/2}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2},  \bar{k}+z_{\alpha/2}\big[\frac{\bar{k}(1-\bar{k})}{n} \big]^{1/2})$

where $\bar{k}=x/n=\hat{p}$ (average the number of events $A$ in $n$ trials)

equivalently:


$CI=(l,u)=(\hat{p}-z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2},  \hat{p}+z_{\alpha/2}\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2})$


Interval estimation for proportions
========================================================

In our case, we are counting failures on vaccinations X=136 in 400 trials   

we know

- $\hat{p}=\bar{k}=134/400=0.34$
- $z_{0.025}=1.96$

$CI=(\hat{p}-1.96\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2},  \hat{p}+1.96\big[\frac{\hat{p}(1-\hat{p})}{n} \big]^{1/2})$

$=(0.29,0.39)$

Why do we measure the failure instead of the success of a vaccine?
