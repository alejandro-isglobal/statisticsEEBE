#comentario: asigna valores a a
a<-c(1,2,3,4,5)
#imprimelos
a
#asigna valores a b
b<-2
#imprime la suma entre a y b
a+b
#lista todas las variables definidas
ls()

#secuencia de 1 a 10
a<-1:10
a
b<-a^2
b
#para a en el eje x y b en el y
plot(a,b)
#para b como funcion de a (~=[ALTGR+4])
plot(b ~ a)
plot(b ~ a, col = "blue", pch = "A")


#busca ayuda con ?
?is.na


#pregunta la clase de un vectos con la función class()
class(17)
class("male")
class(TRUE)
class(NaN)
class(Inf)



# funcion de concatenacion c()
a <- c(10, 5, NaN, 6, Inf)
class(a)
is.vector(a)


b <- c(TRUE,FALSE,TRUE)
class(b)
is.vector(b)


#funcion assign() 
assign("a",c(1,2,3,4,5))
a
#otra forma de usar asign es con: <-
a<-1:5
a
#revisa las variables definidas
ls()


#secuencias
assign("a",c(1,2,3,4,5))
a
#otra forma de usar asign es con: <-
a<-1:5
a
#revisa las variables definidas
ls()


#seleccion de elementos de un vector con []
b<-seq(1,100,2)
b[5]
b[5]<-999
b
#selecciona y quita elementos
b[c(1,3,4)]
b[1:10]
b[-c(1,3,4)]
b

#Se puede hacer aritmetica con vectores
a<-rep(2,10)
a
b<-a+1
b
b*a
exp(a)


#define matrices con matrix()
mat<-matrix(c(1,2,3,4,5,6,7,8),ncol=2,nrow=4)
mat
mat<-matrix(1:8,ncol=4,nrow=2)
mat

#ncol() y nrow()
ncol(mat)
nrow(mat)


#define una matriz aleatoria
x <- matrix(rnorm(100, 1), ncol = 5)

#dale nombres a las columnas
colnames(x)<-c("a","b","c","d","e")
x

head(x)
tail(x)
dim(x)
image(x)

#elemento (1,2)
x[1,2]

#columnas b,c,d
x[,c("b","c","d")]
x[seq(2,20,2),]
x[,c(1,2)] <- 0
x

#funciones ultiles
colSums(x)
rowSums(x)
t(x)
diag(x)


#define un data.frame con data.frame()
v1<-c("a","b","c")
v2<-c(1,2,3)
matFrame<-data.frame(letters=v1, numbers=v2)
matFrame
class(matFrame[,2])
class(matFrame[,1])

#convertir una matriz en data.frame
matFrame<-as.data.frame(x)
matFrame

#data.frame airquality
airquality

#explora airquality
dim(airquality)
head(airquality)


#selecciona variables de un data.frame
names(airquality)
airquality$Ozone
airquality$Day
airquality[c("Ozone","Day")]
class(airquality)

#tambien como matriz
airquality[1:10,c(2,5)]

#listas con list()
mat<-cbind(c(2,4,6),c(1,2,3))
vec<-c(TRUE,FALSE)
chr<-"hello"
L<-list(M=mat,V=vec,C=chr)
L

#selecciona elementos de una lista con $
names(L)
L$M
L$C

#o con [[]]
L[[1]]
L[[2]]

#cambia los nombres con names()
names(L)<-c("data","output","message")
L
