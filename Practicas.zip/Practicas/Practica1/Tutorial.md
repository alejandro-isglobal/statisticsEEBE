Statisticswith R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering, Universitat Politècnica de Catalunya (UPC)
 

Lecture 1

Practicals
========================================================
 

This is a set of 8 practicals that introduce R as a tool for statistical analysis. 

- Statistical concepts and code are explained simultaneously 
- I will use RStudio a GUI for R with integrated. functionalities


Lecture 1
========================================================

- Introduce R (why R?)
- Components of RStudio  
-- Command line
-- Text editor
-- Plot window
- Finding help
- Data types  
-- vectors
-- matrices
-- data.frames
-- lists

- Importing and exporting data files


 
Why R?
========================================================



R:
- is free software
- is a programming language (object oriented)
- has a flexible sintaxis and coding is easy
- has mutiple packages 
- strong comunity

R was initially thought as a analysis software tool but it has grown into a software with strong visualization options and allows even web-apps.  

Slide With Code
========================================================


```r
summary(cars)
```

```
     speed           dist       
 Min.   : 4.0   Min.   :  2.00  
 1st Qu.:12.0   1st Qu.: 26.00  
 Median :15.0   Median : 36.00  
 Mean   :15.4   Mean   : 42.98  
 3rd Qu.:19.0   3rd Qu.: 56.00  
 Max.   :25.0   Max.   :120.00  
```

Slide With Plot
========================================================

![plot of chunk unnamed-chunk-2](Tutorial-figure/unnamed-chunk-2-1.png)
