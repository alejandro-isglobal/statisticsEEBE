####################
#pg6

#assign value to a 
a<-c(1,2,3,4,5) 
#print value of a 
a 
#assign value to b 
b<-2 
#print (show) sum of a and b 
a+b 
#list all variables defined in the session 
ls() 


###################
#pg7

a<-1:10 
a 
b<-a^2 
b 
plot(a,b) 
plot(a,b,col="blue",pch="A") 


###################
#pg8

?is.na 
is.na(c(1, NA)) 

###################
#pg9

?read.dta

library(foreign) 
?read.dta 


###################
#pg10

is.vector(17)
 
class(17) 
class("male") 
class(TRUE) 
class(NaN) 
class(Inf) 

c(10, 5, NaN, 6, Inf) 
class(c(10, 5, NaN, 6, Inf)) 
is.vector(c(10, 5, NaN, 6, Inf)) 
c(TRUE,FALSE,TRUE) 
class(c(TRUE,FALSE,TRUE)) 
is.vector(c(TRUE,FALSE,TRUE)) 

###################
#pg11

assign("a",c(1,2,3,4,5)) 
a 
#another way of using assign is with <- 
a<-1:5 
a 
#check the variables you have defined 
ls() 


seq(1,10) 
#or 
1:10 
#a function within function 
assign("b",seq(1,10)) 
#or a more standard use 
b<-1:10 

###################
#pg12

b<-seq(1,100,2) 
b[5] 
b[5]<-999 
b 
#select and remove many elements 
b[c(1,3,4)] 
b[1:10] 
b[-c(1,3,4)] 
b 

a<-rep(2,10) 
a 
b<-a+1 
b 
b*a 

###################
#pg13

matR<-cbind(c(1,2,3,4),c(2,4,6,8)) 
matR

matC<-rbind(c(1,2,3,4),c(2,4,6,8)) 
matC

mat<-matrix(c(1,2,3,4,5,6,7,8),ncol=2,nrow=4) 
mat 
mat<-matrix(c(1,2,3,4,5,6,7,8),ncol=4,nrow=2) 
mat

###################
#pg14

##DIY...
mat<-matrix(1:10,5,2)

#NCOL, NROW


###################
#pg15

x <- matrix(rnorm(100, 1), ncol = 5) 
colnames(x)<-c("a","b","c","d","e") 
x 
#explore the matrix... 
head(x) 
tail(x) 
dim(x) 
image(x) 
#select one element 
x[1,2] 

#DIY


###################
#pg16


#DIY


###################
#pg17

mat<-cbind(c("a","b","c"),c(1,2,3)) 
colnames(mat)<-c("letters","numbers") 
mat 
mat[,2] 
#numbers get coerced into characters 
class(mat[,2]) 
class(mat) 


airquality 
dim(airquality) 
head(airquality) 
class(airquality) 
newCol<-c(rep("yes",130),rep("maybe",10),rep("no",13)) 
newAir<-cbind(airquality,newCol) 
class(newAir[,3]) 
class(newAir[,7]) 
#in a data.frame characters are coerced into factors 
newAir[,7] 


###################
#pg18

matFrame<-as.data.frame(mat) 
matFrame 
#but check thesecond column 
matFrame[,2] 
# as is not numeric we cannot do 
mean(matFrame[,2]) 

#DIY

#
v1<-c("a","b","c") 
v2<-c(1,2,3) 
matFrame<-data.frame(letters=v1,numbers=v2) 
mean(matFrame[,2]) 
class(matFrame[,2]) 
class(matFrame[,1]) 

###################
#pg19

names(airquality) 
airquality$Ozone 
airquality$Day 
airquality[c("Ozone","Day")] 

airquality[1:10,c(2,5)]

sel<-airquality$Month>=8 
#whatever mathch TRUE rows-wise will be selected 
#cbind(sel, airquality) 
AugustNovAir<-airquality[sel,] 

###################
#pg20

newCol<-c(rep("yes",130),rep("maybe",10),rep("no",13)) 
facCol<-as.factor(newCol) 

levels(facCol) 
#the levels can be renamed 
levels(facCol)<-c("a","b","c") 
facCol 

table(airquality$Month,facCol)

tapply(airquality$Temp,facCol,mean)

###################
#pg21

mat<-cbind(c(2,4,6),c(1,2,3)) 
vec<-c(TRUE,FALSE) 
chr<-"hello" 
L<-list(M=mat,V=vec,C=chr) 
L 


names(L) 
L$M 
L$C

L[[1]] 
L[[2]]

names(L)<-c("data","output","message") 
L

###################
#pg23

dat<-read.table("dat1.txt") 
dat[1:5,] 
names(dat) 
class(dat) 
#change options for the read 
?read.table 
dat<-read.table("dat1.txt",header=TRUE) 
dat 
names(dat) 
dat<-read.table("dat2.txt",header=TRUE,sep=",") 
dat 
names(dat) 


write.table(dat,file="myData.txt") 
?write.table 
write.table(dat,file="myData.txt",quote=FALSE) 

###################
#pg24

data(swiss) 
swiss 
write.dta(swiss,file="stataDat.dta") 
stataD<-read.dta("stataDat.dta") 
stataD 

ls() 
save(swiss,dat,file="myResults.RData") 
#remove all the variables in your environment 
rm(list=ls()) 
ls() 
#load your previous results 
load("myResults.RData") 
ls() 
dat 


###################
#pg25

#DIY



