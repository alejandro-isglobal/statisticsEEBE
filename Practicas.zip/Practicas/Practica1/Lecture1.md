Statistical concepts with R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 1</p>

Practicals
========================================================
 

This is a set of 8 practicals that introduce R as a tool for statistical analysis. 

- Statistical concepts and code are explained simultaneously 
- I will use RStudio a GUI for R with integrated. functionalities

- I have posted the material (slides and videos) in my [blog](https://alejandro-isglobal.github.io/teaching.html)

Lecture 1
========================================================

- Introduce R: why, where, and what is it?
- Components of RStudio  
-- The console
-- The script
-- Plotting
- Help
- Data types  
-- vectors
-- matrices
-- data.frames
-- lists

- Importing and exporting data files


 
Why R?
========================================================


R:
- is free software
- is a programming language (object-oriented)
- has a flexible syntaxis and coding is easy
- has multiple packages 
- strong community

R was initially thought of as an analysis software tool but it has grown into the software with strong visualization options and allows even web-apps. All my [blog](https://alejandro-isglobal.github.io/teaching.html). was made in R. 

Where is R?
========================================================

- R is stored, compiled, and updated in the [r-cran](http://cran.es.r-project.org/
) repository

http://cran.es.r-project.org/

- You can download the binary distributions for Linux, Mac, or windows by following the links.

- RStudio is a GUI that integrates many additional functions in R.

https://rstudio.com/

- Download and install [RStudio](https://rstudio.com/) <b>after</b> you have installed R.


What is R?
========================================================

R is a programming language that runs in a command line.

- The command line in RStudio is at the bottom left corner, called the <b>console</b>

- In the command line, we can write any expression with correct syntax and R will run it after pressing enter. 

- open Rstudio and run the command 


```r
2+2
```

```
[1] 4
```

The console
========================================================

now try

```r
exp(pi*1i)
```

```
[1] -1+0i
```
or

```r
c(1,2,3)+2
```

```
[1] 3 4 5
```

The console
========================================================
You will see the results of these operations in the same command line

<img src="./Lecture1-figure/console.JPG" style="width:75%"  align="center">



The script
========================================================

The commands can be written in a text file, called a <b>script</b> with extension .R

- you can use any text editor
- RStudio has one that can be used to directly run the commands in the console
- Let's open a script in RStudio (Ctrl+Shift+N)

$$File \rightarrow New\,File \rightarrow R\,Script$$

- Save it as "test.R"



The script
========================================================
Write the following commands in the test.R

````markdown
#Commnet: assign values to a 
a <- c(1,2,3,4,5)
#print a
a
#assign values to b
b <- 2
#print the sum between and b
a+b
#list the variables defined
ls()
````


The script
========================================================
It should look something like

<img src="./Lecture1-figure/script.JPG" style="width:75%"  align="center">



The script
========================================================
- We can copy, paste and run each line on the console
- We can put the cursor on the line we want to run and then press [ctrl+Enter]. RStudio will copy, paste, and run the line. 
- Each line followed by # is a commnet and ignored.
- The function <code><-</code> is the assigment function to a variable (a, b, myVariable, etc.).
-  <code><-</code>  creates a new command (a, b, myVariable, etc.), when you run it it prints the value assigned to the variable. 
- R does not print anything that it is not asked for.
- Running the command <code>source("test.R")</code> will run every single line of the script "test.R"

Plotting
========================================================

Plots are functions of R that are run in the command line.

Write the following lines in the script test.R, run line by line or run <code>source("test.R")</code>


```r
a <- 1:10
b <- a^2
#plot a in x y b in y
plot(a,b)
```
Plotting
========================================================

![plot of chunk plot1](Lecture1-figure/plot1-1.png)

 
Plotting
========================================================

plot <code>b</code> as a function of <code>a</code> (<code>~</code>=[ALTGR+4]). Use parameters to change the display.
 

```r
plot(b ~ a, col = "blue", pch = "A") 
```

![plot of chunk plot2](Lecture1-figure/plot2-1.png)


Plotting
========================================================

- Remember: 

write your code in test.R and reproduce all your work with 

<code>source("test.R")</code>

- Note:

You can also save your plot as pdf/png/jpeg




Help
========================================================

Online:
- Use google for general questions: i.e. "substitute missing values in R"
- Check forums like <b>R help archive</b> or <b>Stack overflow</b>. Follow the examples, copy-paste the code from the answers you fid and try to understand!


Help
========================================================

Local:
- If you want to find out what a specific function of R does, like <code>is.na</code> then type

?is.na

- check examples and copy-paste them


```r
is.na(c(1, NA))
```

```
[1] FALSE  TRUE
```

Help
========================================================

If you want to learn more about R go to CRAN

- Manual: [An Introduction to R](http://cran.r-project.org/doc/manuals/R-intro.pdf)

In CRAN and RStudio you can find how to create packages, websites, and apps!



Data types
========================================================


R are a set of <b>functions</b> that operate in data structures

In general 

$$Data\,structure \rightarrow funcion \rightarrow Another\, data \,structure$$

In particular

$$a \rightarrow oneFuncion(a) \rightarrow b$$

In code

````markdown
b <- oneFunction(a)
````


Vectors
========================================================

R is a vectorial language: its primitive data structure is a vector.

The number <code>17</code> is a vector

```r
17
```

```
[1] 17
```

```r
is.vector(17)
```

```
[1] TRUE
```

$$17 \rightarrow is.vector(a) \rightarrow TRUE$$


Vectors
========================================================

There are many different classes. Let's use the function <code>class</code> to find the class of different one-item vectors


```r
class(17)
```

```
[1] "numeric"
```

```r
class(TRUE)
```

```
[1] "logical"
```


Vectors
========================================================


```r
class("male")
```

```
[1] "character"
```

```r
class(NaN)
```

```
[1] "numeric"
```

```r
class(Inf)
```

```
[1] "numeric"
```



Vectors
========================================================

Constructors: They are functions that create vectors

<code>c()</code> concatenates the one-item vectors into a vector of higher length


```r
a <- c(10, 5, NaN, 6, Inf)
class(a)
```

```
[1] "numeric"
```

```r
is.vector(a)
```

```
[1] TRUE
```

Vectors
========================================================

Concatenation of logical units

```r
b <- c(TRUE,FALSE,TRUE)
class(b)
```

```
[1] "logical"
```

```r
is.vector(b)
```

```
[1] TRUE
```

Vectors
========================================================

<code>c()</code> is a function with as many parameters as we want to pass

$$1,3,5,7 \rightarrow c(1,3,5,7) \rightarrow [1]\, 1\, 3\, 5\, 7$$


Vectors
========================================================

A main function is the function <code>assign()</code>: it assigns to the character in the first parameter the data in the second one.


```r
assign("a",c(1,2,3,4,5)) 
a
```

```
[1] 1 2 3 4 5
```


$$a,1,2,3,4,5 \rightarrow assign(''a'',c(1,2,3,4,5)) \rightarrow a \rightarrow [1]\,1\,2\,3\,4\,5 $$ <br>

Note: function <code>c()</code> within function <code>assign()</code>
Vectors
========================================================
Another way to write  <code>assign()</code> is "<code><-</code>"

```r
a <- 1:5
a
```

```
[1] 1 2 3 4 5
```

It is more intuitive but remember that the previous code we apply a function with parameters "<code>a</code>" and "<code>1:5</code>". 

Vectors
========================================================
A useful function to contruct vectors is <code>seq()</code>


```r
seq(1,10)
```

```
 [1]  1  2  3  4  5  6  7  8  9 10
```

Which can also be written as


```r
1:10
```

```
 [1]  1  2  3  4  5  6  7  8  9 10
```

Vectors
========================================================

We can assign the sequence to a vector as we have done before

```r
assign("b",seq(1,10))
```

in standard notation


```r
b <- 1:10
b
```

```
 [1]  1  2  3  4  5  6  7  8  9 10
```


Vectors
========================================================

Selectors: They are functions to get specific values from a data structure 

The elments of a vecor asre selected with the function <code>[]</code>



```r
b <- seq(1,17,2)
b
```

```
[1]  1  3  5  7  9 11 13 15 17
```

```r
b[5]
```

```
[1] 9
```

Vectors
========================================================

We can substitute the value of an element using the assign function


Replace the fifth element of <code>b</code> by <code>999</code>:

```r
b[5] <- 999
b
```

```
[1]   1   3   5   7 999  11  13  15  17
```

Vectors
========================================================

Since <code>[]</code> is a function, we can use other functions in its parameters:

Select mutiple elements with the concatenation function <code>c()</code>

```r
b[c(1,3,4)]
```

```
[1] 1 5 7
```


Vectors
========================================================

or use sequence "<code>:</code>"


```r
b[1:4]
```

```
[1] 1 3 5 7
```

The power of R in data-handling comes from passing arguments to selectors that are functions. In R syntax, google will look like:

`````Markdown
WWW[google(WWW, "help R")]
`````
select the world-wide-web pages where the function google finds the text "help R



Vectors
========================================================

We can remove elements with minus the vector of selected items


```r
b[-c(1,3,4)]
```

```
[1]   3 999  11  13  15  17
```

```r
b
```

```
[1]   1   3   5   7 999  11  13  15  17
```

Vectors
========================================================

We can name the components of a vector by any characters we want 


```r
names(b) <- c("a", "b", "c", "d", "e", "f", "g", "h", "i")
b
```

```
  a   b   c   d   e   f   g   h   i 
  1   3   5   7 999  11  13  15  17 
```

Vectors
========================================================

and use the names of the elements to select them in the order we want

```r
b[c("d", "e", "c", "a", "f")]
```

```
  d   e   c   a   f 
  7 999   5   1  11 
```

Vectors
========================================================

We can use logic functions on vectors

- equal: <code>==</code> 
- not equal: <code>!=</code>
- greater, greater or equal than: <code>></code>, <code>>=</code>
- lower than, lower or equal than: <code><</code>, <code><=</code> 

and use their results to select elements.

Vectors
========================================================


```r
b>10
```

```
    a     b     c     d     e     f     g     h     i 
FALSE FALSE FALSE FALSE  TRUE  TRUE  TRUE  TRUE  TRUE 
```

```r
b[b>10]
```

```
  e   f   g   h   i 
999  11  13  15  17 
```



Vectors
========================================================

We can also do arithmetics with vectors


```r
a <- rep(2,10)
a
```

```
 [1] 2 2 2 2 2 2 2 2 2 2
```

```r
b <- a+1
b
```

```
 [1] 3 3 3 3 3 3 3 3 3 3
```



Vectors
========================================================

Functions are applied on each element of the vector, producing a vector

```r
b*a
```

```
 [1] 6 6 6 6 6 6 6 6 6 6
```

```r
exp(a)
```

```
 [1] 7.389056 7.389056 7.389056 7.389056 7.389056 7.389056 7.389056 7.389056
 [9] 7.389056 7.389056
```


Matrices
========================================================

Matrices are two-dimensional arrays, organized by columns and rows


Matrices can be constructed by the concatenation of vectors by columns using <code>cbind()</code> 


```r
matR <- cbind(c(1,2,3,4), c(2,4,6,8))
matR
```

```
     [,1] [,2]
[1,]    1    2
[2,]    2    4
[3,]    3    6
[4,]    4    8
```

Matrices
========================================================

Or conacatenate vector by rows with <code>rbind()</code> 

```r
matC <- rbind(c(1,2,3,4), c(2,4,6,8))
matC
```

```
     [,1] [,2] [,3] [,4]
[1,]    1    2    3    4
[2,]    2    4    6    8
```



Matrices
========================================================

More generally Matrices are vectors with a "square" format. The constructor of a matrix is the function <code>matrix()</code>

$$v \rightarrow matrix(v) \rightarrow m$$


```r
mat <- matrix(1:8, ncol=4, nrow=2)
mat
```

```
     [,1] [,2] [,3] [,4]
[1,]    1    3    5    7
[2,]    2    4    6    8
```

Matrices
========================================================

- What do you think the functions <code>ncol()</code> and <code>nrow()</code> do?

- Look then up in R help


Matrices
========================================================

- Name the columns of the matrix 


```r
mat <- matrix(1:10, ncol=5)
mat
```

```
     [,1] [,2] [,3] [,4] [,5]
[1,]    1    3    5    7    9
[2,]    2    4    6    8   10
```

using the alfabet letters and the function <code>colnames()</code> 


Matrices
========================================================


```r
colnames(mat) <- letters[1:5]
mat
```

```
     a b c d  e
[1,] 1 3 5 7  9
[2,] 2 4 6 8 10
```

Note:

```r
letters[1:5] == c("a", "b", "c", "d", "e")
```

```
[1] TRUE TRUE TRUE TRUE TRUE
```



Matrices
========================================================

Let's simulate a random numbers with a function called <code>rnorm()</code>


```r
x <- matrix(rnorm(100, 1), ncol = 4)
colnames(x)<-c("a","b","c","d")
x
```

```
                a           b          c           d
 [1,]  0.45483313  1.10445351  0.8270913  2.06381253
 [2,] -0.23063993 -0.23590174  2.4288955  2.65069200
 [3,]  1.15703007  1.02238290 -0.5774972  1.89450041
 [4,] -1.00638809 -0.52434665  0.8606156  0.78352571
 [5,]  0.29698399  1.75396273  0.8766145  0.21747576
 [6,]  3.34301205  2.03658129  1.2390524  0.40218251
 [7,]  0.15566041  0.17786889  0.4835972  1.98555840
 [8,]  0.95122385  2.54837657  3.5371816  1.92558589
 [9,] -0.67914728  0.02039864  0.8177558  0.16112972
[10,]  0.58738839  1.90198613  0.3696160  1.32589933
[11,] -0.15908947  0.87232291  1.2182201 -0.19910102
[12,]  1.16329165  1.01757186  3.2562625  0.43997389
[13,]  0.64764857 -0.28893621  0.1810843  1.37423553
[14,]  0.83440817  2.06438452  0.6895721  2.70634567
[15,]  0.29245350  1.51499587 -0.3075599  2.28024689
[16,] -0.86138554  0.61169196  0.9450283 -0.07694996
[17,] -0.61508019  1.96050548  1.9756530  1.57869430
[18,] -0.09262365  4.01033118 -0.1404559  0.88793368
[19,]  1.10148813  2.64164956  0.2019453  0.65364107
[20,]  1.11324916  2.71023420 -0.3075846  2.71806434
[21,]  0.52747327  2.18818078  0.5385730  0.50489856
[22,] -0.32131947  1.38678619  1.7652957  2.26305903
[23,]  1.89766882  1.01138268  0.8832327  1.35102833
[24,]  2.05148404  0.06947322  1.1064234  2.08473518
[25,]  2.16700686  1.47216360  1.5290091  1.81386293
```

Matrices
========================================================

The selector of a matrix if the function 
<code>[,]</code> (with a comma).<br>

Selects the element (2,1) of the matrix <code>x</code>

```r
x[2,1]
```

```
         a 
-0.2306399 
```

Matrices
========================================================
Leaving the first or second parameter blank in <code>[,]</code> then selects all the elements in rows or columns

Selects the elements of <code>x</code> in the first column

```r
x[,1]
```

```
 [1]  0.45483313 -0.23063993  1.15703007 -1.00638809  0.29698399  3.34301205
 [7]  0.15566041  0.95122385 -0.67914728  0.58738839 -0.15908947  1.16329165
[13]  0.64764857  0.83440817  0.29245350 -0.86138554 -0.61508019 -0.09262365
[19]  1.10148813  1.11324916  0.52747327 -0.32131947  1.89766882  2.05148404
[25]  2.16700686
```

Matrices
========================================================
Selects the elements of <code>x</code> in the second row 

```r
x[2,]
```

```
         a          b          c          d 
-0.2306399 -0.2359017  2.4288955  2.6506920 
```


Matrices
========================================================

Exercises:
- Select the element (1,2) of the matrix <code>x</code>
- Create a submatrix of <code>x</code> by selecting the columns b, c, d. 
- Create a submatrix of <code>x</code> by selecting the even rows. 
- Substitute the values of the first and second columns for zero.
- Explore the matrix with the functions
<code>head()</code>, <code>tail()</code>, <code>dim()</code>, <code>image()</code>

Matrices
========================================================

Matrices are vectors, as such all the vector functions apply element by element.

- Arithmetic is on matrices are performed on each element


```r
mat^2
```

```
     a  b  c  d   e
[1,] 1  9 25 49  81
[2,] 4 16 36 64 100
```

This is not the square of a matrix! 

Each element is just being squared (the matrix product product is <code>mat%*%t(mat)</code>)

Matrices
========================================================

These are useful functions to operate on matrices:

- Sum the elements of a matrix column-wise: <code>colSums()</code>,  

- Sum the elements of a matrix row-wise: <code>rowSums()</code>,  

- The transpose of a matrix: <code>t()</code>

- The digonal of a matrix: <code>diag()</code>

Data frames
========================================================

A data frame is a special type of two dimensional array. It is constructed by the function <code>data.frame()</code>, it concatenates vectors of different classes.


```r
v1 <- c(TRUE,FALSE,FALSE)
v2 <- c(1,2,3)
matFrame <- data.frame(logic=v1, numbers=v2)
matFrame
```

```
  logic numbers
1  TRUE       1
2 FALSE       2
3 FALSE       3
```

 

Data frames
========================================================


```r
class(matFrame[,2])
```

```
[1] "numeric"
```

```r
class(matFrame[,1])
```

```
[1] "logical"
```

```r
class(matFrame)
```

```
[1] "data.frame"
```


Data frames
========================================================
In a matrix, all the elements are of the same class. A matrix can be transformed into a data frame


```r
matFrame <- as.data.frame(x) 
matFrame
```

```
             a           b          c           d
1   0.45483313  1.10445351  0.8270913  2.06381253
2  -0.23063993 -0.23590174  2.4288955  2.65069200
3   1.15703007  1.02238290 -0.5774972  1.89450041
4  -1.00638809 -0.52434665  0.8606156  0.78352571
5   0.29698399  1.75396273  0.8766145  0.21747576
6   3.34301205  2.03658129  1.2390524  0.40218251
7   0.15566041  0.17786889  0.4835972  1.98555840
8   0.95122385  2.54837657  3.5371816  1.92558589
9  -0.67914728  0.02039864  0.8177558  0.16112972
10  0.58738839  1.90198613  0.3696160  1.32589933
11 -0.15908947  0.87232291  1.2182201 -0.19910102
12  1.16329165  1.01757186  3.2562625  0.43997389
13  0.64764857 -0.28893621  0.1810843  1.37423553
14  0.83440817  2.06438452  0.6895721  2.70634567
15  0.29245350  1.51499587 -0.3075599  2.28024689
16 -0.86138554  0.61169196  0.9450283 -0.07694996
17 -0.61508019  1.96050548  1.9756530  1.57869430
18 -0.09262365  4.01033118 -0.1404559  0.88793368
19  1.10148813  2.64164956  0.2019453  0.65364107
20  1.11324916  2.71023420 -0.3075846  2.71806434
21  0.52747327  2.18818078  0.5385730  0.50489856
22 -0.32131947  1.38678619  1.7652957  2.26305903
23  1.89766882  1.01138268  0.8832327  1.35102833
24  2.05148404  0.06947322  1.1064234  2.08473518
25  2.16700686  1.47216360  1.5290091  1.81386293
```

Data frames
========================================================

There is a data frame demo in R. It is called airquality


```r
airquality
```

```
    Ozone Solar.R Wind Temp Month Day
1      41     190  7.4   67     5   1
2      36     118  8.0   72     5   2
3      12     149 12.6   74     5   3
4      18     313 11.5   62     5   4
5      NA      NA 14.3   56     5   5
6      28      NA 14.9   66     5   6
7      23     299  8.6   65     5   7
8      19      99 13.8   59     5   8
9       8      19 20.1   61     5   9
10     NA     194  8.6   69     5  10
11      7      NA  6.9   74     5  11
12     16     256  9.7   69     5  12
13     11     290  9.2   66     5  13
14     14     274 10.9   68     5  14
15     18      65 13.2   58     5  15
16     14     334 11.5   64     5  16
17     34     307 12.0   66     5  17
18      6      78 18.4   57     5  18
19     30     322 11.5   68     5  19
20     11      44  9.7   62     5  20
21      1       8  9.7   59     5  21
22     11     320 16.6   73     5  22
23      4      25  9.7   61     5  23
24     32      92 12.0   61     5  24
25     NA      66 16.6   57     5  25
26     NA     266 14.9   58     5  26
27     NA      NA  8.0   57     5  27
28     23      13 12.0   67     5  28
29     45     252 14.9   81     5  29
30    115     223  5.7   79     5  30
31     37     279  7.4   76     5  31
32     NA     286  8.6   78     6   1
33     NA     287  9.7   74     6   2
34     NA     242 16.1   67     6   3
35     NA     186  9.2   84     6   4
36     NA     220  8.6   85     6   5
37     NA     264 14.3   79     6   6
38     29     127  9.7   82     6   7
39     NA     273  6.9   87     6   8
40     71     291 13.8   90     6   9
41     39     323 11.5   87     6  10
42     NA     259 10.9   93     6  11
43     NA     250  9.2   92     6  12
44     23     148  8.0   82     6  13
45     NA     332 13.8   80     6  14
46     NA     322 11.5   79     6  15
47     21     191 14.9   77     6  16
48     37     284 20.7   72     6  17
49     20      37  9.2   65     6  18
50     12     120 11.5   73     6  19
51     13     137 10.3   76     6  20
52     NA     150  6.3   77     6  21
53     NA      59  1.7   76     6  22
54     NA      91  4.6   76     6  23
55     NA     250  6.3   76     6  24
56     NA     135  8.0   75     6  25
57     NA     127  8.0   78     6  26
58     NA      47 10.3   73     6  27
59     NA      98 11.5   80     6  28
60     NA      31 14.9   77     6  29
61     NA     138  8.0   83     6  30
62    135     269  4.1   84     7   1
63     49     248  9.2   85     7   2
64     32     236  9.2   81     7   3
65     NA     101 10.9   84     7   4
66     64     175  4.6   83     7   5
67     40     314 10.9   83     7   6
68     77     276  5.1   88     7   7
69     97     267  6.3   92     7   8
70     97     272  5.7   92     7   9
71     85     175  7.4   89     7  10
72     NA     139  8.6   82     7  11
73     10     264 14.3   73     7  12
74     27     175 14.9   81     7  13
75     NA     291 14.9   91     7  14
76      7      48 14.3   80     7  15
77     48     260  6.9   81     7  16
78     35     274 10.3   82     7  17
79     61     285  6.3   84     7  18
80     79     187  5.1   87     7  19
81     63     220 11.5   85     7  20
82     16       7  6.9   74     7  21
83     NA     258  9.7   81     7  22
84     NA     295 11.5   82     7  23
85     80     294  8.6   86     7  24
86    108     223  8.0   85     7  25
87     20      81  8.6   82     7  26
88     52      82 12.0   86     7  27
89     82     213  7.4   88     7  28
90     50     275  7.4   86     7  29
91     64     253  7.4   83     7  30
92     59     254  9.2   81     7  31
93     39      83  6.9   81     8   1
94      9      24 13.8   81     8   2
95     16      77  7.4   82     8   3
96     78      NA  6.9   86     8   4
97     35      NA  7.4   85     8   5
98     66      NA  4.6   87     8   6
99    122     255  4.0   89     8   7
100    89     229 10.3   90     8   8
101   110     207  8.0   90     8   9
102    NA     222  8.6   92     8  10
103    NA     137 11.5   86     8  11
104    44     192 11.5   86     8  12
105    28     273 11.5   82     8  13
106    65     157  9.7   80     8  14
107    NA      64 11.5   79     8  15
108    22      71 10.3   77     8  16
109    59      51  6.3   79     8  17
110    23     115  7.4   76     8  18
111    31     244 10.9   78     8  19
112    44     190 10.3   78     8  20
113    21     259 15.5   77     8  21
114     9      36 14.3   72     8  22
115    NA     255 12.6   75     8  23
116    45     212  9.7   79     8  24
117   168     238  3.4   81     8  25
118    73     215  8.0   86     8  26
119    NA     153  5.7   88     8  27
120    76     203  9.7   97     8  28
121   118     225  2.3   94     8  29
122    84     237  6.3   96     8  30
123    85     188  6.3   94     8  31
124    96     167  6.9   91     9   1
125    78     197  5.1   92     9   2
126    73     183  2.8   93     9   3
127    91     189  4.6   93     9   4
128    47      95  7.4   87     9   5
129    32      92 15.5   84     9   6
130    20     252 10.9   80     9   7
131    23     220 10.3   78     9   8
132    21     230 10.9   75     9   9
133    24     259  9.7   73     9  10
134    44     236 14.9   81     9  11
135    21     259 15.5   76     9  12
136    28     238  6.3   77     9  13
137     9      24 10.9   71     9  14
138    13     112 11.5   71     9  15
139    46     237  6.9   78     9  16
140    18     224 13.8   67     9  17
141    13      27 10.3   76     9  18
142    24     238 10.3   68     9  19
143    16     201  8.0   82     9  20
144    13     238 12.6   64     9  21
145    23      14  9.2   71     9  22
146    36     139 10.3   81     9  23
147     7      49 10.3   69     9  24
148    14      20 16.6   63     9  25
149    30     193  6.9   70     9  26
150    NA     145 13.2   77     9  27
151    14     191 14.3   75     9  28
152    18     131  8.0   76     9  29
153    20     223 11.5   68     9  30
```

Data frames
========================================================

We can explore the data with the functions

```r
dim(airquality)
```

```
[1] 153   6
```

```r
head(airquality)
```

```
  Ozone Solar.R Wind Temp Month Day
1    41     190  7.4   67     5   1
2    36     118  8.0   72     5   2
3    12     149 12.6   74     5   3
4    18     313 11.5   62     5   4
5    NA      NA 14.3   56     5   5
6    28      NA 14.9   66     5   6
```

Data frames
========================================================

We think of data frames as multiple data that has been collected for a set of objects, individuals, locations, items, etc. The objects are in rows and the variables in columns. 

The names of the variables are obtained with <code>names()</code>

```r
names(airquality)
```

```
[1] "Ozone"   "Solar.R" "Wind"    "Temp"    "Month"   "Day"    
```

Data frames
========================================================

The values of each variable can be retrieved with the dollar function "<code>$</code>" 

(Note: NA are non-recorded/missing values)


```r
airquality$Ozone
```

```
  [1]  41  36  12  18  NA  28  23  19   8  NA   7  16  11  14  18  14  34   6
 [19]  30  11   1  11   4  32  NA  NA  NA  23  45 115  37  NA  NA  NA  NA  NA
 [37]  NA  29  NA  71  39  NA  NA  23  NA  NA  21  37  20  12  13  NA  NA  NA
 [55]  NA  NA  NA  NA  NA  NA  NA 135  49  32  NA  64  40  77  97  97  85  NA
 [73]  10  27  NA   7  48  35  61  79  63  16  NA  NA  80 108  20  52  82  50
 [91]  64  59  39   9  16  78  35  66 122  89 110  NA  NA  44  28  65  NA  22
[109]  59  23  31  44  21   9  NA  45 168  73  NA  76 118  84  85  96  78  73
[127]  91  47  32  20  23  21  24  44  21  28   9  13  46  18  13  24  16  13
[145]  23  36   7  14  30  NA  14  18  20
```

Data frames
========================================================
A data subset of selected variables can be extracted applying the extractor function <code>[]</code> on one vector parameter 


```r
airquality[c("Ozone","Day")]
```

```
    Ozone Day
1      41   1
2      36   2
3      12   3
4      18   4
5      NA   5
6      28   6
7      23   7
8      19   8
9       8   9
10     NA  10
11      7  11
12     16  12
13     11  13
14     14  14
15     18  15
16     14  16
17     34  17
18      6  18
19     30  19
20     11  20
21      1  21
22     11  22
23      4  23
24     32  24
25     NA  25
26     NA  26
27     NA  27
28     23  28
29     45  29
30    115  30
31     37  31
32     NA   1
33     NA   2
34     NA   3
35     NA   4
36     NA   5
37     NA   6
38     29   7
39     NA   8
40     71   9
41     39  10
42     NA  11
43     NA  12
44     23  13
45     NA  14
46     NA  15
47     21  16
48     37  17
49     20  18
50     12  19
51     13  20
52     NA  21
53     NA  22
54     NA  23
55     NA  24
56     NA  25
57     NA  26
58     NA  27
59     NA  28
60     NA  29
61     NA  30
62    135   1
63     49   2
64     32   3
65     NA   4
66     64   5
67     40   6
68     77   7
69     97   8
70     97   9
71     85  10
72     NA  11
73     10  12
74     27  13
75     NA  14
76      7  15
77     48  16
78     35  17
79     61  18
80     79  19
81     63  20
82     16  21
83     NA  22
84     NA  23
85     80  24
86    108  25
87     20  26
88     52  27
89     82  28
90     50  29
91     64  30
92     59  31
93     39   1
94      9   2
95     16   3
96     78   4
97     35   5
98     66   6
99    122   7
100    89   8
101   110   9
102    NA  10
103    NA  11
104    44  12
105    28  13
106    65  14
107    NA  15
108    22  16
109    59  17
110    23  18
111    31  19
112    44  20
113    21  21
114     9  22
115    NA  23
116    45  24
117   168  25
118    73  26
119    NA  27
120    76  28
121   118  29
122    84  30
123    85  31
124    96   1
125    78   2
126    73   3
127    91   4
128    47   5
129    32   6
130    20   7
131    23   8
132    21   9
133    24  10
134    44  11
135    21  12
136    28  13
137     9  14
138    13  15
139    46  16
140    18  17
141    13  18
142    24  19
143    16  20
144    13  21
145    23  22
146    36  23
147     7  24
148    14  25
149    30  26
150    NA  27
151    14  28
152    18  29
153    20  30
```


Data frames
========================================================
We can use the extractor like in a matrix <code>[,]</code> with two parameters (comma).

These are the fist 10 observations (locations) for the variables 2 and 5

```r
airquality[1:10,c(2,5)]
```

```
   Solar.R Month
1      190     5
2      118     5
3      149     5
4      313     5
5       NA     5
6       NA     5
7      299     5
8       99     5
9       19     5
10     194     5
```


Data frames
========================================================

Or select the data for months greater or equal than August


```r
sel <- airquality$Month>=8
AugustNovAir <- airquality[sel,]
AugustNovAir
```

```
    Ozone Solar.R Wind Temp Month Day
93     39      83  6.9   81     8   1
94      9      24 13.8   81     8   2
95     16      77  7.4   82     8   3
96     78      NA  6.9   86     8   4
97     35      NA  7.4   85     8   5
98     66      NA  4.6   87     8   6
99    122     255  4.0   89     8   7
100    89     229 10.3   90     8   8
101   110     207  8.0   90     8   9
102    NA     222  8.6   92     8  10
103    NA     137 11.5   86     8  11
104    44     192 11.5   86     8  12
105    28     273 11.5   82     8  13
106    65     157  9.7   80     8  14
107    NA      64 11.5   79     8  15
108    22      71 10.3   77     8  16
109    59      51  6.3   79     8  17
110    23     115  7.4   76     8  18
111    31     244 10.9   78     8  19
112    44     190 10.3   78     8  20
113    21     259 15.5   77     8  21
114     9      36 14.3   72     8  22
115    NA     255 12.6   75     8  23
116    45     212  9.7   79     8  24
117   168     238  3.4   81     8  25
118    73     215  8.0   86     8  26
119    NA     153  5.7   88     8  27
120    76     203  9.7   97     8  28
121   118     225  2.3   94     8  29
122    84     237  6.3   96     8  30
123    85     188  6.3   94     8  31
124    96     167  6.9   91     9   1
125    78     197  5.1   92     9   2
126    73     183  2.8   93     9   3
127    91     189  4.6   93     9   4
128    47      95  7.4   87     9   5
129    32      92 15.5   84     9   6
130    20     252 10.9   80     9   7
131    23     220 10.3   78     9   8
132    21     230 10.9   75     9   9
133    24     259  9.7   73     9  10
134    44     236 14.9   81     9  11
135    21     259 15.5   76     9  12
136    28     238  6.3   77     9  13
137     9      24 10.9   71     9  14
138    13     112 11.5   71     9  15
139    46     237  6.9   78     9  16
140    18     224 13.8   67     9  17
141    13      27 10.3   76     9  18
142    24     238 10.3   68     9  19
143    16     201  8.0   82     9  20
144    13     238 12.6   64     9  21
145    23      14  9.2   71     9  22
146    36     139 10.3   81     9  23
147     7      49 10.3   69     9  24
148    14      20 16.6   63     9  25
149    30     193  6.9   70     9  26
150    NA     145 13.2   77     9  27
151    14     191 14.3   75     9  28
152    18     131  8.0   76     9  29
153    20     223 11.5   68     9  30
```

Lists
========================================================

They are collections of variables of different class and are constructed by the function <code>list()</code>


```r
#a matrix
mat <- cbind(c(2,4,6),c(1,2,3)) 
#a vector
vec <- c(TRUE,FALSE)
#a character
chr <- "hello"
#the list
L <- list(M=mat, V=vec, C=chr)
```

Lists
========================================================

```r
L
```

```
$M
     [,1] [,2]
[1,]    2    1
[2,]    4    2
[3,]    6    3

$V
[1]  TRUE FALSE

$C
[1] "hello"
```


Lists
========================================================

Each component of the list is called a field and can be selected with the dollar function "<code>$</code>"


```r
names(L)
```

```
[1] "M" "V" "C"
```

```r
L$M
```

```
     [,1] [,2]
[1,]    2    1
[2,]    4    2
[3,]    6    3
```

Lists
========================================================
Or we can use the double squared braquet function <code>[[]]</code>


```r
L[[1]]
```

```
     [,1] [,2]
[1,]    2    1
[2,]    4    2
[3,]    6    3
```

Lists
========================================================

We can change the names of the fields


```r
names(L)<-c("data","output","message")
L
```

```
$data
     [,1] [,2]
[1,]    2    1
[2,]    4    2
[3,]    6    3

$output
[1]  TRUE FALSE

$message
[1] "hello"
```


Importing and exporting data
========================================================

Important: download the file "dat1.txt" and make sure that R is running on the directory where you downloaded the file. 

To select the directory where R is running:
- Select: Session in the upper menu bar of RStudio
- Select: Set Working Directory
- Select: Choose Directory...

or just press [Ctrl+Shift+H]

- and then select the directory and press open.



Importing and exporting data
========================================================

Data are usually found in text files.
Data from a text file are read into data.frames in R with the function <code>read.table()</code>.


```r
dat <- read.table("dat1.txt")
dat[1:5,]
```

```
  V1 V2  V3
1  x  y fac
2  1  1   B
3  1  2   A
4  1  3   B
5  1  4   B
```

Importing and exporting data
========================================================

However, we want the first line of the text file to be read as the names of the variables in the data frame


```r
names(dat)
```

```
[1] "V1" "V2" "V3"
```

Check the multiple options by inspecting R documentation <code>?read.table</code>

Importing and exporting data
========================================================

We use <code>header=TRUE</code>

```r
dat <- read.table("dat1.txt", header=TRUE)
names(dat)
```

```
[1] "x"   "y"   "fac"
```

```r
dat
```

```
   x  y fac
1  1  1   B
2  1  2   A
3  1  3   B
4  1  4   B
5  1  5   C
6  1  6   A
7  1  7   C
8  1  8   B
9  1  9   A
10 1 10   B
```

Importing and exporting data
========================================================

We can write a data frame as a text file using the function <code>write.table()</code>


```r
write.table(dat, file="myData.txt")
```

Open the results in a text editor. Check the multiple options by inspecting R documentation  <code>?write.table</code> to remove the quotes.


```r
write.table(dat, file="myData.txt", quote=FALSE)
```

Importing and exporting data
========================================================

Data can be saved in a binary file with an extension .RDta. Not only data.frames but any type of data structures like lists or those you define can be saved.


```r
dataTosave <- c(2, 5, 10, 1, 3)
save(dataTosave, file="myResults.RData")
```

Check that the new file is written in R working directory. 

Close R and set the working directory of R with [Ctrl+Shift+H] where myResults.RData is.

Importing and exporting data
========================================================

If you leave the R session and open a new one you can re-load the variable <code>dat</code> that is stored in myResults.RData


```r
load("myResults.RData")
dataTosave
```

```
[1]  2  5 10  1  3
```


