Statistical concepts with R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 5</p>

Objective
===================================

Probability density functions
- Normal distribution
- General distributions


Normal distriubtion
===================================
A random variable $X$ defined on the real numbers distributes nornally if it has a probability density distribution
</br>$f(x)=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma}}, x \in {\Bbb R}\nonumber$

When $X$ distributes normally we write
</br>$X\hookrightarrow N(\mu,\sigma^2)$

Normal distriubtion
===================================

When $X\hookrightarrow N(\mu,\sigma^2)$

- $X$ has mean $E(X)=\mu$
- and  variance $V(X)=\sigma^2$

$\mu$ y $\sigma^2$ are the parameters of the normal distribution that cioncide with its mean anf variance.

Normal distriubtion
===================================

In R, the function <code>dnorm</code> encodes the norall density functon, such that 
</br>$dnorm(x; \mu, \sigma)=\frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(x-\mu)^2}{2\sigma}}$

- Let's plot  $dnorm(x; \mu=0, \sigma=1)$ in the interval [-3,3]


```r
x <- seq(-3,3,0.0001) 
head(x)
```

```
[1] -3.0000 -2.9999 -2.9998 -2.9997 -2.9996 -2.9995
```

Normal distriubtion
===================================


```r
plot(x, dnorm(x,0,1), type="l", col="blue")
```

![plot of chunk unnamed-chunk-2](Lecture5-figure/unnamed-chunk-2-1.png)

Normal distriubtion
===================================
How would you do the next plot?

![plot of chunk unnamed-chunk-3](Lecture5-figure/unnamed-chunk-3-1.png)

Normal distriubtion
===================================

Hints:
- The green line in a normal density with  $\mu=0.5$  and $\sigma=1$
- The red line is a normal denstity  with $\mu=0$ and $\sigma=1.2$
- If you wan to add a curve to an existing plot, use the function <code>lines</code>

Normal distriubtion
===================================


```r
plot(x, dnorm(x,0,1), type="l", col="blue", ylab="f(x)")
lines(x, dnorm(x,0.5,1), type="l", col="red")
lines(x, dnorm(x,0,1.2), type="l", col="green")
```

![plot of chunk unnamed-chunk-4](Lecture5-figure/unnamed-chunk-4-1.png)


We name the axis using the parameters <code>xlab</code> and <code>ylab</code>

Normal distriubtion
===================================

The function <code>rnorm</code> simulates a random sample from a nromal distribution with mean $\mu$ and standard deviation $\sigma$

- If females have a mean height of $165cm$ with standard deviation $8cm$, and woman height distributes nromally, generate a random sample for the height of three women


```r
rnorm(n=3,mean=165,sd=8)
```

```
[1] 158.5109 156.3510 176.4349
```

- Can you do the histogram (<code>hist</code>) of 100 random women heights? 

Normal distriubtion
===================================


```r
altura <- rnorm(n=100,mean=165,sd=8)
hist(altura ,freq=FALSE)
```

![plot of chunk unnamed-chunk-6](Lecture5-figure/unnamed-chunk-6-1.png)

Normal distriubtion
===================================

How would you do this plot?

![plot of chunk unnamed-chunk-7](Lecture5-figure/unnamed-chunk-7-1.png)

Normal distriubtion
===================================

add <code>lines</code>


```r
hist(altura ,freq=FALSE)
x <- seq(130,200,0.001)
lines(x, dnorm(x,mean=165,sd=8), type="l", col="blue")
```


Normal distriubtion
===================================

In R, the function <code>pnorm</code> is the cumulative function for the normal distribution with mean $\mu$  and standard deviation $\sigma$, such that
</br>$pnorm(x,\sigma,\mu)= P(X \leq x) = \int_{-\infty}^x \frac{1}{\sqrt{2\pi}\sigma}e^{-\frac{(t-\mu)^2}{2\sigma}} dt$


For the **standard** density, thse are its values in the interval [-3,3]


```r
F <- pnorm(x,mean=165,sd=8)
head(F)
```

```
[1] 6.071624e-06 6.075104e-06 6.078586e-06 6.082070e-06 6.085556e-06
[6] 6.089044e-06
```

plot $F$

Normal distriubtion
===================================



```r
plot(x, F, type="l", col="red")
```

![plot of chunk unnamed-chunk-10](Lecture5-figure/unnamed-chunk-10-1.png)

Normal distriubtion
===================================

```r
pnorm(150,mean=165,sd=8)
```

```
[1] 0.03039636
```

The acumulated probability up to 150cm is 0.03, or, the 3% of women have heights less than $150cm$

Normal distriubtion
===================================

<code>qnorm</code> is the inverse function of <code>pnorm</code>; that is $F^{-1}(prob)=x$

Use <code>pnorm</code> and <code>qnorm</code>  to answer:

- What is the probability that a man's height is at least $165cm$, if the avergage of man height is $175cm$ its standard deviation $10cm$?
- What is the probabilityt that a man's heigh is between $165cm$  and $180cm$?
- Which is the maximum height that defines the 5% of the smallest men in the population?  

Normal distriubtion
===================================


```r
pnorm(165, mean=175, sd=10)
```

```
[1] 0.1586553
```

```r
pnorm(180, mean=175, sd=10) - pnorm(165, mean=175, sd=10)
```

```
[1] 0.5328072
```

```r
qnorm(0.05, mean=175, sd=10)
```

```
[1] 158.5515
```


Normal distriubtion
===================================

Data from COVID 19 death rates are published by the ministry of health [at]{https://covid19.isciii.es/}

Lets **assume** that the probability of dying in a particular day during the first days of the pandemia followed a normal distribution in Catalonia when quarantine restrictions were imposed. Given the data on the 10th of april, what was the proabability of dying after the 13 de abril when strong lockdown measures were going to be lifted?     



Normal distriubtion
===================================

Let's download the data and load it in R

```r
covid <- read.table("Covid19_9abril.csv", header=TRUE, sep=",")
head(covid)
```

```
  CCAA     FECHA CASOS Hospitalizados UCI Fallecidos Recuperados
1   AN 20/2/2020    NA             NA  NA         NA          NA
2   AR 20/2/2020    NA             NA  NA         NA          NA
3   AS 20/2/2020    NA             NA  NA         NA          NA
4   IB 20/2/2020     1             NA  NA         NA          NA
5   CN 20/2/2020     1             NA  NA         NA          NA
6   CB 20/2/2020    NA             NA  NA         NA          NA
```
Normal distriubtion
===================================

We select the data for Catalonia: rows in which the variable CCAA taked the value CT


```r
cat <- covid$CCAA=="CT"
covidCAT <- covid[cat,]
head(covidCAT)
```

```
    CCAA     FECHA CASOS Hospitalizados UCI Fallecidos Recuperados
9     CT 20/2/2020    NA             NA  NA         NA          NA
28    CT 21/2/2020    NA             NA  NA         NA          NA
47    CT 22/2/2020    NA             NA  NA         NA          NA
66    CT 23/2/2020    NA             NA  NA         NA          NA
85    CT 24/2/2020    NA             NA  NA         NA          NA
104   CT 25/2/2020     1             NA  NA         NA          NA
```

Normal distriubtion
===================================

We select the variable Fellecidos that is the obsolute cumulative frequency for each day and plot it

```r
Ni <- covidCAT$Fallecidos
plot(Ni, type="l", col="red")
```

![plot of chunk unnamed-chunk-15](Lecture5-figure/unnamed-chunk-15-1.png)


Normal distriubtion
===================================

We now retrieve the absolute frequency of deaths by day **ni**. **ni** fot the k-th day is the differences between the cumulative frequency in day k+1 and k: 
</br>$ni(k)=Ni(k+1)-Ni(K)$

we can do this differnces with the function <code>diff</code>

Normal distriubtion
===================================


```r
ni <- diff(Ni)
#we get rid of missings with complete.cases
ni <- ni[complete.cases(ni)]
#we check for how many days we have data
length(ni)
```

```
[1] 32
```

Normal distriubtion
===================================
We create the range of our random variable $X$ that is the day when a death occur


```r
x <- 1:32
names(ni) <- x
head(ni)
```

```
1 2 3 4 5 6 
1 0 1 2 0 2 
```

Normal distriubtion
===================================
Let's do a barplot

```r
barplot(ni)
```

![plot of chunk unnamed-chunk-18](Lecture5-figure/unnamed-chunk-18-1.png)

Normal distriubtion
===================================

Let's compute the relative frequency **fi** from **ni**


```r
fi <- ni/sum(ni) 
names(fi) <- x
head(fi)
```

```
           1            2            3            4            5            6 
0.0003096934 0.0000000000 0.0003096934 0.0006193868 0.0000000000 0.0006193868 
```

What is the mean and the variance of $f$?

Normal distriubtion
===================================

Let's remember that $f_i$ are the frequencies of **data** these can also be computed as (Theory lecture 1)
</br> $\bar{x}=\sum_i^m x_i f_i$
</br> $s^2=\sum_i^m (x_i-\bar{x})^2 f_i$

Remember that in the frequentist limit $f_i \rightarrow P(X=x_i)$ when $n \rightarrow \infty$, and therefore we recover the mean and variace of the random variable.

Normal distriubtion
===================================

for the data, computing the mean and standard deviation in terms of the frequencies

```r
mui <- sum(fi*x)
mui
```

```
[1] 22.17002
```

```r
sdi <- sqrt(sum(fi*(x -mui)^2))
sdi
```

```
[1] 5.35589
```

Normal distriubtion
===================================

- Note that $f_i$ are not direct observations on the random variable $X$ (day of the reported dath) for one random experiment (individual), $f_i$ are observationo fon the frequency of the outcomes of $X$. For observations on $X$ we use the functions <code>mean</code> and <code>sd</code>, while for $f_i$ we use the definitiond of the mean and variance of distributions assuming that for large $n$ we have $P(X=x_i)\sim f_i$

- We asume that the observations $f_i$ are obtained from a normal distribution with mean <code>mui</code>  and satndard deviation <code>sdi</code>.


Normal distriubtion
===================================
Let's plot $f_i$ with <code>barplot</code> and overlay the normal distribution we **estimated** from the data. We use the variable <code>xparaplot</code> to find the positions of the values of x in the barplot, it is a graphical parameter.



```r
xparaplot <- barplot(fi)
lines(xparaplot, dnorm(x,mui,sdi))
```

![plot of chunk unnamed-chunk-21](Lecture5-figure/unnamed-chunk-21-1.png)


Normal distriubtion
===================================
The day 12 of April was the 36th day of the COVID pandemia in Catalonia therefore the cumulative probability of deaths upt to that day would be


```r
pnorm(36,mui,sdi)
```

```
[1] 0.9950914
```


Normal distriubtion
===================================
The fraction of expected deaths after that day, had the confinement been kept indefenetly in place would have been


```r
1 - pnorm(36,mui,sdi)
```

```
[1] 0.004908634
```

This is the sort of analyses (while simplistic for our approach) that epidemiologist and  politicians faced on the 10th of April 2020. 

Normal distriubtion
===================================

Warning:
- This is an academic exercise with many issues
- Most likely the best way to predict deths is not by a normal distribution, as it does not go up an down at the same rate. 
- This is a dynamic process, posterior interventions and popylation behaviour dramatically affect the form of the curve.  
- If the models are nor correct the authorities can (and did) make important mistakes based on erroneous predictions. 
- Models critically depend  on data, if deaths are not (were not) counted accurately then no model will perform well. 
- No one can tell if a model is good or bad until the pandemic passes and we revise the decisions taken and how they affected the modeling.


General densisty distributions
===================================
Let's define the density distribution 
\[
    f(x)= 
\begin{cases}
    1/8+3/8*x,& \text{if} x\in (0,2)\\
    0,& resto 
\end{cases}
\]

We now wnat to generate a random sample of numbers that follow this distribution.

General densisty distributions
===================================
For the density
\[
    f(x)= 
\begin{cases}
    1/8+3/8*x,& \text{if } x\in (0,2)\\
    0,& resto 
\end{cases}
\]

let's define a sequence of data points in the interval where the density is not zero.



```r
x <- seq(0,2,0.0001) 
```

General densisty distributions
===================================
In the interval (0,2), the distribution is simply


```r
fx <- 1/8+3/8*x
```

We can plot it with <code>plot(..., type="l")</code>

General densisty distributions
===================================



```r
plot(x,fx,type="l", col="red")
```

![plot of chunk unnamed-chunk-26](Lecture5-figure/unnamed-chunk-26-1.png)

General densisty distributions
===================================

Now, let's take a sample of 100 random numbers with <code>sample</code>


```r
muestra <- sample(x, size=100,replace=TRUE, prob=fx)
```

In our interval each $x$ has a probaility to be drawn that is determined by the vector $fx$ defined by the denstity function.

- Draw the histogram of <code>muestra</code> and add the distribution <code>fx</code> using <code>lines(...)</code>

- what are the men and the standard deviation of <code>muestra</code>? 

General densisty distributions
===================================

```r
hist(muestra,freq=FALSE)
lines(x, fx, col="red")
```

![plot of chunk unnamed-chunk-28](Lecture5-figure/unnamed-chunk-28-1.png)


General densisty distributions
===================================

```r
mean(muestra)
```

```
[1] 1.220355
```

```r
sd(muestra)
```

```
[1] 0.5200806
```

General densisty distributions
===================================

Let's define a function in R for the density
\[
    f(x)= 
\begin{cases}
    1/8+3/8*x,& \text{if } x\in (0,2)\\
    0,& resto 
\end{cases}
\]

on all the values of $x$, including those $x\notin (0,2)$

General densisty distributions
===================================

Let's define the density like the function 

```r
f<-function(x)
 { 
    out <- 1/8+3/8*x
    out
  }
```

then 


```r
f(0.5)
```

```
[1] 0.3125
```

General densisty distributions
===================================
The function is vectorial 

```r
f(c(-1,0.5,3))
```

```
[1] -0.2500  0.3125  1.2500
```

but note that we want $f(-1)=0$ and $f(3)=0$. We wnat that $f(x)$ returns zero when  $x\leq 0$ o $x\geq2$. So we will set to zero when those cases happen.


General densisty distributions
===================================


```r
f<-function(x)
 { 
    out<-1/8+3/8*x
    out[x<=0]<-0
    out[x>=2]<-0
    out
  }
```


```r
f(c(-1,0.5,3))
```

```
[1] 0.0000 0.3125 0.0000
```


General densisty distributions
===================================

Plot $f$ in the interval wider interval [-1,3]


```r
x <- seq(-1,3,0.0001) 
```

General densisty distributions
===================================

```r
plot(x, f(x), type="l", col="blue")
```

![plot of chunk unnamed-chunk-36](Lecture5-figure/unnamed-chunk-36-1.png)


General densisty distributions
===================================
Now let's produce a random sample of 1000 numbers that distribute  following the density  $f(x)$


```r
fx <- f(x)
sm <- sample(x, size=1000, replace=TRUE, prob=fx)
head(sm)
```

```
[1] 1.6084 1.2551 1.7206 1.9617 0.7496 1.6755
```

Now, plot a histogram of <code>sm</code> and add the values of $f(x)$ to it using <code>lines</code>

General densisty distributions
===================================


We only need <code>sm</code>, <code>x</code> and </code>fx</code>


```r
hist(sm,freq=FALSE, ylim=c(0,1),xlim=c(-1,3))
lines(x, fx, col="blue")
```

![plot of chunk unnamed-chunk-38](Lecture5-figure/unnamed-chunk-38-1.png)


General densisty distributions
===================================

Teh cumulative probability function for $f(x)$ is obtained from 
</br>$F(x)= P(X \leq x) = \int_{0}^t 1/8+3/8*t dt$

and in the entire real line
\[
    F(x)= 
\begin{cases}
   1/8*x+3/16*x^2,& \text{if } x\in (0,2)\\
    0,& resto 
\end{cases}
\]

Make a function for $F(x)$ and plot it

General densisty distributions
===================================


```r
F<-function(x)
{
    out<-1/8*x+3/16*x^2
    out[x<=0]<-0 
    out[x>=2]<-1 
    out
}
```


General densisty distributions
===================================


```r
plot(x, F(x), type="l", col="red")
```

![plot of chunk unnamed-chunk-40](Lecture5-figure/unnamed-chunk-40-1.png)

Exercise: 
===================================

Plot the density in a wide interval 
\[
    f(x)= 
\begin{cases}
   \frac{4}{\pi(1+x^2)},& \text{if } x\in (0,1)\\
    0,& resto 
\end{cases}
\]

- take a random sample of 10000 numbers that distribute acording to $f(x)$ and compare its histogram with the probability density. 
- plot the cumulative probability function 
- what is the probability $P(0.4 \leq X \leq 0.6)$?


Answer: 
===================================


```r
f<-function(x)
{   out<-4/(pi*(1+x^2))
    out[x<=0]<-0
    out[x>=1]<-0
    out
}
```



Answer: 
===================================


```r
x <- seq(-1,3,0.0001) 
plot(x, f(x), type="l", col="blue")
```

![plot of chunk unnamed-chunk-42](Lecture5-figure/unnamed-chunk-42-1.png)

Answer: 
===================================


```r
xsam <- seq(-1,3,0.01)
sm<-sample(xsam, size=10000, replace=TRUE, prob=f(xsam))
hist(sm,freq=FALSE, ylim=c(0,2),xlim=c(-1,3))
lines(x, f(x), col="blue")
```

![plot of chunk unnamed-chunk-43](Lecture5-figure/unnamed-chunk-43-1.png)


Answer: 
===================================

```r
F<-function(x)
{
    out<-4*atan(x)/pi
    out[x<=0]<-0 
    out[x>=1]<-1 
    out
}
```


Answer: 
===================================

```r
plot(x, F(x), type="l", col="red")
```

![plot of chunk unnamed-chunk-45](Lecture5-figure/unnamed-chunk-45-1.png)

Answer: 
===================================



```r
F(0.6) - F(0.4)
```

```
[1] 0.2036077
```



