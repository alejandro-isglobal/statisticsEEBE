Statistical concepts with R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 4</p>

Objective
===================================

Study probability mass functions of discrete variables.

- General probability mass functions
- Beronulli trials  
- Binomial distribution

R Objective
===================================

- Simulate data 
- R functions
- Loops
- Use functions for probility caculus

Dice
===================================

The probability mass function for the sum of two dice (a,b) is
\[
    f(x)= 
\begin{cases}
    1/36,& \text{si } x=2 (a:1,b:1),12 (a:6,b:6) \\
    2/36,& \text{si } x=3,11 \\
    3/36,& \text{si } x=4,10 \\
    4/36,& \text{si } x=5,9 \\
    5/36,& \text{si } x=6,8 \\
    6/36,& \text{si } x=7 \\
\end{cases}
\]

Dice
===================================
Let's define the vectors

```r
x <- seq(2,12)
fx <- c(1,2,3,4,5,6,5,4,3,2,1)/36
#podemos darle nombres los valores fx
names(fx) <- x
fx
```

```
         2          3          4          5          6          7          8 
0.02777778 0.05555556 0.08333333 0.11111111 0.13888889 0.16666667 0.13888889 
         9         10         11         12 
0.11111111 0.08333333 0.05555556 0.02777778 
```


Dice
===================================

What is the probability that the throw of a pair of dice results in a pair number?


Dice
===================================


- Draw the distribution with <code>plot(..., type="p", pch=16)</code>
- add the lines with <code>lines()</code>

For one line: 

```r
lines(c(x[2],x[2]),c(0,fx[2]),col="red")
```

For all 11 lines (length of $x$) do a loop with <code>for()</code>

```r
for(i in 1:11)
{ lines(c(x[i], x[i]), c(0, fx[i])) }
```

Dice
===================================
Can you obtain
![plot of chunk unnamed-chunk-4](Lecture4-figure/unnamed-chunk-4-1.png)

Dice
===================================

- What is the mean of f(x)?
$\mu=\sum_i x_i f(x_i)$

Use <code>sum</code> and the multiplication between vectors. Assign the result to the variable <code>mu</code>

- What is the variance of f(x)?
$$\sigma^2=\sum_i (x_i-\mu)^2 f(x_i)$$


Dice
===================================

- What is the median of f(x)?
$F(x)=Pr(x \leq mediana)=0.5$

- Compute the relative cumulative frequency use <code>cumsum</code> on <code>fx</code> and assign the result to <code>F</code>. Wheere is the the 50% of the probability? 

Sum half of the probability at 7 to the cumulative frequency at 7. How much accumulated frequency you obtain?

Dice
===================================

How ca we throw dice in R?

- We will simulate the result of suming one throw of two dice



```r
lanzamiento <- sample(x, size=1, prob=fx, 
                      replace=TRUE) 
lanzamiento
```

```
[1] 7
```

Which parameter do you have to change to sumulate the result of theowing the dice 100 times? assigns the results ot the variabel <code>lanzamientos</code>

Dice
===================================

Let´s draw the histogram of  <code>lanzamientos</code>, use the parameter <code>freq=FALSE</code> for displaying the relative frequency and the parameter <code>breaks=seq(1.5, 12.5)</code> tocenter the bars in each value of $x$


<code>hist(lanzamientos,  freq=FALSE,  breaks=seq(1.5, 12.5))</code> 
}

add the points of the distribution with 
<code>points(x, fx, pch=16, col="red")</code> 
and the lines with 

```r
for(i in 1:11) 
{lines(c(x[i],x[i]), c(0,fx[i]), col="red")}
```


Dice
===================================

![plot of chunk unnamed-chunk-7](Lecture4-figure/unnamed-chunk-7-1.png)
 
 
Dice
===================================

Now we are dealing with **data**

- What is the average (mean) of the <code>lanzamientos</code>?
- what is the variance of <code>lanzamientos</code>?
- what is the median of <code>lanzamientos</code>?

remamber the function 
Recuerda funciones <code>mean</code>, <code>sd()^2</code> and <code>median</code>.

are the data and distribution means, variances and medians equall? why?


Bernoulli
===================================

The simplest case of a probability model for a discrete variable if the Bernulli trial where there is only two possible outcomes (A and B)

- outcome A (k=1) has probability $p$
- outcome B (k=0) has probability $q=1-p$

The Bernulli probability mass function is
</br>$f(k)=(1-p)^{1-k} p^k$

The toss of a coin if a Bernulli trial with $p=1/2$

Bernoulli
===================================


The Bernulli probability mass function
</br>$f(k)=(1-p)^{1-k} p^k$

has mean 
</br>$E(x)=\mu=p$

and variance
</br>$V(X)=\sigma^2=p(1-p)$

Bernoulli
===================================

<img src="./figures/ber.JPG" style="width:50%"  align="center">

Bernoulli
===================================

Let's consider a system where the proabability to erroneously transmit a pixel is $p=0.2$ (error:k=1) and to correctly transmit a pixel is $0.8$  (correct:k=0)  
\[
    f(k)= 
\begin{cases}
    0.8,& \text{if } k=0 \\
    0.2,& \text{if } k=1\\
\end{cases}
\]

Bernoulli
===================================

assign to <code>k</code> the vector $c(0,1)$ and to <code>fk</code> the vector $(0.8,0.2)$, then transmit a picture of 100 pixels using




```r
foto <- sample(k, size=100, prob=fk, 
replace=TRUE)
foto
```

```
  [1] 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 0 1 0 1 1 0 1 0 0 0 1 0 1
 [38] 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
 [75] 0 0 0 0 0 0 0 0 1 0 1 0 0 0 0 0 0 1 0 0 0 1 0 0 0 0
```



Bernoulli
===================================

-usa <code>hist</code> like before but add <code> ylim=c(0,1)</code> to the limits of the y axis; modify the parameter <code>breaks</code> to match the new values of $k$.
- use <code>points</code> like before
- ise <code>lines</code> with the <code>for</code> loop but changing when the the loop stops.

Bernoulli
===================================


can you obtain?

<img src="./figures/pixels.JPG" style="width:30%"  align="center">

Bernoulli
===================================
How close the the median and variance of the data to those of the distribution?

- Remember the that the median of a Bernulli trial is </br>$\mu=p=0.2$ 
</br>and its variance  
</br>$\sigma^2=p*(1-p)=0.16$

Binomial
===================================

The Binomial distribution is the probability mass function of observing $x$ events of type A with a probability $p$ in $n$ Bernoulli trials.
</br>$Bin(x; n,p)=\binom n x p^x(1-p)^{n-x}$ for $x=0,1,...n$
</br>where 
- $E(X)=\mu=np$
- $V(X)=\sigma^2=np(1-p)$

Binomial
===================================

<img src="./figures/foto.JPG" style="width:50%"  align="center">

Binomial
===================================

Let's send a a 100-pixel picture composed of all white pixels. Let's send the picture on our transmission system, where there is error of 2% per pixel.


```r
foto <- sample(x=c(0,1),size=100, prob=fk, replace=TRUE)
foto
```

```
  [1] 0 0 0 0 1 0 1 0 0 0 0 1 0 1 0 0 1 0 0 0 0 1 0 0 0 0 0 0 1 0 1 0 0 0 0 0 1
 [38] 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 0 0 1 0 0 0
 [75] 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 1 0 0 1 0 0
```

Binomial
===================================

Now let's count how many times a black pixel (error) appears at the end of the transmissio. ($x$=number of errors).


```r
sum(foto)
```

```
[1] 18
```

This is the number of error that this particular picture had. 

Binomial
===================================

What is the probability of sending one 100-picture with no error, or with 1 error, or with 2 errors, .... 12 errors, .... 100 errors? $Pr(x=0)$, Pr(x=1), ... Pr(x=100)?


- We then have to send many 100-pixel pictures (i.e. 1000) and count how maby have 0 errors, 1 error, 2 errors, .... 100 errors ($fr(x=0)$, $fr(x=1)$, ... $fr(x=100)$)

Binomial
===================================
<img src="./figures/fotos.JPG" style="width:50%"  align="center">



Binomial
===================================

Let's do a function that simulate the erros in sending 100-pixel pictures, when the probability of error per pixel is 2% (k=1 in a Bernoulli trial)


```r
enviar <- function(...)
{
   foto <- sample(c(0,1),size=100, 
                  replace=TRUE,prob=fk)
   sum(foto)
}
```

the tree points mean that no matter what the argument in the function is, <code>enviar</code> will allways do the same. 

Binomial
===================================


```r
enviar()
```

```
[1] 21
```

```r
enviar(1)
```

```
[1] 28
```

```r
enviar(1)
```

```
[1] 24
```

```r
enviar("hola")
```

```
[1] 19
```

Binomial
===================================

Everytime we call <code>enviar</code> with any argument it will send a 100-pixel picture and count the pixels with errors. 

Binomial
===================================
We can now simulate the errors produced when we send  three 100-pixel pictures

```r
c(enviar(1), enviar(1), enviar(1))
```

```
[1] 16 26 14
```

In R this can be also done with <code>sapply</code>

```r
Tresfotos <- sapply(rep(1,3), enviar)
Tresfotos
```

```
[1] 21 20 16
```

Binomial
===================================
Simulate the erros when we send 1000 pictures, each with 100 pixels. Assign its result to <code>Milfotos</code> and draw ots histogram.




Binomial
===================================
Can you obtain?

<img src="./figures/binhist.JPG" style="width:35%"  align="center">


Binomial
===================================
As before:

- use <code>hist</code> like before but include the parameter <code>ylim=c(0,0.15)</code>  as the limits of the y axis; change the parameter <code>breaks</code> to account fo the new values of $x$, <code>breaks=seq(1.5, 100.5)</code>; use <code>xlim=c(0,40)</code> as the limits of the x axis.


Binomial
===================================

- What are the mean (<code>mean</code>) and the variance (<code>sd$()^2$</code>) of <code>Milfotos</code>?

Are they equallto the mean and variance of the binomial distribution? how they do differ
- $E(X)=\mu=np=100*0.2=20$
- $V(X)=\sigma=np(1-p)=10*0.3*0.7=16$


Binomial
===================================

How close is the histogram of <code>Milfotos</code> to the binomial probability funtion?

- We need the values of the binomial distribution
for $n=100$ y $p=0.2$. We can obtain them with <code>dbinom</code>.
</br>$Bin(x; n,p)$ en R es <code>dbinom(x, size=n, prob=p)</code>



```r
x <- 0:100
binomial <- dbinom(x, size=100, prob=0.2)
names(binomial) <- x
head(binomial)
```

```
           0            1            2            3            4            5 
2.037036e-10 5.092590e-09 6.302080e-08 5.146699e-07 3.120186e-06 1.497689e-05 
```
Binomial
===================================


```r
hist(Milfotos,breaks=seq(1.5,100.5), 
freq=FALSE, ylim=c(0,0.15), xlim=c(0,40))

points(x, binomial, pch= 16, col="red")

for(i in 1:101)
{lines(c(x[i], x[i]), c(0, binomial[i]), 
  col="red")}
```


Binomial
===================================

![plot of chunk unnamed-chunk-19](Lecture4-figure/unnamed-chunk-19-1.png)

Binomial
===================================
Using the <code>dbinom</code> answer:
- What is the probability for reciecing 5 errors in the transmission of a 50-pixel picturew with error probability per pixel $p=0.1$? (R/ 0.1849246)

- What is the proability that exactly one error is sent in a picture of 3.1 megapixels, when the error per pixel is $1e-6$?  (R/ 0.1396525)

Binomial
===================================

In R the function <code>pbinom</code> is the cumulative probability function for the binomial distribution $F_{bin}(x; n, p)$

</br>$F_{bin}(x; n, p)$ in R is <code>pbinom(x, size=n, prob=p)</code>



```r
binCum <- pbinom(x, size=100, prob=0.2)
binCum
```

```
  [1] 2.037036e-10 5.296294e-09 6.831709e-08 5.829870e-07 3.703173e-06
  [6] 1.868007e-05 7.796360e-05 2.769869e-04 8.553984e-04 2.333561e-03
 [11] 5.696381e-03 1.257488e-02 2.532875e-02 4.691224e-02 8.044372e-02
 [16] 1.285055e-01 1.923376e-01 2.711890e-01 3.620871e-01 4.601614e-01
 [21] 5.594616e-01 6.540332e-01 7.389328e-01 8.109128e-01 8.686468e-01
 [26] 9.125246e-01 9.441673e-01 9.658484e-01 9.799798e-01 9.887510e-01
 [31] 9.939407e-01 9.968703e-01 9.984496e-01 9.992631e-01 9.996639e-01
 [36] 9.998529e-01 9.999381e-01 9.999750e-01 9.999903e-01 9.999964e-01
 [41] 9.999987e-01 9.999996e-01 9.999999e-01 1.000000e+00 1.000000e+00
 [46] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [51] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [56] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [61] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [66] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [71] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [76] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [81] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [86] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [91] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
 [96] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
[101] 1.000000e+00
```

Binomial
===================================


```r
plot(x, binCum, ylim=c(0,1), type="s",
       col="red", ylab="F(x)", xlab="x")
```

![plot of chunk unnamed-chunk-21](Lecture4-figure/unnamed-chunk-21-1.png)


Binomial
===================================
- What is the probability that there is at **least one** error in the when sending a 3,1 mega pixel picture and the error per pixel is $1e-6$?  (R/ 0.1847016)


Geometric distribution
===================================
The geometric distribution assigns a proability to the number of events ($x$) of a type (B) that occur before andother event of type (A) occur with proability $p$ and A and B are events of a Bernulli distribution. 
</br>$P(X=x)=f(x)=(1-p)^{x}p,$$ $x=0,1,2,...$

Its mean and variance are
</br>$E(X)= \mu =\frac{1-p}{p}$ y $V(X)= \sigma^2 =\frac{1-p}{p^2}$

Geometric distribution
===================================

What is the probability of receiving 0 correct pixels, 1 correct pixel, 2 correct pixels ... 100 correct pixeles 
before an error is recieved?  $Pr(x=0)$, $Pr(x=1)$, ... $Pr(x=100)$?

- We have to sent many 100-pixel pictures (i.e. 1000) and coutn the number of zeros before the first 1.

Geometric distribution
===================================

<img src="./figures/fotos2.JPG" style="width:50%"  align="center">

Geometric distribution
===================================

Let's send one picture:

- 100 Bernoulli trials ($p=0.2$) 


```r
foto <- sample(c(0,1),100, replace=TRUE, prob=fk)
foto
```

```
  [1] 0 0 0 0 0 0 0 0 1 0 1 0 0 0 0 0 1 1 0 0 0 0 1 1 0 0 0 0 0 0 0 0 1 0 1 0 0
 [38] 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 1 0 0 0 0
 [75] 0 0 0 0 1 0 0 1 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 1
```
Geometric distribution
===================================

- Now, identify the how many zeros occur before the first 1 appears.

With the funtion <code>which</code> we obstin the positions (index) of th elements of a vector that satisfy one condition. Our condition is that the element of the vector is equal (<code>==</code>) to 1


```r
which(foto==1)
```

```
 [1]   9  11  17  18  23  24  33  35  42  46  49  53  68  70  79  82  85  98 100
```

Geometric distribution
===================================

If we assign to the variable <code>ones</code> the result of  <code>which</code>, What is the position of the last zero?

Geometric distribution
===================================
Let's put everything together

The following code sends 100 white pixels and counts the number of white pixels recieved (correct) before the first black one (error). We assign the result to the variable <code>lastzero</code>.

```r
foto <- sample(c(0,1),100, replace=TRUE, prob=fk)
ones <- which(foto==1)
firstone <- ones[1]  
lastzero <- firstone-1
lastzero
```

```
[1] 7
```

Geometric distribution
===================================
This is only one picture. Can we send 1000 pictures and make a histogram?

- We make a function that we call <code>enviar</code>. This function sends and counts the number of pixels correcly sent until the first error appears


```r
enviar <- function(x)
          {
             foto <- sample(c(0,1),100, 
                      replace=TRUE, prob=fk)
             ones <- which(foto==1)
             firstone <- ones[1]  
             lastzero <- firstone-1
             lastzero
          }   

enviar()
```

```
[1] 6
```

Geometric distribution
===================================

- We make a for loop on 1000 iterations with the function <code>sapply</code>


```r
Milfotos <- sapply(rep(1,1000), enviar)
head(Milfotos)
```

```
[1]  3  2  3 36  2  1
```

Geometric distribution
===================================

the mean and variance of <code>Milfotos</code>
are

```r
mean(Milfotos)
```

```
[1] 3.883
```

```r
sd(Milfotos)^2
```

```
[1] 21.13044
```
While the mean and variance of the geometric distribution are
</br>$E(X) =\frac{1-p}{p}=4$ y $V(X)= \frac{1-p}{p^2}=20$

Geometric distribution
===================================

In R the gemetric distribution is given by the function <code>dgeom</code> whose values can be compared with the histogram of the simulated data. 

```r
hist(Milfotos,breaks=seq(-0.5,100.5), 
     freq=FALSE, ylim=c(0,0.25), xlim=c(0,40))

geom <- dgeom(x, prob=0.2)
points(x, geom, pch= 16, col="red")
for(i in 1:101)
  {lines(c(x[i], x[i]), c(0, geom[i]), col="red")}
```
Geometric distribution
===================================
![plot of chunk unnamed-chunk-29](Lecture4-figure/unnamed-chunk-29-1.png)

Negative binomial distribution
===================================
 Let's send a while pixel picture and count how many correcly pixels we could sned before 4 black pixels appeared ($r=4$). Imagine that we are tolerant to errors but only up to 4. 
 
-The number of correct pixels before the 4th error follow a negative binomial distribution  $NBin(x; r,p)$ which in R is <code>dnbinom(x, size=r, prob=p)</code>. 

Negative binomial distribution
===================================

Let's send a picture a see how many correct pixels we manage to send before 4 errors.


```r
fotos <- sample(c(0,1),100, replace=TRUE,prob=fk)
ones <- which(fotos==1)
fourthone <- ones[4]  
lastzero <- fourthone-1
#We get rid of the three previous errors
goodpixels <- lastzero-3
```

Negative binomial distribution
===================================
Let's make the function

```r
enviar <- function(x)
 {
 foto <- sample(c(0,1),100,
 replace=TRUE, prob=fk)
 ones <- which(foto==1)
 firstone <- ones[4]
 lastzero <- firstone-1
 goodpixels <- lastzero-3
 goodpixels
 }
```

Negative binomial distribution
===================================

send 1000 pictures

```r
Milfotos <- sapply(rep(1,1000), enviar)
```


Negative binomial distribution
===================================
and compare the histogram of the data with the mass probability fucntion 


```r
hist(Milfotos,breaks=seq(-0.5,100.5), 
 freq=FALSE, ylim=c(0,0.25), xlim=c(0,40))

nb <- dnbinom(x, size=4, prob=0.2)
points(x, nb, pch= 16, col="red")

for(i in 1:101)
 {lines(c(x[i], x[i]), c(0, nb[i]), 
   col="red")}
```


Negative binomial distribution
===================================


![plot of chunk unnamed-chunk-34](Lecture4-figure/unnamed-chunk-34-1.png)

