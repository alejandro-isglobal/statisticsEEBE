Statistical concepts with R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 3</p>

Objective
===================================


Concepts in linear regression 
- minimum squares 
- prediction

Problem
===================================

High ozone levels are toxic. Patients with asthma and chronic obstructive pulmonary disease are at increased risk of hospitalizations during days of high ozone levels. 

- Imagine you work in the national weather service (AEMET) and you are required to predict days with high levels of ozone, such that the service raises alarm on high ozone contamination. 
- at what temperature should you activate the alarm on ozone levels higher than 60?



Importing data
========================================================

Important: download the file <code>data.txt</code> and make sure that R is running on the directory where you downloaded the file. 

To select the directory where R is running:
- Select: Session in the upper menu bar of RStudio
- Select: Set Working Directory
- Select: Choose Directory...

or just press [Ctrl+Shift+H]

- and then select the directory and press open.



Importing data
========================================================

We use the function <code>read.table()</code> to read the downloaded file


```r
a <- read.table(file="data.txt", sep=";",
header=TRUE, na.string="NA")
```

Importing data
========================================================

We used the following parameters:

- <code>file="data.txt"</code> indicates the name of the file in quotation marks. 
- <code>sep=";"</code> indicates that the sparation between data  in the text has been done with semicolons ";" 
- <code>header=TRUE</code> indicates that the first line contains the names of the variables.
- <code>na.string="NA"</code> codifies "NA" strings as missing values <code>NA</code>.


Data
========================================================

In the variable <code>a</code> we thus loaded data on air quality stored in the text file. This is the data we used in lecture 2. 


```r
head(a)
```

```
  Ozone Solar.R Wind Temp Month Day
1    41     190  7.4   67     5   1
2    36     118  8.0   72     5   2
3    12     149 12.6   74     5   3
4    18     313 11.5   62     5   4
5    NA      NA 14.3   56     5   5
6    28      NA 14.9   66     5   6
```

Ozone
========================================================

Let's sumarize the variable Ozone <code>a$Ozone</code>. We obtian a categorical variable from ozone <code>dozone</code> whose values are bins or regular partitions of the ozone range. <code>seq</code> does the partition and <code>cut</code> assigns each value of ozone to it bin. 


```r
n <- min(a$Ozone, na.rm=TRUE) 
x <- max(a$Ozone, na.rm=TRUE)
s <- seq(n, x , length=10)
dozone <- cut(a$Ozone,breaks=s,right=FALSE)
dozone
```

```
  [1] [38.1,56.7) [19.6,38.1) [1,19.6)    [1,19.6)    <NA>        [19.6,38.1)
  [7] [19.6,38.1) [1,19.6)    [1,19.6)    <NA>        [1,19.6)    [1,19.6)   
 [13] [1,19.6)    [1,19.6)    [1,19.6)    [1,19.6)    [19.6,38.1) [1,19.6)   
 [19] [19.6,38.1) [1,19.6)    [1,19.6)    [1,19.6)    [1,19.6)    [19.6,38.1)
 [25] <NA>        <NA>        <NA>        [19.6,38.1) [38.1,56.7) [112,131)  
 [31] [19.6,38.1) <NA>        <NA>        <NA>        <NA>        <NA>       
 [37] <NA>        [19.6,38.1) <NA>        [56.7,75.2) [38.1,56.7) <NA>       
 [43] <NA>        [19.6,38.1) <NA>        <NA>        [19.6,38.1) [19.6,38.1)
 [49] [19.6,38.1) [1,19.6)    [1,19.6)    <NA>        <NA>        <NA>       
 [55] <NA>        <NA>        <NA>        <NA>        <NA>        <NA>       
 [61] <NA>        [131,149)   [38.1,56.7) [19.6,38.1) <NA>        [56.7,75.2)
 [67] [38.1,56.7) [75.2,93.8) [93.8,112)  [93.8,112)  [75.2,93.8) <NA>       
 [73] [1,19.6)    [19.6,38.1) <NA>        [1,19.6)    [38.1,56.7) [19.6,38.1)
 [79] [56.7,75.2) [75.2,93.8) [56.7,75.2) [1,19.6)    <NA>        <NA>       
 [85] [75.2,93.8) [93.8,112)  [19.6,38.1) [38.1,56.7) [75.2,93.8) [38.1,56.7)
 [91] [56.7,75.2) [56.7,75.2) [38.1,56.7) [1,19.6)    [1,19.6)    [75.2,93.8)
 [97] [19.6,38.1) [56.7,75.2) [112,131)   [75.2,93.8) [93.8,112)  <NA>       
[103] <NA>        [38.1,56.7) [19.6,38.1) [56.7,75.2) <NA>        [19.6,38.1)
[109] [56.7,75.2) [19.6,38.1) [19.6,38.1) [38.1,56.7) [19.6,38.1) [1,19.6)   
[115] <NA>        [38.1,56.7) <NA>        [56.7,75.2) <NA>        [75.2,93.8)
[121] [112,131)   [75.2,93.8) [75.2,93.8) [93.8,112)  [75.2,93.8) [56.7,75.2)
[127] [75.2,93.8) [38.1,56.7) [19.6,38.1) [19.6,38.1) [19.6,38.1) [19.6,38.1)
[133] [19.6,38.1) [38.1,56.7) [19.6,38.1) [19.6,38.1) [1,19.6)    [1,19.6)   
[139] [38.1,56.7) [1,19.6)    [1,19.6)    [19.6,38.1) [1,19.6)    [1,19.6)   
[145] [19.6,38.1) [19.6,38.1) [1,19.6)    [1,19.6)    [19.6,38.1) <NA>       
[151] [1,19.6)    [1,19.6)    [19.6,38.1)
9 Levels: [1,19.6) [19.6,38.1) [38.1,56.7) [56.7,75.2) ... [149,168)
```


Ozone
========================================================



```r
head(a$Ozone)
```

```
[1] 41 36 12 18 NA 28
```


```r
head(dozone)
```

```
[1] [38.1,56.7) [19.6,38.1) [1,19.6)    [1,19.6)    <NA>        [19.6,38.1)
9 Levels: [1,19.6) [19.6,38.1) [38.1,56.7) [56.7,75.2) ... [149,168)
```

Ozone
========================================================

We sumarize the values of <code>dozone</code> in absolute, relative and cumulative frequencies 

```r
ni <- table(dozone)
fi <- prop.table(ni)
Ni <- cumsum(ni)
Fi <- cumsum(fi)
tab <- cbind(ni,fi,Ni,Fi)
```

Ozone
========================================================


```r
tab
```

```
            ni          fi  Ni        Fi
[1,19.6)    33 0.286956522  33 0.2869565
[19.6,38.1) 35 0.304347826  68 0.5913043
[38.1,56.7) 15 0.130434783  83 0.7217391
[56.7,75.2) 11 0.095652174  94 0.8173913
[75.2,93.8) 12 0.104347826 106 0.9217391
[93.8,112)   5 0.043478261 111 0.9652174
[112,131)    3 0.026086957 114 0.9913043
[131,149)    1 0.008695652 115 1.0000000
[149,168)    0 0.000000000 115 1.0000000
```


Ozone
========================================================

Let's draw a histogram. The histogram is a plot for $n_i$!



```r
hist(a$Ozone)
```

![plot of chunk unnamed-chunk-8](Lecture3-figure/unnamed-chunk-8-1.png)


Ozone Vs Solar.R
========================================================

Let's explore the relationship between ozone and the other variables (Solar radiation and temperature)

- Use the function <code>plot</code> on the variables <code>a$Solar.R</code> and <code>a$Ozone</code> to visualize their functional relationship


Ozone Vs Solar.R
========================================================
In the first argument the values of the x-axis and in the second the values of the y-axis

```r
plot(a$Solar.R, a$Ozone)
```

![plot of chunk unnamed-chunk-9](Lecture3-figure/unnamed-chunk-9-1.png)

Ozone Vs Solar.R
========================================================
Or  <code>a$Ozone</code> as a function (<code>~</code>) of <code>a$Solar.R</code> 

```r
plot(a$Ozone~a$Solar.R)
```

![plot of chunk unnamed-chunk-10](Lecture3-figure/unnamed-chunk-10-1.png)


Ozone Vs other variables
========================================================

How are the plots for <code>a$Ozone</code> as function of the other varibles <code>a$Wind</code> and  <code>a$Temp</code>?

![plot of chunk unnamed-chunk-11](Lecture3-figure/unnamed-chunk-11-1.png)![plot of chunk unnamed-chunk-11](Lecture3-figure/unnamed-chunk-11-2.png)



all variables Vs all variables
========================================================


- inspect all the possible combinations of variables we use the function <code>pairs</code>


```r
pairs(a)
```

![plot of chunk unnamed-chunk-12](Lecture3-figure/unnamed-chunk-12-1.png)



Linear regression
========================================================

When we have observed the values of two variables in a random experiment and we have realized multiple repetitions of the experiment, we want to find whether the variables are statistically dependent.  

In our case, the realization of one random experiment is a line in <code>a</code>, where different variables were observed in a location on a given day. Repetitions of the experiment were carried out each day. Each point in the plots before is one random experiment.  

Linear regression
========================================================

Can the relationship between two variables be described as a linear function?

- since there is a variation (error) in the observations then which is the best line that described the relationship?


Linear regression
========================================================

For each observed value of $x_i$ we would liket to obtain a new value of $\hat{y}_i$ such that
</br>$\hat{y}_i=m x_i+b$ (blue)

<img src="./figures/reg.png" style="width:35%"  align="center">

we want to determine $m$  and $b$

Linear regression
========================================================

One way is to find the line, defined by $m$  and $b$, such that the sum of the distances from the data points (red) to the new points (blue) is minimum. 

</br>$Q=\sum_{i=1}^n (y_i- \hat{y}_i)^2= \sum_{i=1}^n (y_i- (mx_i+b))^2$

Linear regression
========================================================

We, therefore, derive with respect to $m$  and $b$
$$Q=\sum_{i=1}^n (y_i- \hat{y}_i)^2= \sum_{i=1}^n (y_i- (mx_i+b))^2$$

we equal to zero to obtain

</br>$m= \frac{\sum{i=1}^n (x_i-\bar{x})(y_i-\bar{y})}{\sum{i=1}^n (x_i-\bar{x})^2}$
</br>$b=\bar{y}-m\bar{x}$

Linear regression
========================================================

Let's compute $m$  and $b$ for the relationship between <code>a$Solar.R</code> and <code>a$Ozone</code>. But first, we remove the missing values <code>NA</code> in <code>a</code>, using the function <code>complete.cases</code>


```r
select <- complete.cases(a) 
head(select) 
```

```
[1]  TRUE  TRUE  TRUE  TRUE FALSE FALSE
```

```r
a <- a[select,]
head(a)
```

```
  Ozone Solar.R Wind Temp Month Day
1    41     190  7.4   67     5   1
2    36     118  8.0   72     5   2
3    12     149 12.6   74     5   3
4    18     313 11.5   62     5   4
7    23     299  8.6   65     5   7
8    19      99 13.8   59     5   8
```


Linear regression
========================================================

Let's compute $m$  and $b$ for the relationship between <code>a$Solar.R</code> and <code>a$Ozone</code>.

- assign <code>x</code> to <code>a$Solar.R</code> and <code>y</code> to  <code>a$Ozone</code>

- assign  <code>xbar</code> to the mean of <code>x</code> y and <code>ybar</code> to the mean of <code>y</code>.

- use <code>sum</code> assign to  <code>m</code> the quantity 
$\frac{\sum{i=1}^n (x_i-\bar{x})(y_i-\bar{y})}{\sum{i=1}^n (x_i-\bar{x})^2}$

- assign to <code>b</code> the quantity $\bar{y}-m\bar{x}$

Linear regression
========================================================


```r
x <- a$Solar.R
y <- a$Ozone

xbar <- mean(x)
ybar <- mean(y)

m <- sum((x-xbar)*(y-ybar))/sum((x-xbar)^2)
b <- ybar-m*xbar

m
```

```
[1] 0.1271653
```

```r
b
```

```
[1] 18.59873
```

Linear regression
========================================================

We are now going to define a function (<code>ypred</code>) that predicts the value of <code>y</code> when <code>x=20</code>, or for any value of <code>x=20</code>


```r
ypred <- function (x) {m*x+b}
ypred(0)
```

```
[1] 18.59873
```

```r
ypred(20)
```

```
[1] 21.14203
```


Linear regression
========================================================

-  R undestands that <code>x</code> in the definition of  <code>ypred</code> is an internal variable (we could have used another name).
- but remember that we have defined a variable <code>x</code> with the data from Solar radiation, so we can do 


```r
ypred(x)
```

```
  [1] 42.76013 33.60423 37.54635 58.40146 56.62114 31.18809 21.01487 51.15304
  [9] 55.47666 53.44201 26.86447 61.07193 57.63847 28.51762 59.54595 24.19400
 [17] 19.61605 59.29161 21.77786 30.29793 20.25188 50.64438 46.95658 54.07784
 [25] 34.74872 55.60382 59.67311 37.41919 42.88729 54.71366 23.30384 33.85856
 [33] 36.02037 52.80619 50.13572 48.60973 40.85265 58.52862 53.69634 52.55186
 [41] 53.18768 40.85265 52.17036 40.85265 24.70266 51.66170 53.44201 54.84083
 [49] 42.37863 46.57509 19.48888 55.98532 46.95658 28.89911 29.02628 45.68493
 [57] 53.56918 50.77154 50.89871 29.15345 21.65069 28.39045 51.02587 47.71957
 [65] 44.92194 43.01446 53.31485 38.56368 27.62746 25.08416 33.22273 49.62705
 [73] 42.76013 51.53453 23.17668 45.55777 48.86406 45.93926 44.41328 47.21091
 [81] 48.73690 42.50580 39.83533 43.65029 41.86997 42.63296 30.67943 30.29793
 [89] 50.64438 46.57509 47.84674 51.53453 48.60973 51.53453 48.86406 21.65069
 [97] 32.84124 48.73690 47.08375 22.03219 48.86406 44.15895 48.86406 20.37904
[105] 36.27470 24.82983 21.14203 43.14163 42.88729 35.25738 46.95658
```



Linear regression
========================================================

- Now we compare our data with the line $mx+b$


```r
plot(y ~ x)
lines(x, ypred(x),col="blue")
```

![plot of chunk unnamed-chunk-17](Lecture3-figure/unnamed-chunk-17-1.png)



Linear regression
========================================================

We have found a line, but how actually close is the relationship between <code>y</code> and <code>x</code> to a line?

We want a measure of such closeness, we will call it $R^2>0$ and require that 

- $R^2=1$ when the relationship is a perfect line. 
- $R^2=0$ when it is furthest from a line. 


Linear regression
========================================================


- $\sum_{i=1..n}(y_i-\bar{y})^2$ measures how much the data $y_i$ change about their mean. 

- $\sum_{i=1..n}(ypred_i-\bar{y})^2$ measures how much the predictions $ypred_i$ change about their mean. 

How much percentage in the variation of the data is explained by the variation of the predicted line?

Linear regression
========================================================

We define the coefficient of variation 

$R^2=\frac{\sum_{i=1..n}(ypred_i-\bar{y})^2}{\sum_{i=1..n}(y_i-\bar{y})^2}$

- $R^2=1$ when all the data falls in a line $y_i=ypred_i$
- $R^2=0$ when data is furthest from a line, or they uniformly distribute on a disc (no line is better than other)
- $R$ is called Pearson's correlation coefficient

Linear regression
========================================================

We now compute, for our data
</br>$R^2=\frac{\sum_{i=1..n}(\hat{y}_i-\bar{y})^2}{\sum_{i=1..n}(y_i-\bar{y})^2}$

where 

$\hat{y}_i=ypred_i=ypred(x)$

Linear regression
========================================================

The $12\%$ of the variation of the data can be explained by an underlying linear relatioship between <code>x</code> and <code>y</code>


```r
R2 <- sum((ypred(x)-ybar)^2)/sum((y-ybar)^2)
R2
```

```
[1] 0.1213419
```


Statistical dependence
========================================================

A note on statistical dependence.

- We have found an underlying relationship between $x$ and $y$.
- This implies that knowing $x$ brings knowledge on $y$ and therefore fore they are not statistically independent variables.


Statistical dependence
========================================================
Here is the joint probability distribution $f(x,y)$. This is a two-dimensional histogram where the bins are little squares and the (marginal) histograms of $x$ and $y$ are shown on top and bottom.

![plot of chunk unnamed-chunk-19](Lecture3-figure/unnamed-chunk-19-1.png)


Statistical dependence
========================================================

</br>let's look in detail at the gradient of the regression
$m=\frac{\sum{i=1}^n (x_i-\bar{x})(y_i-\bar{y})}{\sum{i=1}^n (x_i-\bar{x})^2}$

Counting how many points fell on each square (i,j) and inteval (i) bins we can write $m$ in terms of frequencies $f_ij$ and $f_i$ 
</br>$m=\frac{\sum{i=1}^m \sum{j=1}^l(x_i-\bar{x})(y_i-\bar{y})f_{i,j})}{\sum{i=1}^n (x_i-\bar{x})f_i^2}$
</br>If $X$ and $Y$ are independent then $f_ij=f_i*f_j$ ($P(X,Y)=P(X)*P(Y)$) and we have on the numerator of $m$, $\sum{i=1}^m(x_i-\bar{x})f_i\sum{j=1}^l(y_i-\bar{y})f_j)=m(\bar{x}-\bar{x})*(\bar{y}-\bar{y})=0$. 

Therefore, when $X$ and $Y$ are statistically independent then $m=0$.  


Statistical dependence
========================================================
This is how the joint probability distribution of two **independent** variables looks like

![plot of chunk unnamed-chunk-20](Lecture3-figure/unnamed-chunk-20-1.png)


Statistical dependence
========================================================
This is how the joint probability distribution of two **dependent** variables through a linear dependence

![plot of chunk unnamed-chunk-21](Lecture3-figure/unnamed-chunk-21-1.png)

Linear regression
========================================================

We can do all of this, and much more, with the function <code>lm</code>. We store the output of the function in the variable <code>mod</code>


```r
#using the data.frame a (in the parameter data) 
mod <- lm(Ozone ~ Solar.R, data=a)

#using the variables x e y
mod <- lm(y ~ x)
```

Linear regression
========================================================

We retrieve the information stored in the variable <code>mod</code> with the function <code>summary</code>, 



```r
summary(mod)
```

```

Call:
lm(formula = y ~ x)

Residuals:
    Min      1Q  Median      3Q     Max 
-48.292 -21.361  -8.864  16.373 119.136 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept) 18.59873    6.74790   2.756 0.006856 ** 
x            0.12717    0.03278   3.880 0.000179 ***
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 31.33 on 109 degrees of freedom
Multiple R-squared:  0.1213,	Adjusted R-squared:  0.1133 
F-statistic: 15.05 on 1 and 109 DF,  p-value: 0.0001793
```


Linear regression
========================================================

The plot of the regression line can be added with the function <code>abline</code> on the output of <code>lm</code> 


```r
plot(x, y)
abline(mod)
```

![plot of chunk unnamed-chunk-24](Lecture3-figure/unnamed-chunk-24-1.png)


Linear regression
========================================================

The predicted values on the line are obtained with the function <code>predict</code>

The prediction of the ozone for a solar radiation of 20 is

```r
predict(mod, data.frame(x=20))
```

```
       1 
21.14203 
```


Data structures
========================================================

what is the class of <code>mod</code>?


- the class of <code>mod</code> is a new data structure called <code>lm</code> that is constructed by the function <code>lm()</code>


```r
class(mod)
```

```
[1] "lm"
```

<code>predict()</code> is a function that acts on the data structure <code>lm</code>. which data structure is the output of <code>predict()</code>?



Data structures
========================================================

Note:

<code>vector</code> $\rightarrow$ <code>data.frame(vector)</code> $\rightarrow$ <code>lm(data.frame)</code> $\rightarrow$ <code>predict(lm)</code> $\rightarrow$ <code>vector</code>

This is a typical R workflow. 

Exponential regression 
========================================================

Now let`s look at the relationship between <code>a$Ozone</code> and <code>a$Temp</code>


- plot Ozone Vs Temp  and  log(Ozone) Vs Temp 
- use the function  <code>lm</code>  to study Ozone Vs Temp  and log(Ozone) Vs Temp 
- plot each relationship with their regression line
- which regression explains more variability?
- which is a better predictor of ozone, solar radiation, or the temperature? 


Problem
===================================

High ozone levels are toxic. Patients with asthma and chronic obstructive pulmonary disease are at increased risk of hospitalizations during days of high ozone levels. 

- Imagine you work in the national weather service (AEMET) and you are required to predict days with high levels of ozone, such that the service raises alarm on high ozone contamination. 
- at what temperature should you activate the alarm on ozone levels higher than 60?


Problem
===================================

The limit of ozone (Oz=60,log(Oz)=4.09) is surpassed in most days with temperatures higher than 80F (26C)

![plot of chunk unnamed-chunk-27](Lecture3-figure/unnamed-chunk-27-1.png)![plot of chunk unnamed-chunk-27](Lecture3-figure/unnamed-chunk-27-2.png)


