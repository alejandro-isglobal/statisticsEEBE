Statistical concepts with R  
========================================================
author: Alejandro Cáceres
date:  
autosize: true

Barcelona East School of Engineering<br> 
Universitat Politècnica de Catalunya (UPC)
 

<p style="font-size:70px">Lecture 2</p>

Objective
========================================================
 
Use R to: 
- describe data in data and tables
- categorical and continuous variables


Objective
========================================================
 

This is a guide intended to be followed with the help of material in Lecture 1. 

- Try to answer the questions on your own. 

- Answers are given in a script.txt and accompanying videos.

Importing data
========================================================

Important: download the file <code>dat1.txt</code> and make sure that R is running on the directory where you downloaded the file. 

To select the directory where R is running:
- Select: Session in the upper menu bar of RStudio
- Select: Set Working Directory
- Select: Choose Directory...

or just press [Ctrl+Shift+H]

- and then select the directory and press open.



Importing data
========================================================

Data are usually found in text files.
Data from a text file are read into data.frames in R with the function <code>read.table()</code>.


```r
a <- read.table("air.txt")
a[1:5,]
```

```
     V1      V2   V3   V4    V5  V6
1 Ozone Solar.R Wind Temp Month Day
2    41     190  7,4   67     5   1
3    36     118    8   72     5   2
4    12     149 12,6   74     5   3
5    18     313 11,5   62     5   4
```


Importing data
========================================================

However, we want the first line of the text file to be read as the names of the variables in the data frame


```r
names(a)
```

```
[1] "V1" "V2" "V3" "V4" "V5" "V6"
```

Check the multiple options by inspecting R documentation <code>?read.table</code>

Importing data
========================================================

We use <code>header=TRUE</code>

```r
a <- read.table("air.txt", header=TRUE)
names(a)
```

```
[1] "Ozone"   "Solar.R" "Wind"    "Temp"    "Month"   "Day"    
```

Importing data
========================================================

We look at the first lines of <code>a</code> with the function <code>head</code>

```r
head(a)
```

```
  Ozone Solar.R Wind Temp Month Day
1    41     190  7,4   67     5   1
2    36     118    8   72     5   2
3    12     149 12,6   74     5   3
4    18     313 11,5   62     5   4
5    NA      NA 14,3   56     5   5
6    28      NA 14,9   66     5   6
```

Data
========================================================

- The data in <code>a</code> represent air quality measurements, including Ozone concentration, Solar radiation, Wind, and Temperature on a geographical location during different days.

- We see entries encoded as <code>NA</code>. These represent instances in which data could not be collected, namely missing observations.  
Data
========================================================
We usually start by asking basic questions on the data (see lecture 1)

- What data structure is <code>a</code>?
- What are its dimensions?
- How do I obtain the variable Ozone? 
- What structure is Ozone? is it a vector?
- How do I obtain the first 10 values of Ozone?
- What info does <code>length(a$Ozone)</code> retrieves?


Categorical variables
========================================================

- Categorical data: Discrete numerable variables like month or day, or unordered like sex or color

- Let's explore the variable <code>Month</code> from the <code>data.frame</code> <code>a</code>

Frequency tables
========================================================

Absolute frequency ($n_i$): How many times does each of the months appeared in the variable  <code>Month</code>?

- Assign "<code><-</code>"" to the variable <code>ni</code> the output of applying the function <code>table</code> on  <code>a$Month</code> 

- How many observations were done in July and August?

Frequency tables
========================================================

Relative frequency ($f_i$): It is the absolute frequency divided by the total number of observations.

What is the proportion of observations made for each month?

- use the function <code>prop.table</code> on <code>ni</code> assign its output to <code>fi</code>

- why <code>sum(fi)</code> is 1? (What does <code>sum</code> do?)

- what is the relative frequency of <code>a$Month</code> up to July?


Frequency tables
========================================================

Absolute cumulative frequency ($N_i$): It is the sum of the
absolute frequency up to a given value of a categorical ordered variable. 

For <code>a$Month</code>, $N_i$ is a vector (5 components) whose elements are first, the number of observations up May (month 5), second the number of observations up to June (month 6), ... up to September (month 9).

- use the function <code>cumsum</code> on <code>ni</code> assign its output to <code>Ni</code>


- What do you obtain with <code>Ni[-c(2,3,4,5)]</code>?


Frequency tables
========================================================

Relative cumulative frequency ($F_i$): It is the absolute cumulative frequency divided by the total number of observations.

- For <code>a$Month</code> , $F_i$ is a vector (5 components) whose elements are first, the acumulated proportion of observations up May (month 5), second acumulated proportion of observations up June (month 6), ... up to September (month 9).

- use the function <code>cumsum</code> on <code>fi</code> assign its output to <code>Fi</code>

- What do you obtain with 1-Fi[3]?



Frequency tables
========================================================

Pongamos todas las frecuencias en una matriz



```r
Tabla_Frec <- cbind(ni,Ni,fi,Fi)
Tabla_Frec
```

```
  ni  Ni        fi        Fi
5 31  31 0.2026144 0.2026144
6 30  61 0.1960784 0.3986928
7 31  92 0.2026144 0.6013072
8 31 123 0.2026144 0.8039216
9 30 153 0.1960784 1.0000000
```

Plots
========================================================

The frequencies of categorical data can be visualized with:

- Pie: apply <code>pie</code> on <code>ni</code>. It shows the relative frequencies as the proportions of the area of a disc that correspond to each category. 

- Dot chart: apply <code>dotchart</code> on <code>a\$Month</code>: on thex asis is shows the values of the variable is adds a point for each observation in a particular value. 

Plots
========================================================
Can you obtain the following plots? which one is a pie plot and which is a dot chart?

![plot of chunk unnamed-chunk-7](Lecture2-figure/unnamed-chunk-7-1.png)![plot of chunk unnamed-chunk-7](Lecture2-figure/unnamed-chunk-7-2.png)

Numerical variables
========================================================

Descriptive statistics are typically used to describe numerical variables, including discrete and continuous.

- mean: it is the average
$\bar{x}=\frac{1}{n} \Sigma_{i=1..n} x_i$.
- minimum: the minimum value observed.
- maximum: the maximum value observed.
- median: the value that split into two equal parted the observations (50% of the observations are lower than the median).


Continuous variables
========================================================

Let's look at the continuos variable: Ozone in <code>a</code>

- What are the median, minumum, maximum and median of Ozone?

- Use the functions <code>mean</code>, <code>min</code>, <code>max</code> and <code>median</code>. 

- use the parameter <code>na.rm=TRUE</code> to account for missing values. 

Plots
========================================================

Continuous data can be visualized with a stem plot. 


```r
stem(a$Ozone)
```

```

  The decimal point is 1 digit(s) to the right of the |

   0 | 1467778999
   1 | 01112233334444666688889
   2 | 0000111123333334478889
   3 | 001222455667799
   4 | 01444556789
   5 | 0299
   6 | 134456
   7 | 13367889
   8 | 024559
   9 | 1677
  10 | 8
  11 | 058
  12 | 2
  13 | 5
  14 | 
  15 | 
  16 | 8
```

Plots
========================================================

The numbers in the stem plot are the actual observations on Ozone, ordered from the minimum to the maximum value: 

That is:

(1,4,6,7,7,7,8,9,9,9,10,11,11,11,12,13 ... 135,168)

In the plot the <code>|</code> character represents the number of 10ths for each observation. Therefore we see in the first line of the plot all the values that fell in the 0-th tenth (0). That is observations: 1, 4, 6, ...9,9,9. The second line is the observations that fell in the first tenth (1), that is 11, 11, 11, 11, 12 .... and so on. The last value is the 16th tenth plus 8 units, or 168.  

Plots
========================================================


In the previous stem plot data was binned at regular intervals of size 10 (10ths). It is useful to bin data in flexible intervals. For instance, if the rance of the observations in between 0, and 1. 

- We can bin continuous data at regular intervals with the histogram. 

- Which is a horizontal representation of the stem plot? 

- We count the number of observations that fell in a particular bin. 

- For each bin, we draw a bar. 

Plots
========================================================
We can change the number of bins with the parameter <code>br</code>.


```r
hist(a$Ozone, br=10)
```

![plot of chunk unnamed-chunk-9](Lecture2-figure/unnamed-chunk-9-1.png)


Dispersion
========================================================

The plots show that there is dispersion on the observations. 

Dispersion or spread of data can be measured with

- the standard deviation (corrected standard error): 
</br>$s=[\frac{1}{n-1} \Sigma_{i=1..n} (x_i-\bar{x})^2]^{1/2}$
</br>it measures the mean cuadratic distace from the **median**

- what is the standar deviation for Ozone?

use the function <code>sd</code> with parameter  <code>na.rm=TRUE</code>

Note: $s^2$ is called the sample variance.

Dispersion
========================================================
Dispersion can also be measured with
- The interquartile range: This is the distance between the **first** and **third** quartiles.

-- the first quartile is the value that splits the lower 25% the observations, $q_{0.25}$. 

-- the second quartile is the value that splits the lower 50% the observations, that is the median.

-- the third quartile is the value that splits the lower 75% the observations, $q_{0.75}$.


Dispersion
========================================================

- The interquartile range is Q3-Q1 and measures the dispersion about the median. It captures the observations that are above 25%  and below the 75% 

- The function <code>quantile(a$Ozone, probs=XX, na.rm=TRUE)</code> computes the $q_{xx}$ quantile. Where xx is the percentage where we want to split the data.

then 
</br><code>probs = 0.25</code> (first quartile 25%) 
</br><code>probs = 0.75</code> (first quartile 75%),

Dispersion
========================================================

- Compute  $q_{0.25}$ and $q_{0.75}$ for Ozone 
- Compute thier difference
- Is it the same that applying <code>IQR(a\$Ozone,na.rm=TRUE)</code>?

Dispersion
========================================================

Boxplot: Shows the 1st and 3rd quartiles as a box, the median is the line between the box and the $q_{0.05}$ and  $q_{0.95}$ are shown by whiskers. Outliers, which are data that are further than $q_{0.05}$ and  $q_{0.95}$ are shown as single dots. 


```r
bp <- boxplot(a$Ozone)
```

![plot of chunk unnamed-chunk-10](Lecture2-figure/unnamed-chunk-10-1.png)

Dispersion
========================================================

Is the maximum value of Ozone an outlier?

We had assigned to <code>bp</code> the outcome of the boxplot, we can extract further information. The assignment is not required to produce the plot. The outliers, for instance, can be obtained as follows


```r
names(bp)
```

```
[1] "stats" "n"     "conf"  "out"   "group" "names"
```

```r
bp$out
```

```
[1] 135 168
```
