---
title: "Errata Práctica7"
author: "Alejandro Caceres"
date: "14/12/2020"
output: html_document
---

En los vídeos de la práctica 7 se ha hecho la definición

$z_{\alpha/2}=$<code>qnorm(alpha/2)</code>

Es convención en estadística usar:

- $z_{\alpha/2}=$<code>qnorm(1-alpha/2)</code>

- $t_{\alpha/2, n-1}=$<code>qt(1-alpha/2, n-1)</code>

- $\chi^2_{\alpha/2, n-1}=$<code>qchisq(1-alpha/2, n-1)</code>

o en genral

$\zeta_{\alpha/2}=F^{-1}(1-\alpha/2)=$<code>qXXX(1-alpha/2)</code>

Estas nuevas deficiciones se han replazado en las diapos pero no en los vídeos. 